//
//  main.m
//  asoserver
//
//  Created by Qiu.ZhiKai on 2017/3/28.
//  Copyright © 2017年 robert. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMain.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        [CMain start];
    }
}
