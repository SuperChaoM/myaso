//
//  CfgManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/20.
//
//

#import <Foundation/Foundation.h>

@interface Utils : NSObject

+ (NSString *)getAppDocumentsPath:(NSString *)identifier;

@end
