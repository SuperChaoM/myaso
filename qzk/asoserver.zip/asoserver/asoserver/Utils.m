//
//  CfgManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/20.
//
//

#import "Utils.h"
#import "LSApplicationWorkspace.h"
#import "LSApplicationProxy.h"

@implementation Utils

+ (NSString *)getAppDocumentsPath:(NSString *)identifier {
    NSArray *allApps = [[LSApplicationWorkspace defaultWorkspace] allApplications];
    for (id app in allApps) {
        NSString *appIdf = [app applicationIdentifier];
        NSURL *containurl = [app containerURL];
        if ([appIdf isEqualToString:identifier]) {
            NSString *path = [containurl absoluteString];
            path = [path stringByReplacingOccurrencesOfString:@"file://" withString:@""];
            if ([path hasSuffix:@"/"]) {
                path = [path stringByAppendingString:@"Documents/"];
            } else {
                path = [path stringByAppendingString:@"/Documents/"];
            }
            return path;
        }
    }
    
    return @"";
}

@end
