//
//  CMain.m
//  myDaemon
//
//  Created by Qiu.ZhiKai on 6/3/14.
//  Copyright (c) 2014 Qiu.ZhiKai. All rights reserved.
//

#import "CMain.h"
#import "LSApplicationWorkspace.h"
#import "Utils.h"

static CMain* s_main = nil;

@implementation CMain

+ (void)start
{
    if (s_main == nil){
        s_main = [[CMain alloc] init];
    }
    [s_main initNotify];
    
    CFRunLoopRun();
}

- (void)initNotify
{
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    (__bridge const void *)(self),
                                    InstallCB,
                                    CFSTR("com.robert.asoserver.install"),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    (__bridge const void *)(self),
                                    UninstallCB,
                                    CFSTR("com.robert.asoserver.uninstall"),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    (__bridge const void *)(self),
                                    ResetIdfaCB,
                                    CFSTR("com.robert.asoserver.resetidfa"),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/DynamicLibraries/FakeIDFA.dylib"]) {
        [[NSFileManager defaultManager] removeItemAtPath:@"/Library/MobileSubstrate/DynamicLibraries/FakeIDFA.dylib" error:nil];
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/DynamicLibraries/FakeIDFA.plist"]) {
        [[NSFileManager defaultManager] removeItemAtPath:@"/Library/MobileSubstrate/DynamicLibraries/FakeIDFA.plist" error:nil];
    }
    
    NSLog(@"##### aso守护启动 #####");
}

#pragma mark - 通知回调
// 安装应用
void InstallCB (CFNotificationCenterRef center,
                      void *observer,
                      CFStringRef name,
                      const void *object,
                      CFDictionaryRef userInfo) {
    NSString *docDir = [Utils getAppDocumentsPath:@"com.apple.AppStore"];
    NSString *tmpIpa = [NSString stringWithFormat:@"%@tmp.ipa", docDir];
    NSLog(@"##### InstallCB ipa路径:%@ #####", tmpIpa);
    [[LSApplicationWorkspace defaultWorkspace] installApplication:[NSURL URLWithString:tmpIpa]
                                                      withOptions:nil
                                                            error:nil
                                                       usingBlock:^(NSDictionary *dictionary) {
//       NSLog(@"##### 安装进度: %@ #####", dictionary);
   }];
}

// 卸载应用
void UninstallCB (CFNotificationCenterRef center,
                void *observer,
                CFStringRef name,
                const void *object,
                CFDictionaryRef userInfo) {
    NSLog(@"##### UninstallCB #####");
    NSString *docDir = [Utils getAppDocumentsPath:@"com.apple.AppStore"];
    NSString *path = [NSString stringWithFormat:@"%@task.txt", docDir];
    NSString *jsonString = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    jsonString = jsonString == nil ? @"" : jsonString;
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *task = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];
    if (task) {
        NSString *idf = [task valueForKey:@"identifier"];
        NSLog(@"##### UninstallCB %@ #####", idf);
        NSDictionary *opt = [NSDictionary dictionaryWithObject:@"User" forKey:@"ApplicationType"];
        [[LSApplicationWorkspace defaultWorkspace] uninstallApplication:idf withOptions:opt];
    }
}


// 重置idfa
void ResetIdfaCB (CFNotificationCenterRef center,
                  void *observer,
                  CFStringRef name,
                  const void *object,
                  CFDictionaryRef userInfo) {
    NSLog(@"##### ResetIdfaCB #####");
    [[LSApplicationWorkspace defaultWorkspace] clearAdvertisingIdentifier];
}

@end
