//
//  CMain.h
//  myDaemon
//
//  Created by Qiu.ZhiKai on 6/3/14.
//  Copyright (c) 2014 Qiu.ZhiKai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CMain : NSObject

+ (void)start;



@end
