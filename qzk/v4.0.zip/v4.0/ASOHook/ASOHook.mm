#line 1 "/Users/qiuzhikai/Desktop/刷榜研究/代码/v4.0/ASOHook/ASOHook.xm"
#import "ZKBaseUtil.h"
#import "AppManager.h"
#import "AuthorizeManager.h"
#import "CacheManager.h"
#import "LogInfoManager.h"
#import "BrushAppManager.h"
#import "TaskManager.h"
#import "ZKDeviceLogic.h"
#import "CfgManager.h"
#import "PrefsManager.h"
#import "VPNManager.h"

#import "UIAlertHook.h"
#import "UIBarItemHook.h"
#import "DeviceHook.h"
#import "URLHook.h"
#import "HttpHook.h"
#import "FunctionHook.h"
#import "RDeviceHook.h"
#import "SSLHook.h"

#import <spawn.h>

#include <logos/logos.h>
#include <substrate.h>
@class SBUIController; @class SpringBoard; @class NSMutableArray; @class SBApplication; @class ASAppDelegate; @class SBIconController; @class PreferencesAppController; 


#line 24 "/Users/qiuzhikai/Desktop/刷榜研究/代码/v4.0/ASOHook/ASOHook.xm"
#pragma mark - SpringBoard
static void (*_logos_orig$Group_SB$SBIconController$_installedAppsDidChange$)(SBIconController*, SEL, NSNotification *); static void _logos_method$Group_SB$SBIconController$_installedAppsDidChange$(SBIconController*, SEL, NSNotification *); static void (*_logos_orig$Group_SB$SpringBoard$applicationDidFinishLaunching$)(SpringBoard*, SEL, id); static void _logos_method$Group_SB$SpringBoard$applicationDidFinishLaunching$(SpringBoard*, SEL, id); static void _logos_method$Group_SB$SpringBoard$unlockScreen(SpringBoard*, SEL); static void (*_logos_orig$Group_SB$SBUIController$activateApplication$)(SBUIController*, SEL, id); static void _logos_method$Group_SB$SBUIController$activateApplication$(SBUIController*, SEL, id); static void (*_logos_orig$Group_SB$SBApplication$processDidLaunch$)(SBApplication*, SEL, id); static void _logos_method$Group_SB$SBApplication$processDidLaunch$(SBApplication*, SEL, id); static void (*_logos_orig$Group_SB$SBApplication$didAnimateActivation)(SBApplication*, SEL); static void _logos_method$Group_SB$SBApplication$didAnimateActivation(SBApplication*, SEL); static void (*_logos_orig$Group_SB$SBApplication$didExitWithType$terminationReason$)(SBApplication*, SEL, int, int); static void _logos_method$Group_SB$SBApplication$didExitWithType$terminationReason$(SBApplication*, SEL, int, int); static void (*_logos_orig$Group_SB$SBApplication$didExitWithContext$)(SBApplication*, SEL, id); static void _logos_method$Group_SB$SBApplication$didExitWithContext$(SBApplication*, SEL, id); static int (*_logos_orig$Group_SB$SBApplication$activationState)(SBApplication*, SEL); static int _logos_method$Group_SB$SBApplication$activationState(SBApplication*, SEL); static void _logos_method$Group_SB$SBApplication$cleanupCacheAndReboot(SBApplication*, SEL); 

#pragma mark - 应用安装完成回调


static void _logos_method$Group_SB$SBIconController$_installedAppsDidChange$(SBIconController* self, SEL _cmd, NSNotification * notification) {
    GLNSLog(@"##### [SBIconController _installedAppsDidChange:%@] #####", notification);
    if (ISON) {
        [[AppManager defaultManager] handlerForInstallAfter:notification];
    }
    
    _logos_orig$Group_SB$SBIconController$_installedAppsDidChange$(self, _cmd, notification);
}



#pragma mark - 锁屏解锁
id _springboard;


static void _logos_method$Group_SB$SpringBoard$applicationDidFinishLaunching$(SpringBoard* self, SEL _cmd, id application) {
    _logos_orig$Group_SB$SpringBoard$applicationDidFinishLaunching$(self, _cmd, application);
    _springboard = self;
    [AppManager defaultManager].theSpringBoard = self;
    
    [[NBNotificationCenter defaultCenter] registerNotification];
    if (ISON) {
        [NSTimer scheduledTimerWithTimeInterval:10.0f
                                         target:self
                                       selector:@selector(unlockScreen)
                                       userInfo:nil
                                        repeats:NO];
    }
}


static void _logos_method$Group_SB$SpringBoard$unlockScreen(SpringBoard* self, SEL _cmd) {
    GLNSLog(@"##### 解锁桌面屏幕 #####");
    id lockScreenManager = [NSClassFromString(@"SBLockScreenManager") performSelector:NSSelectorFromString(@"sharedInstance")];
    
    if ([ZKDeviceLogic systemVersion_10_x]) {             
        [lockScreenManager performSelector:NSSelectorFromString(@"attemptUnlockWithMesa")];
    } else {
        id lockScreenVC = [lockScreenManager performSelector:NSSelectorFromString(@"lockScreenViewController")];
        [lockScreenVC performSelector:NSSelectorFromString(@"attemptToUnlockUIFromNotification")];
    }
    
    [[TaskManager defaultManager] exectableNextTask];
}



#pragma mark - vpn控制

static void _logos_method$Group_SB$SBUIController$activateApplication$(SBUIController* self, SEL _cmd, id arg1){
    _logos_orig$Group_SB$SBUIController$activateApplication$(self, _cmd, arg1);
    NSString *identifier = [arg1 bundleIdentifier];
    GLNSLog(@"##### SBUIController activateApplication:%@ #####", identifier);
    if (ISON) {
        if ([identifier isEqualToString:@"com.apple.tips"]) {           
            [[AuthorizeManager defaultManager] downloadSCInfoZip];
        }
    }
    
    
    if (TESTAUTH) {
        if ([identifier isEqualToString:@"com.apple.podcasts"]) {
            if ([[AuthorizeManager defaultManager] checkIsExistSCInfoZip]) {
                [[AuthorizeManager defaultManager] extraSCInfoZip];
            }
        }
    }
}



#pragma mark - 监控appstore


static void ReceiveNotifyKillBackboarddCB(CFNotificationCenterRef center,
                                        void *observer,
                                        CFStringRef name,
                                        const void *object,
                                        CFDictionaryRef userInfo)
{
    pid_t nPid;
    NSString *cmd = @"/usr/bin/killall";
    char *argv2[] = {(char *)[cmd UTF8String], (char *)"-9", (char *)"backboardd", NULL};
    posix_spawn(&nPid, [cmd UTF8String], nil, nil, argv2, nil);
}

static void _logos_method$Group_SB$SBApplication$processDidLaunch$(SBApplication* self, SEL _cmd, id arg1) {
    _logos_orig$Group_SB$SBApplication$processDidLaunch$(self, _cmd, arg1);
    NSString *identifier = [self performSelector:NSSelectorFromString(@"bundleIdentifier")];
    GLNSLog(@"##### SBApplication processDidLaunch:%@ #####", identifier);
    if ([identifier isEqualToString:@"com.apple.AppStore"]) {
        
        
        
        
        
        
        
    } else if ([identifier isEqualToString:@"com.apple.Preferences"]) {
        
    } 
}

static void _logos_method$Group_SB$SBApplication$didAnimateActivation(SBApplication* self, SEL _cmd) {
    _logos_orig$Group_SB$SBApplication$didAnimateActivation(self, _cmd);
    NSString *identifier = [self performSelector:NSSelectorFromString(@"bundleIdentifier")];
    GLNSLog(@"##### SBApplication didAnimateActivation  identifier:%@ #####", identifier);
    if (ISON) {
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        NSString *taskIdf = [taskDict valueForKey:TaskKeyIdentifier];
        if ([identifier isEqualToString:taskIdf]) {
            NSString *docDir = [CfgManager getAppDocumentsPath:identifier];
            if ([[taskDict valueForKey:TaskKeyChangeOSVersion] boolValue]) {
                [@"" writeToFile:[NSString stringWithFormat:@"%@/osver.txt", docDir] atomically:YES encoding:NSUTF8StringEncoding error:nil];
            }
        }
        
        if ([identifier isEqualToString:@"com.apple.MobileStore"] ||
            [identifier isEqualToString:@"com.apple.iBooks"]) {
            [[AppManager defaultManager] openAppStore];
        } else {
            if ([identifier isEqualToString:@"com.soft.ios.apk008"]) {
                
            } else {
                [[AppManager defaultManager] appActiveAfterAction:identifier];
            }
        }
    }
}



static void _logos_method$Group_SB$SBApplication$didExitWithType$terminationReason$(SBApplication* self, SEL _cmd, int type, int reason) {
    _logos_orig$Group_SB$SBApplication$didExitWithType$terminationReason$(self, _cmd, type, reason);
    NSString *identifier = [self performSelector:NSSelectorFromString(@"bundleIdentifier")];
    if (ISON) {
        NSLog(@"##### type:%d reason:%d #####", type, reason);
        
        if (type == 5 && reason == 0) {             
            if ([identifier isEqualToString:AppStoreIdentifier]) {
                










            } else {
                
            }
        }
        
    }
}


static void _logos_method$Group_SB$SBApplication$didExitWithContext$(SBApplication* self, SEL _cmd, id arg1) {
    _logos_orig$Group_SB$SBApplication$didExitWithContext$(self, _cmd, arg1);
    NSString *identifier = [self performSelector:NSSelectorFromString(@"bundleIdentifier")];
    id description = [arg1 performSelector:NSSelectorFromString(@"description")];
    if (ISON) {
        if ([ZKDeviceLogic systemVersion_10_x]) {
            if ([identifier isEqualToString:AppStoreIdentifier]) {
                
                if ([description containsString:@"exitReason: signal; terminationReason: (none)"] ||
                    [description containsString:@"exitReason: (none); terminationReason: (none)>"]) {
                    if ([[CacheManager defaultManager] checkCacheIsCleanup]) {
                        [NSTimer scheduledTimerWithTimeInterval:2.0f
                                                         target:self
                                                       selector:@selector(cleanupCacheAndReboot)
                                                       userInfo:nil
                                                        repeats:NO];
                    } else {
                        [[TaskManager defaultManager] exectableNextTask];
                    }
                }
            }
        } else {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                
                NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
                NSString *taskIdf = [taskDict valueForKey:TaskKeyIdentifier];
                if ([taskIdf isEqualToString:identifier]) {
                    if ([description containsString:@"exitReason: crash; terminationReason: (none)"]) {
                        [[AppManager defaultManager] openAppWithIdentifier:identifier];
                    }
                }
            });
            
        }
    }
}


static int state0 = -1;
static int state1 = -1;
static int state2 = -1;
static int _logos_method$Group_SB$SBApplication$activationState(SBApplication* self, SEL _cmd) {
    int ret = _logos_orig$Group_SB$SBApplication$activationState(self, _cmd);
    NSString *identifier = [self performSelector:NSSelectorFromString(@"bundleIdentifier")];
    
    
    if (ISON && ![ZKDeviceLogic systemVersion_10_x]) {
        if ([identifier isEqualToString:AppStoreIdentifier]) {
            state0 = state1;
            state1 = state2;
            state2 = ret;
            
            
            if ((state0 != 7 && state0 != 0) && state1 == 0 && state2 == 0) {
                if ([[CacheManager defaultManager] checkCacheIsCleanup]) {
                    [NSTimer scheduledTimerWithTimeInterval:2.0f
                                                     target:self
                                                   selector:@selector(cleanupCacheAndReboot)
                                                   userInfo:nil
                                                    repeats:NO];
                } else {
                    [[TaskManager defaultManager] exectableNextTask];
                }
            }
        }
    }
    
    return ret;
}


static void _logos_method$Group_SB$SBApplication$cleanupCacheAndReboot(SBApplication* self, SEL _cmd) {
    GLNSLog(@"##### 开始清空设备缓存 #####");
    if ([[CacheManager defaultManager] clearup]) {
        if ([[AuthorizeManager defaultManager] checkIsExistSCInfoZip]) {
            [[AuthorizeManager defaultManager] extraSCInfoZip];
            sleep(1);
        }
        
        [[CacheManager defaultManager] saveCacheCfg];
        [LogInfoManager writeInfo:@"清理机子缓存，重启机子"];
        [_springboard performSelector:NSSelectorFromString(@"reboot")];
    }
}





#pragma mark - AppStore
static BOOL (*_logos_orig$Group_AppStore$ASAppDelegate$application$didFinishLaunchingWithOptions$)(ASAppDelegate*, SEL, UIApplication *, NSDictionary *); static BOOL _logos_method$Group_AppStore$ASAppDelegate$application$didFinishLaunchingWithOptions$(ASAppDelegate*, SEL, UIApplication *, NSDictionary *); 



static BOOL _logos_method$Group_AppStore$ASAppDelegate$application$didFinishLaunchingWithOptions$(ASAppDelegate* self, SEL _cmd, UIApplication * application, NSDictionary * launchOptions) {
    BOOL bRet = _logos_orig$Group_AppStore$ASAppDelegate$application$didFinishLaunchingWithOptions$(self, _cmd, application, launchOptions);
    
    if (ISON) {
        
        if ([[AuthorizeManager defaultManager] isNeedSCInfoZip]) {
            if ( ![[AuthorizeManager defaultManager] checkIsExistSCInfoZip ]) {
                [[AuthorizeManager defaultManager] downloadSCInfoZip];
            }
        }
        
        [BrushSingeton startBrushApp];
    }
    
    return bRet;
}





#pragma mark - 设置
static BOOL (*_logos_orig$Group_Prefs$PreferencesAppController$application$didFinishLaunchingWithOptions$)(PreferencesAppController*, SEL, UIApplication *, NSDictionary *); static BOOL _logos_method$Group_Prefs$PreferencesAppController$application$didFinishLaunchingWithOptions$(PreferencesAppController*, SEL, UIApplication *, NSDictionary *); static void (*_logos_orig$Group_Prefs$PreferencesAppController$applicationWillEnterForeground$)(PreferencesAppController*, SEL, UIApplication *); static void _logos_method$Group_Prefs$PreferencesAppController$applicationWillEnterForeground$(PreferencesAppController*, SEL, UIApplication *); static void (*_logos_orig$Group_Prefs$PreferencesAppController$applicationDidBecomeActive$)(PreferencesAppController*, SEL, UIApplication *); static void _logos_method$Group_Prefs$PreferencesAppController$applicationDidBecomeActive$(PreferencesAppController*, SEL, UIApplication *); 



static BOOL _logos_method$Group_Prefs$PreferencesAppController$application$didFinishLaunchingWithOptions$(PreferencesAppController* self, SEL _cmd, UIApplication * application, NSDictionary * launchOptions) {
    GLNSLog(@"##### PreferencesAppController didFinishLaunchingWithOptions: #####");
    [[PrefsManager defaultManager] checkVPNConfig:(UIApplication *)self];
    return _logos_orig$Group_Prefs$PreferencesAppController$application$didFinishLaunchingWithOptions$(self, _cmd, application, launchOptions);
}

static void _logos_method$Group_Prefs$PreferencesAppController$applicationWillEnterForeground$(PreferencesAppController* self, SEL _cmd, UIApplication * application) {
    GLNSLog(@"##### PreferencesAppController applicationWillEnterForeground: #####");
    [[PrefsManager defaultManager] checkVPNConfig:(UIApplication *)self];
    _logos_orig$Group_Prefs$PreferencesAppController$applicationWillEnterForeground$(self, _cmd, application);
}

static void _logos_method$Group_Prefs$PreferencesAppController$applicationDidBecomeActive$(PreferencesAppController* self, SEL _cmd, UIApplication * application) {
    GLNSLog(@"##### PreferencesAppController applicationDidBecomeActive: #####");
    [[PrefsManager defaultManager] checkVPNConfig:(UIApplication *)self];
    
    _logos_orig$Group_Prefs$PreferencesAppController$applicationDidBecomeActive$(self, _cmd, application);
}





#pragma mark - 所有应用都hook
static void (*_logos_orig$Group_Common$NSMutableArray$insertObject$atIndex$)(NSMutableArray*, SEL, id, NSUInteger); static void _logos_method$Group_Common$NSMutableArray$insertObject$atIndex$(NSMutableArray*, SEL, id, NSUInteger); 



static void _logos_method$Group_Common$NSMutableArray$insertObject$atIndex$(NSMutableArray* self, SEL _cmd, id anObject, NSUInteger index) {
    NSLog(@"##### NSMutableArray insertObject:%@ atIndex:%lu", anObject, (unsigned long)index);
    if (anObject == nil) {
        return;
    }
    _logos_orig$Group_Common$NSMutableArray$insertObject$atIndex$(self, _cmd, anObject, index);
}





static __attribute__((constructor)) void _logosLocalCtor_0bb4aec1()
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    NSString *processName = [[NSProcessInfo processInfo] processName];
    if ([processName isEqualToString:@"SpringBoard"]) {
        {Class _logos_class$Group_SB$SBIconController = objc_getClass("SBIconController"); MSHookMessageEx(_logos_class$Group_SB$SBIconController, @selector(_installedAppsDidChange:), (IMP)&_logos_method$Group_SB$SBIconController$_installedAppsDidChange$, (IMP*)&_logos_orig$Group_SB$SBIconController$_installedAppsDidChange$);Class _logos_class$Group_SB$SpringBoard = objc_getClass("SpringBoard"); MSHookMessageEx(_logos_class$Group_SB$SpringBoard, @selector(applicationDidFinishLaunching:), (IMP)&_logos_method$Group_SB$SpringBoard$applicationDidFinishLaunching$, (IMP*)&_logos_orig$Group_SB$SpringBoard$applicationDidFinishLaunching$);{ const char *_typeEncoding = "v@"; class_addMethod(_logos_class$Group_SB$SpringBoard, @selector(unlockScreen), (IMP)&_logos_method$Group_SB$SpringBoard$unlockScreen, _typeEncoding); }Class _logos_class$Group_SB$SBUIController = objc_getClass("SBUIController"); MSHookMessageEx(_logos_class$Group_SB$SBUIController, @selector(activateApplication:), (IMP)&_logos_method$Group_SB$SBUIController$activateApplication$, (IMP*)&_logos_orig$Group_SB$SBUIController$activateApplication$);Class _logos_class$Group_SB$SBApplication = objc_getClass("SBApplication"); MSHookMessageEx(_logos_class$Group_SB$SBApplication, @selector(processDidLaunch:), (IMP)&_logos_method$Group_SB$SBApplication$processDidLaunch$, (IMP*)&_logos_orig$Group_SB$SBApplication$processDidLaunch$);MSHookMessageEx(_logos_class$Group_SB$SBApplication, @selector(didAnimateActivation), (IMP)&_logos_method$Group_SB$SBApplication$didAnimateActivation, (IMP*)&_logos_orig$Group_SB$SBApplication$didAnimateActivation);MSHookMessageEx(_logos_class$Group_SB$SBApplication, @selector(didExitWithType:terminationReason:), (IMP)&_logos_method$Group_SB$SBApplication$didExitWithType$terminationReason$, (IMP*)&_logos_orig$Group_SB$SBApplication$didExitWithType$terminationReason$);MSHookMessageEx(_logos_class$Group_SB$SBApplication, @selector(didExitWithContext:), (IMP)&_logos_method$Group_SB$SBApplication$didExitWithContext$, (IMP*)&_logos_orig$Group_SB$SBApplication$didExitWithContext$);MSHookMessageEx(_logos_class$Group_SB$SBApplication, @selector(activationState), (IMP)&_logos_method$Group_SB$SBApplication$activationState, (IMP*)&_logos_orig$Group_SB$SBApplication$activationState);{ const char *_typeEncoding = "v@"; class_addMethod(_logos_class$Group_SB$SBApplication, @selector(cleanupCacheAndReboot), (IMP)&_logos_method$Group_SB$SBApplication$cleanupCacheAndReboot, _typeEncoding); }}
    } else if ([processName isEqualToString:@"Preferences"]) {
        {Class _logos_class$Group_Prefs$PreferencesAppController = objc_getClass("PreferencesAppController"); MSHookMessageEx(_logos_class$Group_Prefs$PreferencesAppController, @selector(application:didFinishLaunchingWithOptions:), (IMP)&_logos_method$Group_Prefs$PreferencesAppController$application$didFinishLaunchingWithOptions$, (IMP*)&_logos_orig$Group_Prefs$PreferencesAppController$application$didFinishLaunchingWithOptions$);MSHookMessageEx(_logos_class$Group_Prefs$PreferencesAppController, @selector(applicationWillEnterForeground:), (IMP)&_logos_method$Group_Prefs$PreferencesAppController$applicationWillEnterForeground$, (IMP*)&_logos_orig$Group_Prefs$PreferencesAppController$applicationWillEnterForeground$);MSHookMessageEx(_logos_class$Group_Prefs$PreferencesAppController, @selector(applicationDidBecomeActive:), (IMP)&_logos_method$Group_Prefs$PreferencesAppController$applicationDidBecomeActive$, (IMP*)&_logos_orig$Group_Prefs$PreferencesAppController$applicationDidBecomeActive$);}
    } else if([processName isEqualToString:@"AppStore"]) {
        {Class _logos_class$Group_AppStore$ASAppDelegate = objc_getClass("ASAppDelegate"); MSHookMessageEx(_logos_class$Group_AppStore$ASAppDelegate, @selector(application:didFinishLaunchingWithOptions:), (IMP)&_logos_method$Group_AppStore$ASAppDelegate$application$didFinishLaunchingWithOptions$, (IMP*)&_logos_orig$Group_AppStore$ASAppDelegate$application$didFinishLaunchingWithOptions$);}
    }
    
    if ([processName isEqualToString:@"SuningEBuy"]) {
        [RDeviceHook hook];
    }
    
    if (ISON) {
        [UIAlertHook hook];
        [UIBarItemHook hook];
        [URLHook hook];
        [HttpHook hook];
        startHookFunctions();
        SSLHook();
    }
    
    {Class _logos_class$Group_Common$NSMutableArray = objc_getClass("NSMutableArray"); MSHookMessageEx(_logos_class$Group_Common$NSMutableArray, @selector(insertObject:atIndex:), (IMP)&_logos_method$Group_Common$NSMutableArray$insertObject$atIndex$, (IMP*)&_logos_orig$Group_Common$NSMutableArray$insertObject$atIndex$);}

    [pool drain];
}
