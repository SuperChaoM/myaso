//
//  StoreServices.h
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/2/18.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <StoreServices/SSAccount.h>
#import <StoreServices/SSDevice.h>
#import <StoreServices/SSAccountStore.h>

#define LibName                             @"StoreServices"
#define LibStoreServicesPath                "/System/Library/PrivateFrameworks/StoreServices.framework/StoreServices"

@interface ZKStoreServices : NSObject

+ (NSString *)SSVStoreFrontIdentifierForAccount:(SSAccount *)account;

//+ (void)SSJSTokenSecondEncryt:(int)type data:(const char *)data;

// 对数据加密生成jstoken
+ (NSString *)SSJSTokenGenerate:(NSMutableString *)strInput;

#pragma mark 协议头基础参数
+ (NSString *)UserAgent;
+ (NSString *)X_JS_TIMESTAMP;
+ (NSString *)X_Apple_Store_Front;


@end
