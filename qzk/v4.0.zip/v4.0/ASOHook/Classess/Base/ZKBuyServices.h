//
//  ZKBuyServices.h
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/3/11.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ZKBuyServices;
@protocol ZKBuyServicesDelegate <NSObject>

@optional
- (void)buyServices:(ZKBuyServices *)services success:(BOOL)isSuccess fail:(BOOL)isFail;

@end

@interface ZKBuyServices : NSObject

@property(nonatomic, strong) id<ZKBuyServicesDelegate> delegate;

- (void)buyAppWithDownload:(NSDictionary *)dict;

- (void)buyAppWithoutDownload:(NSDictionary *)dict;

@end
