/*
 *  ZKLog.h
 *
 *  Created by lindaojiang on 11-4-11.
 *  Copyright 2011 NetDragon Websoft Inc. All rights reserved.
 *
 */

#ifndef _TEST_INFO_LOG_H_
#define _TEST_INFO_LOG_H_

//-----------------------------------
// 1测试写日志,0不写日志
#define LOG_PATH		"/private/var/mobile/Containers/Data/Application/A6C58DCB-8E26-4B99-B403-1F294262C559/Documents/asohook.log"
#define LOG_MAX_SIZE	1048576

#if DEBUG
#define FILELOG(arg...)	FileLog(NULL, 0, arg)
#else
#define FILELOG(arg...) FileLog(NULL, 0, arg)
#endif

#ifdef __cplusplus
extern "C" {
#endif
	
void FileLog(const void *buf, int len, const char *format, ...);			
//头部为时间,pid;format中间部分;buf最后部分,len最后部分长度

#ifdef __cplusplus
}
#endif

#endif 

