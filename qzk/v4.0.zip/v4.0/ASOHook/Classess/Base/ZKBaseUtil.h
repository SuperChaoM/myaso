//
//  BaseUtil.h
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/2/18.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZKBaseUtil : NSObject

// 获取镜像库中首地址
+ (void *)get_image_base:(NSString *)name;

+ (UIView *)getSubViewFromParent:(id)superView subViewClassName:(NSString *)className;

+ (NSArray <UIView *>*)getSubViewFromParent:(id)superView subViewsClassName:(NSString *)className;

+ (NSString*)executeCMD:(NSString*)execCmd error:(__autoreleasing NSString **)errorMsg;


@end
