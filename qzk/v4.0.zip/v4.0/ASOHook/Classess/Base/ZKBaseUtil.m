//
//  BaseUtil.m
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/2/18.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import "ZKBaseUtil.h"
#import "NSTask.h"
#import <mach-o/dyld.h>

@implementation ZKBaseUtil

+ (void *)get_image_base:(NSString *)name
{
    for( int i=0; i< _dyld_image_count();i++)
    {
        //NSLog(@"[0x%08X][%s]",_dyld_get_image_header(i), _dyld_get_image_name(i));
        if (strstr(_dyld_get_image_name(i), name.UTF8String))
        {
            void *address = (void *)_dyld_get_image_header(i);
            return address;
        }
    }
    return NULL;
}

+ (UIView *)getSubViewFromParent:(id)superView subViewClassName:(NSString *)className {
    for (UIView *view in ((UIView *)superView).subviews) {
        if ([view isKindOfClass:NSClassFromString(className)]) {
            return view;
        }
    }
    
    return nil;
}

+ (NSArray <UIView *>*)getSubViewFromParent:(id)superView subViewsClassName:(NSString *)className {
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    for (UIView *view in ((UIView *)superView).subviews) {
        if ([view isKindOfClass:NSClassFromString(className)]) {
            [arr addObject:view];
        }
    }
    
    return arr;
}

+ (NSString*)executeCMD:(NSString*)execCmd error:(__autoreleasing NSString **)errorMsg
{
    //iOS9无法使用
    if (SYSTEM_VERSION_GREATER_THAN(NSFoundationVersionNumber_iOS_8_x_Max)) {
//        if (errorMsg) {
//            *errorMsg = @"iOS9 error";
//        }
//        return @"iOS9 error";
        system([execCmd UTF8String]);
        return @"";
    }
    NSTask *task = [[NSTask alloc]init];
    
    NSPipe *readPipe = [NSPipe pipe];
    NSFileHandle *readHandle = [readPipe fileHandleForReading];
    NSPipe *writePipe = [NSPipe pipe];
    NSPipe *errorPipe = [NSPipe pipe];
    NSFileHandle *errorHandle = [errorPipe fileHandleForReading];
    
    [task setStandardError:errorPipe];
    [task setStandardInput:writePipe];
    [task setStandardOutput:readPipe];
    
    
    [task setLaunchPath:@"/bin/su"];
    
    NSArray *arguments = [NSArray arrayWithObjects:@"root", @"-c", execCmd, nil];
    [task setArguments:arguments];
    
    [task launch];
    
    NSFileHandle *writeFileHandle = [writePipe fileHandleForWriting];
    [writeFileHandle writeData:[@"alpine" dataUsingEncoding:NSASCIIStringEncoding]];
    [writeFileHandle closeFile];
    
    NSMutableData *data = [[NSMutableData alloc] init];
    NSData *readData;
    NSData *error;
    NSMutableData *errorData = [[NSMutableData alloc] init];
    
    while ((readData = [readHandle availableData])
           && [readData length]) {
        [data appendData: readData];
    }
    [readHandle closeFile];
    NSString *result = @"";
    result = [[NSString alloc]
              initWithData:data
              encoding: NSASCIIStringEncoding];

    while ((error = [errorHandle availableData])
           && [error length]) {
        [errorData appendData: error];
    }
    [errorHandle closeFile];
    
    if (errorMsg) {
        *errorMsg = [[NSString alloc]
                     initWithData:errorData
                     encoding: NSASCIIStringEncoding];
    }
    return result;
}

@end
