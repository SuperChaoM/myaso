/*
 *  ZKLog.c
 *
 *  Created by lindaojiang on 11-4-11.
 *  Copyright 2011 NetDragon Websoft Inc. All rights reserved.
 *
 */

#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>

#include "ZKLog.h"

void FileLog(const void *buf, int len, const char *format, ...)
{
	char *buffer;
	int headerLen, midLen, hd;
	struct timeval tv;
	struct tm *logTm;
	struct stat statbuf;
	va_list ap;
	FILE *fp;
	
	//测长
	if(stat(LOG_PATH, &statbuf) != -1)
	{
		if(statbuf.st_size > LOG_MAX_SIZE)
		{
			fp = fopen(LOG_PATH, "w+");
			if(fp != NULL)
				fclose(fp);
		}
	}
	else 
	{
		hd = open(LOG_PATH, O_RDWR|O_CREAT, S_IRWXU|S_IRWXG|S_IRWXO);
		if(hd != -1)
		{
			fchmod(hd, S_IRWXU|S_IRWXG|S_IRWXO);
			close(hd);
		}
		else 
			return;
	}

	gettimeofday(&tv, NULL);
	logTm = localtime(&(tv.tv_sec));
	
	//头部
	headerLen = snprintf(NULL, 0, "[%04d-%02d-%02d %02d:%02d:%02d.%06d][pid=%08d] ",
						 logTm->tm_year+1900, logTm->tm_mon+1, logTm->tm_mday, 
						 logTm->tm_hour, logTm->tm_min, logTm->tm_sec, tv.tv_usec,
						 getpid()
					  );
	
	//中部
	va_start(ap, format);
	midLen = vsnprintf(NULL, 0, format, ap);	//返回长度，不包括最后个'\0'
	va_end(ap);
	
	buffer = (char *)malloc(headerLen+midLen+len+1);
	if(buffer == NULL)
		return;
	
	//头部
	snprintf(buffer, headerLen+1, "[%04d-%02d-%02d %02d:%02d:%02d.%06d][pid=%08d] ",
			 logTm->tm_year+1900, logTm->tm_mon+1, logTm->tm_mday, 
			 logTm->tm_hour, logTm->tm_min, logTm->tm_sec, tv.tv_usec, 
			 getpid()
			 );
	
	//中部
	va_start(ap, format);
	vsnprintf(buffer+headerLen, midLen+1, format, ap);
	va_end(ap);
	
	if((buf != NULL) && (len > 0))
		memcpy(buffer+headerLen+midLen, buf, len);
	
	memcpy(buffer+headerLen+midLen+len, "\n", 1);
	
	fp = fopen(LOG_PATH, "r+");
	if(fp == NULL)
	{
		free(buffer);
		return;
	}
    fseek(fp,0,SEEK_END);
	fwrite(buffer, 1, headerLen+midLen+len+1, fp);
	fclose(fp);

	free(buffer);
}



