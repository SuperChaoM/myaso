//
//  ZKBuyServices.m
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/3/11.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import "ZKBuyServices.h"

//购买应用
#import <StoreServices/SSPurchaseRequest.h>
#import <StoreServices/SSPurchase.h>
#import <StoreServices/SSPurchaseResponse.h>
#import <StoreServices/SSURLConnectionResponse.h>


@implementation ZKBuyServices

- (void)buyAppWithDownload:(NSDictionary *)dict {
    SSPurchase *purchase = [[SSPurchase alloc] init];
    
    NSString *buyParams = [[[dict valueForKey:@"offers"] valueForKey:@"buyParams"] firstObject];
    
    //纪录下载的应用是从何处何来：（搜索，精品推荐，排行榜等)
    buyParams = [buyParams stringByAppendingString:[NSString stringWithFormat:@"&origName=%@", [dict objectForKey:@"origName"]]];
    purchase.buyParameters = buyParams; //offers->buyParams
    purchase.expectedDownloadFileSize = 0; //断点续传大小？
    purchase.requiredDeviceCapabilities = nil;
    purchase.usesLocalRedownloadParametersIfPossible = YES;
    purchase.createsDownloads = NO;
    
    [purchase setValue:@"software" forDownloadProperty:@"1"];
    [purchase setValue:[dict valueForKey:@"name"] forDownloadProperty:@"2"]; //name or nameRaw
    [purchase setValue:[dict valueForKey:@"id"] forDownloadProperty:@"7"]; //id,而不是artisId
    //    [purchase setValue:[info valueForKey:@"hasInAppPurchases"] forDownloadProperty:@"21"]; //hasInAppPurchases?
    [purchase setValue:[NSNumber numberWithBool:YES] forDownloadProperty:@"21"]; //hasInAppPurchases?
    NSString *iconUrl;
    NSArray *artwork = [dict valueForKey:@"artwork"];
    for (NSDictionary *artDict in artwork) {
        NSNumber *height = [artDict valueForKey:@"height"];
        NSNumber *width = [artDict valueForKey:@"width"];
        if ([height intValue] == 134  && [width intValue] == 134) {
            iconUrl = [artDict valueForKey:@"url"];
            break;
        }
    }
    NSLog(@"iconUrl = %@",iconUrl);
    
    [purchase setValue:[dict valueForKey:@"bundleId"] forDownloadProperty:@"c"]; //bundleId
    [purchase setValue:[dict valueForKey:@"artistName"] forDownloadProperty:@"d"]; //artistName
    [purchase setValue:[NSURL URLWithString:iconUrl] forDownloadProperty:@"G"]; //artwork数组中构造一个,因为没有看到134x134的icon

    SSPurchaseRequest *purchaseRequest = [[SSPurchaseRequest alloc] initWithPurchases:[NSMutableArray arrayWithObjects:purchase, nil]];
    [purchaseRequest startWithPurchaseResponseBlock:^(SSPurchaseResponse *response){
//        SSURLConnectionResponse *connectionResponse = response.URLResponse;
        if (!response.error) {
            if (_delegate && [_delegate respondsToSelector:@selector(buyServices:success:fail:)]) {
                [_delegate buyServices:self success:YES fail:NO];
            }
        } else {
            if (_delegate && [_delegate respondsToSelector:@selector(buyServices:success:fail:)]) {
                [_delegate buyServices:self success:NO fail:YES];
            }
        }
    }completionBlock:nil];
}

- (void)buyAppWithoutDownload:(NSDictionary *)dict {
    
}

@end
