//
//  StoreServices.m
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/2/18.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import "ZKStoreServices.h"
#import <dlfcn.h>
#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonDigest.h>

#import "ZKBaseUtil.h"
#import "UIDevice+Common.h"

@implementation ZKStoreServices

+ (NSString *)SSVStoreFrontIdentifierForAccount:(SSAccount *)account {
    typedef NSString* (*_SSVStoreFrontIdentifierForAccount)(SSAccount *account);
    _SSVStoreFrontIdentifierForAccount ptrFunc;
    
    void *lib = dlopen(LibStoreServicesPath, RTLD_LAZY);
    if (lib) {
        ptrFunc = (_SSVStoreFrontIdentifierForAccount)dlsym(lib, "SSVStoreFrontIdentifierForAccount");
    }
    dlclose(lib);
    
    if (ptrFunc) {
        return ptrFunc(account);
    }
    
    return @"";
}

// jstoken结果跟设备信息无关
+ (NSString *)SSJSTokenGenerate:(NSString *)strInput {
    const char* szInput = [strInput UTF8String];
    if (szInput) {
        NSMutableData *destData = [[NSMutableData alloc] initWithLength:16];
        CC_SHA1(szInput, (CC_LONG)strInput.length, (unsigned char *)[destData bytes]);
        const void* destBytes = [destData bytes];
        [ZKStoreServices SSJSTokenSecondEncryt:3 data:destBytes];
        NSString *output = [destData base64EncodedStringWithOptions:0];
        return output;
    }
    return @"";
}

// 对jstoken数据进行第二重加密
+ (void)SSJSTokenSecondEncryt:(int)type data:(const char *)data {
    typedef NSString* (*_SSJSTokenSecondEncryt)(int a1, const void *a2);
    _SSJSTokenSecondEncryt ptrFunc = NULL;
    
    // jstoken第二重加密函数
    NSString *systemVer = [[UIDevice currentDevice] deviceSystemVersion];
    void *libAddress = [ZKBaseUtil get_image_base:LibName];
    IOSPlatform platform = [[UIDevice currentDevice] devicePlatform];
    if (platform == kIOSPlatform_iPhone4) {
        if ([systemVer isEqualToString:@"7.1.2"]) {
            ptrFunc = libAddress + 0x348462BC - 0x3476d000 + 0x1;
        }
    } else if (platform == kIOSPlatform_iPhone5c) {
        if ([systemVer isEqualToString:@"7.1.2"]) {
            ptrFunc = libAddress + 0x3492E0D8 - 0x34854000 + 0x1;
        } else if ([systemVer isEqualToString:@"8.0"]) {
            ptrFunc = libAddress + 0x2B49E150 - 0x2B3C4000 + 0x1;
        }else if ([systemVer isEqualToString:@"8.1"]) {
            ptrFunc = libAddress + 0x2B5450D8 - 0x2B46A000 + 0x1;
        } else if ([systemVer isEqualToString:@"8.2"]) {
            ptrFunc = libAddress + 0x2BB1CB04 - 0x2BA32000 + 0x1;
        } else if ([systemVer isEqualToString:@"8.1.3"]) {
            ptrFunc = libAddress + 0x2B5510B0 - 0x2B476000 + 0x1;
        } else if ([systemVer isEqualToString:@"8.3"]) {
            ptrFunc = libAddress + 0x2C1226B4 - 0x2C037000 + 0x1;
        } else if ([systemVer isEqualToString:@"8.4"]) {
            ptrFunc = libAddress + 0x2C4FA384 - 0x2C3CB000 + 0x1;
        }
    } else if (platform == kIOSPlatform_iPhone5s) {
        if ([systemVer isEqualToString:@"8.3"]) {
            ptrFunc = libAddress + (0x190eb58b4 - 0x190da0000);
        } else if ([systemVer isEqualToString:@"8.4"]) {
            ptrFunc = libAddress + (0x1900ba010 - 0x18ff58000);
        } else if ([systemVer isEqualToString:@"9.0"]) {
            ptrFunc = libAddress + (0x191a35984 - 0x1918d4000);
        } else if ([systemVer isEqualToString:@"9.0.1"]) {
            ptrFunc = libAddress + (0x193e0d984 - 0x193cac000);
        } else if ([systemVer isEqualToString:@"9.0.2"]) {
            ptrFunc = libAddress + (0x1948b5900 - 0x194754000);
        } else if ([systemVer isEqualToString:@"9.1"]) {
            ptrFunc = libAddress + (0x1922966c4 - 0x192134000);
        } else if ([systemVer isEqualToString:@"9.2"]) {
            ptrFunc = libAddress + (0x1855533f0 - 0x1853f0000);
        } else if ([systemVer isEqualToString:@"9.2.1"]) {
            ptrFunc = libAddress + (0x1855ef3f0 - 0x18548c000);
        } else if ([systemVer isEqualToString:@"9.3"]) {
            ptrFunc = libAddress + (0x184df7d84 - 0x184c8c000);
        } else if ([systemVer isEqualToString:@"9.3.1"]) {
            ptrFunc = libAddress + (0x187cdbd84 - 0x187b70000);
        } else if ([systemVer isEqualToString:@"9.3.2"]) {
            ptrFunc = libAddress + (0x184e0bbf0 - 0x184ca0000);
        } else if ([systemVer isEqualToString:@"9.3.3"]) {
            ptrFunc = libAddress + (0x186ca7bb4 - 0x186b3c000);
        }
    }
    
    if (ptrFunc) {
        (*ptrFunc)(type, data);
    } else {
        NSLog(@"版本:%@ JSToken未适配", systemVer);
    }
}

#pragma mark 协议头基础参数
+ (NSString *)UserAgent {
    // User-Agent
    SSDevice *device = [SSDevice currentDevice];
    NSString *userAgent = [device userAgentWithClientName:@"AppStore" version:@"2.0"];
    return userAgent;
}

+ (NSString *)X_JS_TIMESTAMP {
    NSString *timestamp = [NSString stringWithFormat:@"%.0f", [[NSDate date] timeIntervalSince1970]];
    return timestamp;
}

+ (NSString *)X_Apple_Store_Front {
    // X-Apple-Store-Front
    NSString *storeFront;
    SSAccountStore *accountStore = [SSAccountStore defaultStore];
    SSAccount *account = accountStore.activeAccount;
    NSString *tmpStr =  [ZKStoreServices SSVStoreFrontIdentifierForAccount:account];
    storeFront = [NSString stringWithFormat:@"%@", tmpStr];  // @"%@ t:native"
    
    return storeFront;
}

@end
