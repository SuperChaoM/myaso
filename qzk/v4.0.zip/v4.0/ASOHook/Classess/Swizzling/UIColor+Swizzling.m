//
//  UIColor+Swizzling.m
//  ASOHook
//
//  Created by 邱智铠 on 2018/3/14.
//
//

#import "UIColor+Swizzling.h"

void xzRedColorIMP(id self, SEL _cmd) {
    NSLog(@"##### xzRedColorIMP");
}

@implementation UIColor (Swizzling)

+ (BOOL)resolveClassMethod:(SEL)sel {
    NSLog(@"##### 111 %@", NSStringFromSelector(sel));
    Method method;
    IMP imp;
    if ([NSStringFromSelector(sel) isEqualToString:@"xzRedColor"]) {
        method = class_getClassMethod(object_getClass(self), @selector(xzRedColorIMP));
        imp = method_getImplementation(method);
        class_addMethod(object_getClass(self), sel, imp, "v@:");
        return YES;
    } else if ([NSStringFromSelector(sel) isEqualToString:@"xzMainTextColor"]) {
        method = class_getClassMethod(object_getClass(self), @selector(xzMainTextColorIMP));
        imp = method_getImplementation(method);
        class_addMethod(object_getClass(self), sel, imp, "v@:");
        return YES;
    }

    return [super resolveClassMethod:sel];
}

+ (UIColor *)xzRedColorIMP {
    return [UIColor redColor];
}

+ (UIColor *)xzMainTextColorIMP {
    return [UIColor blackColor];
}

@end
