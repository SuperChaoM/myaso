//
//  YDFormDataRequest.m
//  QianKaTest
//
//  Created by sss on 2017/7/24.
//  Copyright © 2017年 sss@yunduo.com. All rights reserved.
//

#import "YDFormDataRequest.h"
#import "HMDataSafeParser.h"

@implementation YDFormDataRequest

- (id)initWithURL:(NSString *)newURL {
    self = [super init];
    if (self) {
        _stringEncoding = NSUTF8StringEncoding;
        _request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:newURL]];
        [_request setHTTPMethod:@"POST"];
        [_request setTimeoutInterval:15.0];
    }
    return self;
}

#pragma mark utilities

- (void)addPostValue:(id <NSObject>)value forKey:(NSString *)key {
    if (!key) {
        return;
    }
    if (![self postData]) {
        [self setPostData:[NSMutableArray array]];
    }
    
    NSMutableDictionary *keyValuePair = [NSMutableDictionary dictionaryWithCapacity:2];
    [keyValuePair setStringValue:key forKey:@"key"];
    [keyValuePair setStringValue:[value description] forKey:@"value"];
    [[self postData] addObjectValue:keyValuePair];
}

- (void)setPostValue:(id <NSObject>)value forKey:(NSString *)key {
    // Remove any existing value
    NSUInteger i;
    for (i=0; i<[[self postData] count]; i++) {
        NSDictionary *val = [[self postData] dictValueAtIndex:i];
        if ([[val stringValueForKey:@"key"] isEqualToString:key]) {
            [[self postData] removeObjectAtIndex:i];
            i--;
        }
    }
    [self addPostValue:value forKey:key];
}

- (void)addRequestHeader:(NSString *)header value:(NSString *)value {
    if (!isNullOrEmptyString(header) && value) {
        [_request setValue:value forHTTPHeaderField:header];
    }
}

- (void)appendPostString:(NSString *)string {
    [self appendPostData:[string dataUsingEncoding:[self stringEncoding]]];
}

- (void)appendPostData:(NSData *)data {
    if ([data length] == 0) {
        return;
    }

    if (![self postBody]) {
        [self setPostBody:[NSMutableData data]];
    }
    [[self postBody] appendData:data];
}

- (void)addData:(id)data withFileName:(NSString *)fileName andContentType:(NSString *)contentType forKey:(NSString *)key
{
    if (![self fileData]) {
        [self setFileData:[NSMutableArray array]];
    }
    
    if (!contentType) {
        contentType = @"application/octet-stream";
    }
    
    NSMutableDictionary *fileInfo = [NSMutableDictionary dictionaryWithCapacity:4];
    [fileInfo setStringValue:key forKey:@"key"];
    [fileInfo setStringValue:fileName forKey:@"fileName"];
    [fileInfo setStringValue:contentType forKey:@"contentType"];
    [fileInfo setObjectValue:data forKey:@"data"];
    
    [[self fileData] addObjectValue:fileInfo];
}

- (void)buildMultipartFormDataPostBody {
    
    NSString *charset = (NSString *)CFStringConvertEncodingToIANACharSetName(CFStringConvertNSStringEncodingToEncoding([self stringEncoding]));
    
    // We don't bother to check if post data contains the boundary, since it's pretty unlikely that it does.
    CFUUIDRef uuid = CFUUIDCreate(nil);
    NSString *uuidString = (NSString*)CFBridgingRelease(CFUUIDCreateString(nil, uuid));
    CFRelease(uuid);
    NSString *stringBoundary = [NSString stringWithFormat:@"0xKhTmLbOuNdArY-%@",uuidString];
    
    [self addRequestHeader:@"Content-Type" value:[NSString stringWithFormat:@"multipart/form-data; charset=%@; boundary=%@", charset, stringBoundary]];
    
    [self appendPostString:[NSString stringWithFormat:@"--%@\r\n", stringBoundary]];
    
    // Adds post data
    NSString *endItemBoundary = [NSString stringWithFormat:@"\r\n--%@\r\n", stringBoundary];
    NSUInteger i=0;
    for (NSDictionary *val in [self postData]) {
        [self appendPostString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", [val stringValueForKey:@"key"]]];
        [self appendPostString:[val stringValueForKey:@"value"]];
        i++;
        if (i != [[self postData] count] || [[self fileData] count] > 0) { //Only add the boundary if this is not the last item in the post body
            [self appendPostString:endItemBoundary];
        }
    }
    
    // Adds files to upload
    i=0;
    for (NSDictionary *val in [self fileData]) {
        
        [self appendPostString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n",
                                [val stringValueForKey:@"key"], [val stringValueForKey:@"fileName"]]];
        [self appendPostString:[NSString stringWithFormat:@"Content-Type: %@\r\n\r\n", [val stringValueForKey:@"contentType"]]];
        
        id data = [val objectValueForKey:@"data" verifyClass:[NSData class]];
        if ([data isKindOfClass:[NSData class]]) {
            [self appendPostData:data];
        }
        
        i++;
        // Only add the boundary if this is not the last item in the post body
        if (i != [[self fileData] count]) {
            [self appendPostString:endItemBoundary];
        }
    }
    
    [self appendPostString:[NSString stringWithFormat:@"\r\n--%@--\r\n",stringBoundary]];
    
    [_request setHTTPBody:self.postBody];
    unsigned long long postLength = [[self postBody] length];
    [self addRequestHeader:@"Content-Length" value:[NSString stringWithFormat:@"%llu", postLength]];
}

- (void)sendDataPostRequestWithCompletionHandler:(void (^)(NSString *response, NSError *connectionError)) handler {
    
    [self buildMultipartFormDataPostBody];
    
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:_request queue:queue completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        
        NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        handler(responseString, connectionError);
        
    }];
}

@end
