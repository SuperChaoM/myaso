//
//  YDFormDataRequest.h
//  QianKaTest
//
//  Created by sss on 2017/7/24.
//  Copyright © 2017年 sss@yunduo.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDFormDataRequest : NSURLConnection

@property (nonatomic, strong) NSMutableURLRequest *request;
@property (nonatomic, strong) NSOperationQueue *queue;

@property (nonatomic, strong) NSMutableData *postBody;
@property (nonatomic, strong) NSMutableArray *postData;
@property (nonatomic, strong) NSMutableArray *fileData;
@property (nonatomic, assign) NSStringEncoding stringEncoding;

- (id)initWithURL:(NSString *)newURL;

- (void)addPostValue:(id <NSObject>)value forKey:(NSString *)key;

- (void)setPostValue:(id <NSObject>)value forKey:(NSString *)key;

- (void)addData:(id)data withFileName:(NSString *)fileName andContentType:(NSString *)contentType forKey:(NSString *)key;

- (void)sendDataPostRequestWithCompletionHandler:(void (^)(NSString *response, NSError *connectionError)) handler;
@end
