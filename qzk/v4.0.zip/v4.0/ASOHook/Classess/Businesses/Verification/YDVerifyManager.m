//
//  YDVerifyManager.m
//  QianKaTest
//
//  Created by sss on 2017/7/25.
//  Copyright © 2017年 sss@yunduo.com. All rights reserved.
//

#import "YDVerifyManager.h"
#import "YDFormDataRequest.h"
#import "StringLogic.h"
#import "HMDataSafeParser.h"

@interface YDVerifyManager ()

@property (nonatomic, strong) NSMutableArray *screenshotImages;
@property (nonatomic, strong) NSMutableArray *clippingImages;
@property (nonatomic, strong) NSMutableArray *readClippingIndexs;
@end

@implementation YDVerifyManager

+ (YDVerifyManager *)sharedManager {
    static YDVerifyManager *sharedManager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[YDVerifyManager alloc] init];
    });
    return sharedManager;
}


- (instancetype)init {
    if (self = [super init]) {
        _screenshotCount = 5;
        _sleepForScreenshot = 0.3;
        _clipTargetRect = CGRectMake(65.0, 300.0, 310.0, 68.0);   // iPhone6
        _autoRetryCount = 1;
        _screenshotImages = [NSMutableArray array];
        _clippingImages = [NSMutableArray array];
        _readClippingIndexs = [NSMutableArray array];
    }
    return self;
}

- (void)autoVerifyCodeWithCompletionHandler:(void (^)(NSString *code, NSError *error))handler {
    
    [_screenshotImages removeAllObjects];
    [_clippingImages removeAllObjects];
    [_readClippingIndexs removeAllObjects];
    
    // 连续截图
    for (int i = 0; i < _screenshotCount; i++) {
        NSLog(@"Start screenshot for KeyWindow: %ld", (long)i);
        UIImage *screenshot = [self screenshot4KeyWindow];
        [_screenshotImages addObjectValue:screenshot];
        
//        NSData *imageData = UIImageJPEGRepresentation(screenshot, kVerifyImageCompressionQuality);
//        NSString *imageEncode = [StringLogic base64EncodeData:imageData];
//        NSLog(@"全屏截屏数据：\n%@", imageEncode);
        [NSThread sleepForTimeInterval:_sleepForScreenshot];    // 暂停300毫秒
    }
    
    // 裁剪验证码区域
    for (UIImage *screenshotImg in _screenshotImages) {
        UIImage *clipImage = [self clipImageFromImage:screenshotImg inRect:_clipTargetRect];
        [_clippingImages addObjectValue:clipImage];
    }
    
    // 压缩图片上传
    while (_readClippingIndexs.count < _autoRetryCount + 1 && _readClippingIndexs.count <= _clippingImages.count) {
        NSInteger randomIndex = arc4random() % _clippingImages.count;
        if (![_readClippingIndexs containsObject:@(randomIndex)]) {
            [_readClippingIndexs addObjectValue:@(randomIndex)];
        }
    }
    
    [self readVerifyCodeAutoRetryWithCompletionHandler:handler];
}

- (void)readVerifyCodeAutoRetryWithCompletionHandler:(void (^)(NSString *code, NSError *error))handler {
    
    if (_autoRetryCount > 0 && _readClippingIndexs.count == 0) {
        // 已达到最大重试次数
        NSError *error = [NSError errorWithDomain:@"verify.aso.yunduo"
                                             code:9999
                                         userInfo:@{NSLocalizedDescriptionKey:@"Reached maximum retry count!!!"}];
        handler(nil, error);
        return;
    }
    
    NSUInteger targetIndex = [[_readClippingIndexs lastObject] integerValue];
    UIImage *targetImage = [_clippingImages objectValueAtIndex:targetIndex];
    [_readClippingIndexs removeLastObject];
    
    //图片解码：http://www.vgot.net/test/image2base64.php
//    NSData *imageData = UIImageJPEGRepresentation(targetImage, kVerifyImageCompressionQuality);
//    NSString *imageEncode = [StringLogic base64EncodeData:imageData];
//    NSLog(@"验证码图片数据：\n%@", imageEncode);
    
    __weak __typeof(self)weakSelf = self;
    [self readVerifyCodeFromImage:targetImage completionHandler:^(NSString *code, NSError *error) {
        NSLog(@"Read verify code: %@, error: %@", code, error);
        if ([code length] == kVerifyImageCodeLengthDefault && [code integerValue] != 0 && error == nil) {
            NSLog(@"Read verify code: %ld valid!!!", (long)[code integerValue]);
            handler(code, nil);
            [weakSelf reportVerifyImages:weakSelf.clippingImages withCode:code];
        } else {
            handler(nil, error);
            [weakSelf readVerifyCodeAutoRetryWithCompletionHandler:handler];
        }
    }];
}

- (UIImage *)screenshot4KeyWindow {
    UIWindow *screenWindow = [[UIApplication sharedApplication] keyWindow];
    UIGraphicsBeginImageContextWithOptions(screenWindow.frame.size, NO, 0.0);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSaveGState(context);
    for (UIWindow *window in [[UIApplication sharedApplication] windows]) {
        if(window == screenWindow) {
            break;
        } else {
            [window.layer renderInContext:context];
        }
    }
    
    if ([screenWindow respondsToSelector:@selector(drawViewHierarchyInRect:afterScreenUpdates:)]) {
        [screenWindow drawViewHierarchyInRect:screenWindow.bounds afterScreenUpdates:YES];
    } else {
        [screenWindow.layer renderInContext:context];
    }
    CGContextRestoreGState(context);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    screenWindow.layer.contents = nil;
    UIGraphicsEndImageContext();
    
    return image;
}

- (UIImage *)clipImageFromImage:(UIImage *)image inRect:(CGRect)rect {
    
    CGFloat scaleValue = image.scale;
    CGRect scaledRect = CGRectMake(rect.origin.x * scaleValue,
                                   rect.origin.y * scaleValue,
                                   rect.size.width * scaleValue,
                                   rect.size.height * scaleValue);
    //截取部分图片并生成新图片
    CGImageRef sourceImageRef = [image CGImage];
    CGImageRef newImageRef = CGImageCreateWithImageInRect(sourceImageRef, scaledRect);
    UIImage *newImage = [UIImage imageWithCGImage:newImageRef
                                            scale:scaleValue
                                      orientation:UIImageOrientationUp];
    return newImage;
}

- (void)readVerifyCodeFromImage:(UIImage *)image completionHandler:(void (^)(NSString *code, NSError *error))handler
{
    if (image == nil) {
        NSLog(@"Function (%@) param is invalid", NSStringFromSelector(_cmd));
        return;
    }
    
    YDFormDataRequest *dataRequest = [[YDFormDataRequest alloc] initWithURL:@"http://api.ruokuai.com/create.json"];
    [dataRequest addPostValue:@"labixiaoxinxin" forKey:@"username"];
    [dataRequest addPostValue:[StringLogic MD5With32BitUpper:@"11235813"] forKey:@"password"];
    [dataRequest addPostValue:@"1030" forKey:@"typeid"];
    [dataRequest addPostValue:@"60" forKey:@"timeout"];
    [dataRequest addPostValue:@"85483" forKey:@"softid"];
    [dataRequest addPostValue:@"4bcd3b04b0f84745bfda377fd25b17c8" forKey:@"softkey"];
    
    NSData *data = UIImageJPEGRepresentation(image, kVerifyImageCompressionQuality);
    if (!data) {
        data = UIImagePNGRepresentation(image);
        [dataRequest addData:data withFileName:@"yzmImage" andContentType:@"png" forKey:@"image"];
    } else {
        [dataRequest addData:data withFileName:@"yzmImage" andContentType:@"JPEG" forKey:@"image"];
    }
    
    [dataRequest sendDataPostRequestWithCompletionHandler:^(NSString *response, NSError *connectionError) {
        NSLog(@"Verify code response: %@", response);
        
        //若快平台返回结果示例
        //{"Result":"806","Id":"27859297-3ca2-4d11-b19f-0f1382349789"}
        //{"Error":"用户名或密码不能为空.","Error_Code":"10101","Request":""}
        //{"Error":"multipart格式有误,请检查POST multipart/form-data数据格式。multipart: NextPart: EOF","Error_Code":"10601","Request":""}
        
        NSDictionary *result = [HMDataSafeParser dictionaryValue:response];
        if (result && !connectionError) {
            NSString *resultCode = [result stringValueForKey:@"Result"];
            NSString *resultId = [result stringValueForKey:@"Id"];
            if (!isNullOrEmptyString(resultCode)) {
                NSLog(@"Verify code: %@, ID: %@", resultCode, resultId);
                handler(resultCode, nil);
            } else {
                // 第三方平台返回的错误类型
                NSString *errorDes = [result stringValueForKey:@"Error"];
                NSString *errorCode = [result stringValueForKey:@"Error_Code"];
                NSLog(@"Verify error: %@, %@", errorCode, errorDes);
                NSError *error = [NSError errorWithDomain:@"verify.aso.yunduo"
                                                     code:[errorCode integerValue]
                                                 userInfo:@{NSLocalizedDescriptionKey:errorDes}];
                handler(nil, error);
            }
        } else {
            // 请求错误，或者返回数据错误
            handler(nil, connectionError);
        }
    }];
}

- (void)reportVerifyImages:(NSArray *)images withCode:(NSString *)code {
    
    if (isNullOrEmptyString(code) || [images count] == 0) {
        NSLog(@"Function (%@) param is invalid", NSStringFromSelector(_cmd));
        return;
    }
    
    NSString *URLString = @"http://www.iosapples.com/ImageHandler.ashx?act=uploadimg";
    
    NSMutableDictionary *verifyInfo = [NSMutableDictionary dictionary];
    NSMutableArray *imageArray = [NSMutableArray array];
    for (UIImage *img in images) {
        NSData *imageData = UIImageJPEGRepresentation(img, kVerifyImageCompressionQuality);
        NSString *imageEncode = [StringLogic base64EncodeData:imageData];
        [imageArray addStringValue:imageEncode];
    }
    [verifyInfo setObjectValue:imageArray forKey:code];
    NSString *verifyJSON = [HMDataSafeParser JSONRepresentationWithObject:verifyInfo];
    
    NSLog(@"##### [验证码] 收集：%@", URLString);
    NSURL *url = [NSURL URLWithString:URLString];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[verifyJSON dataUsingEncoding:NSUTF8StringEncoding]];
    NSOperationQueue *queue= [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        
        NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"Report verify response: %@", responseString);
        NSDictionary *dict = [HMDataSafeParser dictionaryValue:responseString];
        if ([dict isKindOfClass:[NSDictionary class]]) {
            BOOL bRet = [[dict valueForKey:@"Code"] intValue] == 1;
            NSLog(@"##### [验证码] 收集%@ #####", bRet ? @"成功" : [NSString stringWithFormat:@"失败, response:%@", responseString]);
        } else {
            NSLog(@"##### [验证码] 收集失败 response:%@ #####", responseString);
        }
    }];
}

@end
