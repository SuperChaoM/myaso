//
//  YDVerifyManager.h
//  QianKaTest
//
//  Created by sss on 2017/7/25.
//  Copyright © 2017年 sss@yunduo.com. All rights reserved.
//

#import <UIKit/UIkit.h>

#define kVerifyImageCompressionQuality      0.7     // JPEG图片压缩系数
#define kVerifyImageCodeLengthDefault       3       // 验证码数据默认长度

@interface YDVerifyManager : NSObject

@property (nonatomic, assign) NSInteger screenshotCount;            // 截屏数量
@property (nonatomic, assign) NSTimeInterval sleepForScreenshot;    // 连续截图时间间隔（默认：0.3s）

@property (nonatomic, assign) CGRect clipTargetRect;                // 切图的目标区域
@property (nonatomic, assign) NSInteger autoRetryCount;             // 自动识别重试次数（默认：1）

+ (YDVerifyManager *)sharedManager;

// 验证码自动识别
- (void)autoVerifyCodeWithCompletionHandler:(void (^)(NSString *code, NSError *error))handler;

// 获取当前屏幕截图
- (UIImage *)screenshot4KeyWindow;

// 截取指定范围的图片
- (UIImage *)clipImageFromImage:(UIImage *)image inRect:(CGRect)rect;

// 从第三平台解析验证码
- (void)readVerifyCodeFromImage:(UIImage *)image completionHandler:(void (^)(NSString *code, NSError *error))handler;

// 验证码结果样本收集
- (void)reportVerifyImages:(NSArray *)images withCode:(NSString *)code;
@end
