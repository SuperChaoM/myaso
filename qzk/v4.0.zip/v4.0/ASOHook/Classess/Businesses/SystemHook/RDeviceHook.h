//
//  RDeviceHook.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/7/31.
//
//

#import <Foundation/Foundation.h>

@interface RDeviceHook : NSObject

+ (void)hook;

@end
