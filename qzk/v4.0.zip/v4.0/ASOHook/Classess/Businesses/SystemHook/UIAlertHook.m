//
//  UIAlert+Hook.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/29.
//
//

#import "UIAlertHook.h"
#import "CfgManager.h"
#import "TaskManager.h"
#import "AppManager.h"

@implementation UIAlertHook

+ (void)hook {
    exchangeMethod([UIAlertView class],
                   @selector(popupAlertAnimated:),
                   @selector(hook_popupAlertAnimated:));
    
    exchangeMethod([UIAlertController class],
                   @selector(viewDidAppear:),
                   @selector(hook_viewDidAppear:));
}

@end

#pragma mark - UIAlertView

@implementation UIAlertView (Hook)

- (void)hook_popupAlertAnimated:(BOOL)animated {
    [self hook_popupAlertAnimated:animated];
    
    UIWindow *win = [[UIApplication sharedApplication] keyWindow];
    UIAlertController *alertVc = (UIAlertController *)[win.rootViewController presentedViewController];
    UIAlertAction *alertAction = nil;
    
    NSString *title = [alertVc performSelector:NSSelectorFromString(@"title")];
    NSLog(@"==> 关闭弹窗View title = %@, message = %@ <==", title, alertVc.message);
    
    if ([title isEqualToString:@"可能不支持此配件。"] ||
        [title isEqualToString:@"无法下载应用程序"] ||
        [title isEqualToString:@"低电量模式"] ||
        [title isEqualToString:@"存储容量几乎已满"] ||
        [title isEqualToString:@"无法使用此 Apple ID 进行更新"] ||
        [title isEqualToString:@"使用推送通知来连接 iTunes"] ||
        [title isEqualToString:@"The iTunes Store is unable to process purchases at this time."] ||
        [title isEqualToString:@"若不希望被询问是否加入 Wi-Fi 网络，请在 Wi-Fi 设置中关闭此功能。"] ||
        [title containsString:@"“App Store”想要打开"] ||
        [title containsString:@"访问您的位置"]) {
        alertAction = alertVc.actions[0];
    } else if ([title containsString:@"想给您发送推送通知"] ||
               [title isEqualToString:@"您必须同时输入 Apple ID 和密码。"]) {
        alertAction = alertVc.actions[1];
    }
    
    if (alertAction) {
        [alertVc performSelector:@selector(_dismissAnimated:triggeringAction:)
                      withObject:@YES
                      withObject:alertAction];
    }
}

@end

#pragma mark - UIAlertController

@implementation UIAlertController (Hook)

- (void)hook_viewDidAppear:(BOOL)animated {
    [self hook_viewDidAppear:animated];
    
    NSString *title = [self performSelector:NSSelectorFromString(@"title")];
    NSString *message = [self performSelector:NSSelectorFromString(@"message")];
    NSArray *actions = [self performSelector:NSSelectorFromString(@"actions")];
    NSArray *textFields = [self performSelector:NSSelectorFromString(@"textFields")];
    NSLog(@"==> 关闭弹窗Controller title = %@, message = %@ <==", title, message);
    
    UIAlertAction *alertAction = nil;
    if ([title isEqualToString:@"未安装 SIM 卡"] ||
        [title isEqualToString:@"是否为免费项目保存密码？"] ||
        [title isEqualToString:@"要自动更新 App 吗？"] ||
        [title isEqualToString:@"表格填写不完整。"] ||
        [title isEqualToString:@"发生了 SSL 错误，无法建立与该服务器的安全连接。"] ||
        [title isEqualToString:@"请求超时。"] ||
        [title isEqualToString:@"您的帐户暂时无法使用。请稍后再试。"] ||
        [title isEqualToString:@"Update Apps Automatically?"] ||
        [title isEqualToString:@"网络连接已中断。"] ||
        [title isEqualToString:@"您的 Apple ID 或密码不正确。"] ||
        [title isEqualToString:@"未能登录"] ||
        [title isEqualToString:@"您的帐户已被禁用。"] ||
        [title isEqualToString:@"Your account is disabled."] ||
        [title isEqualToString:@"Unable to Download App"] ||
        [title isEqualToString:@"Cannot Download"] ||
        [title isEqualToString:@"要信任此电脑吗？"] ||
        [title isEqualToString:@"无法购买"] ||
        [title isEqualToString:@"编辑主屏幕"] ||
        [title isEqualToString:@"无法下载应用"] ||
        [title isEqualToString:@"出错了"] ||
        [title isEqualToString:@"软件更新"] ||
        [title isEqualToString:@"电池电量不足"] ||
        [title isEqualToString:@"储存空间几乎已满"] ||
        [title isEqualToString:@"输入错误次数过多"] ||
        [title isEqualToString:@"无法连接到 iTunes Store"] ||
        [title isEqualToString:@"登录以启用“自动下载”"] ||
        [title isEqualToString:@"开启“定位服务”以查看您当前位置附近的热门 App。"] ||
        [title isEqualToString:@"允许此设备访问照片和视频吗？"] ||
        [title isEqualToString:@"是否要在此设备上启用自动下载功能？"] ||
        [title isEqualToString:@"您已购买过此项目，所以现在可以免费下载，不再另外收费。"] ||
        [title isEqualToString:@"此电缆或配件尚未经过认证，因此可能无法配合此 iPhone 可靠地工作。"] ||
        [title containsString:@"可能使 iPhone 变慢"] ||
        [title containsString:@"无法下载"] ||
        [message isEqualToString:@"您从您的电脑下载了一个 App。若要在此设备上直接获得 App，请开启“自动下载”。"] ||
        [message isEqualToString:@"您从其他 iOS 设备下载了一个 App。若要在此设备上直接获得 App，请开启“自动下载”。"] ||
        [message isEqualToString:@"您从其他 iOS 设备下载了一个 App。若要在此设备上直接获得 App，请开启“自动下载的项目”。"] ||
        [message isEqualToString:@"是否开始运行脚本?"] ||
        // 中国
        [title isEqualToString:@"此 Apple ID 只能在 iTunes Store 中国店面购物。您将被转至该店面。"] ||
        [title isEqualToString:@"立即下载"] ||
        // 台湾
        [title isEqualToString:@"此 Apple ID 只可在台灣的 iTunes Store 中進行購買。系統會將您轉至該商店。"] ||
        [title isEqualToString:@"立即下載"]
        ) {
        alertAction = actions[0];
    } else if ([title isEqualToString:@"VPN 连接"]) {
        if (textFields.count >= 2) {
            ((UITextField *)textFields[1]).text = @"As142536";
            alertAction = actions[1];
        } else {
            alertAction = actions[0];
        }
    } else if ([title isEqualToString:@"您的 Apple ID 已被停用。"] ||
               //台湾
               [title isEqualToString:@"已停用您的帳號。"]
               ) {
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        [taskDict setValue:[NSString stringWithFormat:@"%d", ASCodeFailAppleIDStop] forKey:TaskKeyAccountStatus];
        NSData *data = [NSJSONSerialization dataWithJSONObject:taskDict options:NSJSONWritingPrettyPrinted error:nil];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSString *path = [CfgManager getTaskFilePath];
        [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
        
        alertAction = actions[0];
    } else if ([title isEqualToString:@"验证 Apple ID"] && [message containsString:@"打开“设置”以继续使用"]) {
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        [taskDict setValue:[NSString stringWithFormat:@"%d", ASCodeFailAppleIDNeedVerifyForSetting] forKey:TaskKeyAccountStatus];
        NSData *data = [NSJSONSerialization dataWithJSONObject:taskDict options:NSJSONWritingPrettyPrinted error:nil];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSString *path = [CfgManager getTaskFilePath];
        [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
        
        alertAction = actions[0];
    } else if ([title isEqualToString:@"需要验证"]) {
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        [taskDict setValue:[NSString stringWithFormat:@"%d", ASCodeFailAppleIDNeedVerify] forKey:TaskKeyAccountStatus];
        NSData *data = [NSJSONSerialization dataWithJSONObject:taskDict options:NSJSONWritingPrettyPrinted error:nil];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSString *path = [CfgManager getTaskFilePath];
        [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
        
    } else if ([title isEqualToString:@"Apple ID 已锁定"] ||
               [title isEqualToString:@"您的帐户已被锁定，因此无法登录"]) {
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        [taskDict setValue:[NSString stringWithFormat:@"%d", ASCodeFailAppleIDLocked] forKey:TaskKeyAccountStatus];
        NSData *data = [NSJSONSerialization dataWithJSONObject:taskDict options:NSJSONWritingPrettyPrinted error:nil];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSString *path = [CfgManager getTaskFilePath];
        [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [[AppManager defaultManager] openAppStore];
        });
        
        alertAction = actions[1];
    } else if ([title isEqualToString:@"Wi-Fi 密码不正确"]) {
        if (textFields.count == 1) {
            ((UITextField *)textFields[0]).text = @"As142536";
            alertAction = actions[1];
        } else {
            alertAction = actions[0];
        }
    } else if ([message isEqualToString:@"我们需要先进行一个简短的验证。"]) {
        if (NO) {           // 是否碰见验证码就停止
            NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
            [taskDict setValue:[NSString stringWithFormat:@"%d", ASCodeBuyNeedInputVerifyCode] forKey:TaskKeyAccountStatus];
            NSData *data = [NSJSONSerialization dataWithJSONObject:taskDict options:NSJSONWritingPrettyPrinted error:nil];
            NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSString *path = [CfgManager getTaskFilePath];
            [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
            
            alertAction = actions[0];
        } else {
            alertAction = actions[1];
        }
    } else if ([title isEqualToString:@"项目不可用"] ||
               [title isEqualToString:@"VPN 使用 PPTP 可能不安全"] ||
               [title isEqualToString:@"无法下载项目"] ||
               [title isEqualToString:@"Account Not In This Store"] ||
               [title isEqualToString:@"先前的购买存在帐单问题。"] ||
               [title containsString:@"打开“定位服务”来允许"] ||
               [title isEqualToString:@"定位服务已关闭"] ||
               [title isEqualToString:@"关闭飞行模式或使用 Wi-Fi 来访问数据"] ||
               [title isEqualToString:@"验证失败"] ||
               [title isEqualToString:@"发生未知错误。"] ||
               [title containsString:@"包含受年龄限制的内容"] ||
               [title containsString:@"想给您发送通知"] ||
               [title containsString:@"忘记了密码"] ||
               // 中国
               [message isEqualToString:@"我已阅读并同意 iTunes Store 条款与条件。"] ||
               [message isEqualToString:@"我已阅读并同意 Apple 媒体服务条款与条件。"] ||
               [title isEqualToString:@"在此设备上的其他购买是否需要密码？"] ||
               [title isEqualToString:@"Apple 媒体服务条款与条件已更改。"] ||
               // 台湾
               [title isEqualToString:@"在此裝置購買其他項目時要求輸入密碼？"] ||
               [title isEqualToString:@"Apple 媒體服務條款與約定已更改"] ||
               [message isEqualToString:@"我已閱讀並同意 Apple 媒體服務條款與約定。"]) {
        alertAction = actions[1];
    } else if ([title isEqualToString:@"登录"]) {
        alertAction = actions[actions.count - 1];
    } else if ([title isEqualToString:@"需要登录"]) {
        if (textFields.count <= 0) {
            alertAction = actions[1];
        } else if (textFields.count == 1) {
            NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
            NSString *taskAccount = [taskDict valueForKey:TaskKeyAccount];
            NSString *taskPwd = [taskDict valueForKey:TaskKeyPwd];
            if (taskAccount.length > 0 && taskPwd.length > 0) {
                ((UITextField *)textFields[0]).text = taskPwd;
                alertAction = actions[1];
            } else {
                alertAction = actions[0];
            }
        }
    } else if ([title isEqualToString:@"登录“iTunes Store”"] ||
               [title isEqualToString:@"登录 iTunes Store"] ||
               [title isEqualToString:@"需要用 Apple ID 登录"] ||
               [title isEqualToString:@"Apple ID 密码"]) {
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        NSString *taskAccount = [taskDict valueForKey:TaskKeyAccount];
        NSString *taskPwd = [taskDict valueForKey:TaskKeyPwd];
        if ([taskPwd containsString:@"$"]) {
            NSArray *arr = [taskPwd componentsSeparatedByString:@"$"];
            taskAccount = arr.count >= 1 ? arr[0] : @"";
            taskPwd = arr.count >= 2 ? arr[1] : @"";
        }
        if (textFields.count == 1) {
            if ([message rangeOfString:@"Apple ID"].location != NSNotFound) {
                NSArray *info = [message componentsSeparatedByString:@"“"];
                if ([info count] > 1) {
                    NSString *account = [info[1] componentsSeparatedByString:@"”"][0];
                    if ([account isEqualToString:taskAccount]) {
                        ((UITextField *)textFields[0]).text = taskPwd;
                        alertAction = taskPwd.length > 0 ? actions[1] : actions[0];
                    } else {
                        alertAction = actions[0];
                    }
                } else {
                    alertAction = actions[0];
                }
            } else {
                alertAction = actions[0];
            }
        } else if (textFields.count == 2) {
            if (taskAccount.length > 1 && taskAccount.length > 1) {
                ((UITextField *)textFields[0]).text = taskAccount;
                ((UITextField *)textFields[1]).text = taskPwd;
                alertAction = actions[1];
            } else {
                alertAction = actions[0];
            }
        }
    }
    
    if (alertAction) {
        [self performSelector:@selector(_dismissAnimated:triggeringAction:)
                   withObject:@YES
                   withObject:alertAction];
    }
}

@end
