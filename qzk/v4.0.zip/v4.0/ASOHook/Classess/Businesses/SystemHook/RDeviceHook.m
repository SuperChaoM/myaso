//
//  RDeviceHook.m
//  ASOHook
//
//  一键新机
//
//  Created by 邱智铠 on 2017/7/31.
//
//

#import "RDeviceHook.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>

@implementation RDeviceHook

+ (void)hook {
    exchangeMethod([UIDevice class], @selector(name), @selector(hook_name));
    exchangeMethod([UIDevice class], @selector(systemVersion), @selector(hook_systemVersion));
    exchangeMethod([UIDevice class], @selector(systemName), @selector(hook_systemName));
    exchangeMethod([UIDevice class], @selector(model), @selector(hook_model));
    exchangeMethod([UIDevice class], @selector(batteryState), @selector(hook_batteryState));
    exchangeMethod([UIDevice class], @selector(batteryLevel), @selector(hook_batteryLevel));
    
    exchangeMethod([UIScreen class], @selector(brightness), @selector(hook_brightness));
    exchangeMethod([UIScreen class], @selector(bounds), @selector(hook_bounds));
    exchangeMethod([UIScreen class], @selector(scale), @selector(hook_scale));
    
    exchangeMethod([CTTelephonyNetworkInfo class], @selector(currentRadioAccessTechnology), @selector(hook_currentRadioAccessTechnology));
    
    exchangeMethod([CTCarrier class], @selector(carrierName), @selector(hook_carrierName));
    exchangeMethod([CTCarrier class], @selector(isoCountryCode), @selector(hook_isoCountryCode));
    exchangeMethod([CTCarrier class], @selector(mobileCountryCode), @selector(hook_mobileCountryCode));
    exchangeMethod([CTCarrier class], @selector(mobileNetworkCode), @selector(hook_mobileNetworkCode));
}

@end

@implementation UIDevice (hook)

static int s_pid_UIDevice = 0;
static UIDeviceBatteryState s_batteryState = UIDeviceBatteryStateUnknown;

- (NSString *)hook_name {
    NSString *value = [self hook_name];
    NSLog(@"##### [伪装随机数据] [UIDevice name] %@ #####", value);
    return value;
}

- (NSString *)hook_systemVersion {
    NSString *value = [self hook_systemVersion];
    //NSLog(@"##### [伪装随机数据] [UIDevice systemVersion] %@ #####", value);
    return value;
}

- (NSString *)hook_systemName {
    NSString *value = [self hook_systemName];
    //NSLog(@"##### [伪装随机数据] [UIDevice systemName] %@ #####", value);
    return value;
}

- (NSString *)hook_model {
    NSString *value = [self hook_model];
    //NSLog(@"##### [伪装随机数据] [UIDevice model] %@ #####", value);
    return value;
}

- (UIDeviceBatteryState)hook_batteryState {
    if ([NSProcessInfo processInfo].processIdentifier != s_pid_UIDevice) {
        s_pid_UIDevice = [NSProcessInfo processInfo].processIdentifier;
        
        s_batteryState = arc4random() % 2 + 1;
    }
    UIDeviceBatteryState value = s_batteryState; //[self hook_batteryState];
    //NSLog(@"##### [伪装随机数据] [UIDevice batteryState] %ld #####", (long)value);
    return value;
}

- (float)hook_batteryLevel {
    float value = ((float)(arc4random() % 400000) / 1000000) + 0.4; //[self hook_batteryLevel];
    //NSLog(@"##### [伪装随机数据] [UIDevice batteryLevel] %f #####", value);
    return value;
}

@end

@implementation UIScreen (hook)

- (CGFloat)hook_brightness {
    CGFloat value = [self hook_brightness];
    NSLog(@"##### [伪装随机数据] [UIScreen brightness] %f #####", value);
    return value;
}

- (CGRect)hook_bounds {
    CGRect value = [self hook_bounds];
    //NSLog(@"##### [伪装随机数据] [UIScreen bounds] width:%f height:%f #####", value.size.width, value.size.height);
    return value;
}

- (CGFloat)hook_scale {
    CGFloat value = [self hook_scale];
    //NSLog(@"##### [伪装随机数据] [UIScreen scale] %f #####", value);
    return value;
}

@end

@implementation CTTelephonyNetworkInfo (hook)

- (NSString *)hook_currentRadioAccessTechnology {
    NSString *value = [self hook_currentRadioAccessTechnology];
    NSLog(@"##### [伪装随机数据] [CTTelephonyNetworkInfo currentRadioAccessTechnology] %@ #####", value);
    return value;
}

@end

@implementation CTCarrier (hook)

static int s_pid_CTCarrier = 0;
static NSString *s_carrierName = @"";

- (NSString *)hook_carrierName {
    if ([NSProcessInfo processInfo].processIdentifier != s_pid_CTCarrier) {
        s_pid_CTCarrier = [NSProcessInfo processInfo].processIdentifier;
        
        NSArray *carriers = @[@"中国电信", @"中国移动", @"中国联通"];
        s_carrierName = [carriers objectAtIndex:(arc4random() % 3)];
    } ;
    
    NSString *value = s_carrierName;//[self hook_carrierName];
    //NSLog(@"##### [伪装随机数据] [CTCarrier carrierName] %@ #####", value);
    return value;
}

- (NSString *)hook_isoCountryCode {
    NSString *value = [self hook_isoCountryCode];
    NSLog(@"##### [伪装随机数据] [CTCarrier isoCountryCode] %@ #####", value);
    return value;
}

- (NSString *)hook_mobileCountryCode {
    NSString *value = [self hook_mobileCountryCode];
    NSLog(@"##### [伪装随机数据] [CTCarrier mobileCountryCode] %@ #####", value);
    return value;
}

- (NSString *)hook_mobileNetworkCode {
    NSString *value = [self hook_mobileNetworkCode];
    NSLog(@"##### [伪装随机数据] [CTCarrier mobileNetworkCode] %@ #####", value);
    return value;
}

@end
