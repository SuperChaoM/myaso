//
//  UIAlert+Hook.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/29.
//
//

#import <Foundation/Foundation.h>

@interface UIAlertHook : NSObject

+ (void)hook;

@end

@interface UIAlertView (Hook)

@end

@interface UIAlertController (Hook)

@end
