//
//  URLHook.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/29.
//
//

#import "URLHook.h"
#import "TaskManager.h"
#import "ZKDeviceLogic.h"

@implementation URLHook

+ (void)hook {
    //exchangeMethod([NSURL class], @selector(initWithString:), @selector(hook_initWithString:));
    
    exchangeMethod([NSURLConnection class],
                   @selector(start),
                   @selector(hook_start));
    
    exchangeMethod([NSURLConnection class],
                   @selector(initWithRequest:delegate:startImmediately:),
                   @selector(hook_initWithRequest:delegate:startImmediately:));
}

@end


@implementation NSURL (Hook)

- (instancetype)hook_initWithString:(NSString *)URLString {
    if ([URLString hasSuffix:@".jpg"]) {
        return nil;
    }
    
    NSLog(@"##### [NSURL initWithString:%@] #####", URLString);
    return [self hook_initWithString:URLString];
}

@end

@implementation NSURLConnection (Hook)

- (void)hook_start {
    NSURLRequest *request = [self performSelector:NSSelectorFromString(@"currentRequest")];
    NSString *body = [[NSString alloc] initWithData:request.HTTPBody encoding:NSUTF8StringEncoding];
    NetNSLog(@"##### [NSURLConnection start] request:%@ \nheaders:%@ \nbody:%@ #####",
             request, request.allHTTPHeaderFields, body);
    NSString *processName = [[NSProcessInfo processInfo] processName];
    if ([processName isEqualToString:@"AppStore"] &&
        ([request.URL.absoluteString hasSuffix:@".jpg"] ||
         [request.URL.absoluteString hasSuffix:@".jpeg"] ||
         [request.URL.absoluteString hasSuffix:@".mp4"])) {
        // 不请求图片
        return;
    }
    
    [self hook_start];
}

- (instancetype)hook_initWithRequest:(NSURLRequest *)request delegate:(id)delegate startImmediately:(BOOL)startImmediately {
    NSURL *URL= [request URL];
    NetNSLog(@"##### [NSURLConnection initWithRequest:delegate:startImmediately: %@ #####", URL);
    if ([URL.absoluteString hasSuffix:@"buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/upToDateEligibilitySrv"]) {
        // 这里可以修改http协议内容
        
    } else if ([URL.absoluteString hasPrefix:@"https://client-api.itunes.apple.com/WebObjects/MZStorePlatform.woa/wa/lookup"]) {

    }
    return [self hook_initWithRequest:request delegate:delegate startImmediately:startImmediately];
}

@end
