//
//  UIBarButtonItem+Hook.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/29.
//
//

#import "UIBarItemHook.h"
#import "MyTouch.h"
#import "UIDevice+Common.h"
#import "YDASOWidget.h"

@implementation UIBarItemHook

+ (void)hook {
    exchangeMethod([UIBarButtonItem class], @selector(setTitle:), @selector(hook_setTitle:));
}

@end

// 帐号协议更改  SUBarButtonItem
@implementation UIBarButtonItem (Hook)

-(void)hook_setTitle:(NSString *)title {
    GLNSLog(@"##### [UIBarButtonItem setTitle:%@] %@ #####", title, self);
    [self hook_setTitle:title];
    
    if ([title isEqualToString:@"同意"] ||
        [title isEqualToString:@"完成"]) {
        NSThread *thread = [[NSThread alloc] initWithTarget:self
                                                   selector:@selector(handlerClickBarItem)
                                                     object:nil];
        [thread start];
    } else if ([title isEqualToString:@"下一页"] ||
               [title containsString:@"Next"]) {
        
    }
}

- (void)handlerClickBarItem {
    [NSThread sleepForTimeInterval:1.5];
    NSString *title = [self performSelector:@selector(title)];
    id target = [self performSelector:NSSelectorFromString(@"target")];
    SEL action = (SEL)[self performSelector:NSSelectorFromString(@"action")];
    NSLog(@"##### UIBarButtonItem action:%@ #####", NSStringFromSelector(action));
    if (target && [self isKindOfClass:NSClassFromString(@"SUBarButtonItem")]) {
        [target performSelector:NSSelectorFromString(@"buttonAction:") withObject:self];
//        [target performSelector:action withObject:object];
        
        if ([title isEqualToString:@"完成"]) {
            NSBundle* bundle =[NSBundle mainBundle];
            NSDictionary* info =[bundle infoDictionary];
            NSString* prodName =[info objectForKey:@"CFBundleDisplayName"];
            if (![prodName isEqualToString:@"App Store"]) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://itunes.apple.com/WebObjects/MZStore.woa/wa/search?media=software&country=CN&mt=8&term="]];
            }
        }
    }
}


@end
