//
//  HttpHook.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/29.
//
//

#import <Foundation/Foundation.h>
#import <ITMLKit/IKJSXMLHTTPRequest.h>


@interface HttpHook : NSObject

+ (void)hook;

@end

#pragma mark - 应用排名替换
@interface IKJSXMLHTTPRequest (Hook)

@end

#pragma mark - NSMutableURLRequest
@interface NSMutableURLRequest (Hook)

@end
