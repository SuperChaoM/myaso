//
//  HttpHook.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/29.
//
//

#import "HttpHook.h"
#import "TaskManager.h"
#import "BrushAppManager.h"
#import "ZKDeviceLogic.h"

#import "ZKStoreServices.h"

@implementation HttpHook

+ (void)hook {
    exchangeMethod([IKJSXMLHTTPRequest class],
                   @selector(operation:finishedWithOutput:),
                   @selector(hook_operation:finishedWithOutput:));
    
    /*
    exchangeMethod([NSMutableURLRequest class],
                   @selector(setAllHTTPHeaderFields:),
                   @selector(hook_setAllHTTPHeaderFields:));
    exchangeMethod([NSMutableURLRequest class],
                   @selector(setValue:forHTTPHeaderField:),
                   @selector(hook_setValue:forHTTPHeaderField:));
    exchangeMethod([NSMutableURLRequest class],
                   @selector(addValue:forHTTPHeaderField:),
                   @selector(hook_addValue:forHTTPHeaderField:));
    exchangeMethod([NSMutableURLRequest class],
                   @selector(setHTTPBody:),
                   @selector(hook_setHTTPBody:));
     */
}

@end

#pragma mark - 应用排名替换
@implementation IKJSXMLHTTPRequest (Hook)

- (void)hook_operation:(id)operation finishedWithOutput:(NSData *)output {
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    if (taskDict != nil) {
        NSURL * theUrl = [[self performSelector:NSSelectorFromString(@"urlRequest") withObject:nil]
                          performSelector:NSSelectorFromString(@"URL")
                          withObject:nil];
        NSString *strUrl = theUrl.absoluteString;
        NetNSLog(@"##### 搜索url:%@ #####", strUrl);
        if ([strUrl hasPrefix:@"https://itunes.apple.com/WebObjects/MZStore.woa/wa/search?"] ||
            [strUrl hasPrefix:@"https://search.itunes.apple.com/WebObjects/MZStore.woa/wa/search?"] ||       // 2016/12／15  苹果改的URL
             [strUrl hasPrefix:@"https://edge.itunes.apple.com/search?"]        // 2017/11/15
            ) {
            NSMutableDictionary *dic = [NSDictionary paramsDictionaryFromUrl:strUrl];
            NSString *keyword = [NSString decodeString:[dic objectForKey:@"term"]];
            NetNSLog(@"##### 搜索关键字:%@ #####", keyword);
            if (keyword.length > 0) {
                // 替换应用
                NSString *taskAppID = [taskDict valueForKey:TaskKeyAppID];
                NSString *taskKeyword = [taskDict valueForKey:TaskKeyKeyword];
                NetNSLog(@"##### 目标关键字:%@ #####", taskKeyword);
                if ([keyword isEqualToString:taskKeyword]) {                // 匹配关键字
                    NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData:output options:0 error:nil];
                    NSMutableDictionary *newJSON = [NSMutableDictionary dictionaryWithDictionary:JSON];
                    NSMutableDictionary *pageData = [NSMutableDictionary dictionaryWithDictionary:[JSON valueForKey:@"pageData"]];
                    NSMutableArray *bubbles = [NSMutableArray arrayWithArray:[pageData valueForKey:@"bubbles"]];
                    if (bubbles.count > 0) {
                        NSMutableDictionary *firstBubbles = [NSMutableDictionary dictionaryWithDictionary:bubbles[0]];
                        NSMutableArray *bubblesResult = [NSMutableArray arrayWithArray:[firstBubbles valueForKey:@"results"]];
                        
                        // 计算排名
                        GLNSLog(@"##### 计算应用排名 #####");
                        BrushSingeton.appPosIndex = -1;
                        BrushSingeton.storeDataResultsNum = 0;
                        for (int i = 0; i < bubblesResult.count; i++) {
                            NSDictionary *info = bubblesResult[i];
                            if ([[info valueForKey:@"id"] isEqualToString:taskAppID]) {
                                BrushSingeton.appPosIndex = i;
                                break;
                            }
                        }
                        
                        // 计算第一个返回的应用详情个数
                        NSMutableDictionary *storePlatformData = [NSMutableDictionary dictionaryWithDictionary:[JSON valueForKey:@"storePlatformData"]];
                        NSMutableDictionary *native_search = [NSMutableDictionary dictionaryWithDictionary:[storePlatformData valueForKey:@"native-search-lockup"]];
                        NSMutableDictionary *results = [NSMutableDictionary dictionaryWithDictionary:[native_search valueForKey:@"results"]];
                        BrushSingeton.storeDataResultsNum = (int)results.count;
                        
                        GLNSLog(@"##### 应用ID:%@, 关键字:%@, 排名:%d #####", taskAppID, keyword, BrushSingeton.appPosIndex + 1);
                        int appPos = [[taskDict valueForKey:TaskKeyAppPos] intValue];
                        if (BrushSingeton.appPosIndex > 0 && appPos != -1) {
                            // 替换到第一
                            if (appPos == 1) {
                                GLNSLog(@"##### 替换到第一名 #####");
                                NSDictionary *appDict = [self turnPageGetAppInfoForAppID:taskAppID];
                                [results setObject:appDict forKey:[bubblesResult[0] valueForKey:@"id"]];
                                BrushSingeton.appPosIndex = 0;
                                //替换返回数据
                                [native_search setObject:results forKey:@"results"];
                                [storePlatformData setObject:native_search forKey:@"native-search-lockup"];
                                [newJSON setObject:storePlatformData forKey:@"storePlatformData"];
                            } else {
                                //替换到第九
                                if (BrushSingeton.appPosIndex > 8) {
                                    GLNSLog(@"##### 替换到第九名 #####");
                                    NSDictionary *info_8     = bubblesResult[8];
                                    NSDictionary *info_index = bubblesResult[BrushSingeton.appPosIndex];
                                    [bubblesResult replaceObjectAtIndex:8 withObject:info_index];
                                    [bubblesResult replaceObjectAtIndex:BrushSingeton.appPosIndex withObject:info_8];
                                    BrushSingeton.appPosIndex = 8;
                                    
                                    // 替换返回数据
                                    [firstBubbles setObject:bubblesResult forKey:@"results"];
                                    [bubbles replaceObjectAtIndex:0 withObject:firstBubbles];
                                    [pageData setObject:bubbles forKey:@"bubbles"];
                                    [newJSON setObject:pageData forKey:@"pageData"];
                                }
                            }
                            
                            output = [NSJSONSerialization dataWithJSONObject:newJSON options:NSJSONWritingPrettyPrinted error:nil];
                        }
                    }
                }
            }
        }
    }
    
    [self hook_operation:operation finishedWithOutput:output];
}

- (NSDictionary *)getAppInfoForAppID:(NSString *)appID {
    NSDictionary *appDict = [BrushSingeton.cacheAppDict valueForKey:appID];
    if ([appDict isKindOfClass:[NSDictionary class]]) {
        return appDict;
    }
    NSString *sysVerString = [[UIDevice currentDevice] deviceSystemVersion];
    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
        sysVerString = TargetDeviceOSVersion;
    }
    NSString *userAgent = [NSString stringWithFormat:TargetDeviceUAFormat, @"AppStore/2.0 ", sysVerString, TargetDeviceProductType, TargetDeviceBuildVersion];;
    
    NSString * URLString = [NSString stringWithFormat:@"https://itunes.apple.com/cn/app/id%@?mt=8", appID];
    NSURL * URL = [NSURL URLWithString:[URLString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest * request = [[NSMutableURLRequest alloc]initWithURL:URL];
    [request setValue:TargetDeviceLanguage forHTTPHeaderField:@"Accept-Language"];
    [request setValue:userAgent forHTTPHeaderField:@"User-Agent"];
    [request setValue:TargetDeviceStoreFront forHTTPHeaderField:@"X-Apple-Store-Front"];
    NSURLResponse * response = nil;
    NSError * error = nil;
    NSData * data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    if (error == nil) {
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([jsonDict isKindOfClass:[NSDictionary class]]) {
            NSDictionary *storePlatformData = [jsonDict valueForKey:@"storePlatformData"];
            if ([storePlatformData isKindOfClass:[NSDictionary class]]) {
                NSDictionary *product_dv = [storePlatformData valueForKey:@"product-dv"];
                if ([product_dv isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *results = [product_dv valueForKey:@"results"];
                    if ([results isKindOfClass:[NSDictionary class]]) {
                        NSDictionary *appDict = [results valueForKey:appID];
                        if ([appDict isKindOfClass:[NSDictionary class]]) {
                            [BrushSingeton.cacheAppDict setObject:appDict forKey:appID];
                            return appDict;
                        }
                    }
                }
            }
        }
    }
    
    return nil;
}

// 翻页获取应用信息
- (NSDictionary *)turnPageGetAppInfoForAppID:(NSString *)appID {
    NSDictionary *appDict = [BrushSingeton.cacheAppDict valueForKey:appID];
    if ([appDict isKindOfClass:[NSDictionary class]]) {
        return appDict;
    }
    
    NSString *caller = @"P6";
    NSString *lockup = @"native-search-lockup";
    NSString *userAgent = [ZKStoreServices UserAgent];
    NSString *storeFront = [ZKStoreServices X_Apple_Store_Front];
    
    // cookies
    NSMutableString *strCookie = [[NSMutableString alloc] init];
    NSString *timestamp = [ZKStoreServices X_JS_TIMESTAMP];
    [strCookie appendFormat:@"X-JS-TIMESTAMP=%@;", timestamp];
    
    [strCookie appendString:@"hsaccnt=1;itspod=52;mz_at0-10185602512=AwQAAAFhAAE45wAAAABW5s9LH0oEM/T6LAhB/1fLEuv4vh0ShGE=;mz_at_ssl-10185602512=AwUAAAFhAAE45wAAAABW5s9LN7CGa5YCbwNQiibu26SmpSBFk1A=;mzf_in=522446;wosid-lite=h0C1FENynfT9VCzBBIPwCg;xp_ci=3zjyiCmz78Hz555z93azHsMbmupt;xt-b-ts-10185602512=1457966923830;"];
    
    NSMutableString *mstrJSToken = [[NSMutableString alloc] init];
    [mstrJSToken appendString:timestamp];
    [mstrJSToken appendString:storeFront];
    [mstrJSToken appendString:caller];
    [mstrJSToken appendString:appID];
    [mstrJSToken appendString:lockup];
    NSString *jsToken = [ZKStoreServices SSJSTokenGenerate:mstrJSToken];
    [strCookie appendFormat:@"X-JS-SP-TOKEN=%@;", jsToken];
    
    // 请求
    NSString *URLString = [NSString stringWithFormat:@"https://client-api.itunes.apple.com/WebObjects/MZStorePlatform.woa/wa/lookup?caller=%@&id=%@&p=%@&version=2", caller, appID, lockup];
    NSURL * URL = [NSURL URLWithString:[URLString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest * request = [[NSMutableURLRequest alloc]initWithURL:URL];
    [request setValue:TargetDeviceLanguage forHTTPHeaderField:@"Accept-Language"];
    [request setValue:userAgent forHTTPHeaderField:@"User-Agent"];
    [request setValue:storeFront forHTTPHeaderField:@"X-Apple-Store-Front"];
    [request setValue:strCookie forHTTPHeaderField:@"Cookie"];
    NSURLResponse * response = nil;
    NSError * error = nil;
    NSData * data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    if (error == nil) {
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([jsonDict isKindOfClass:[NSDictionary class]]) {
            NSDictionary *results = [jsonDict valueForKey:@"results"];
            if ([results isKindOfClass:[NSDictionary class]]) {
                NSDictionary *appDict = [results valueForKey:appID];
                if ([appDict isKindOfClass:[NSDictionary class]]) {
                    [BrushSingeton.cacheAppDict setObject:appDict forKey:appID];
                    return appDict;
                }
            }
        }
    }
    
    return nil;
}

@end

#pragma mark - NSMutableURLRequest
@implementation NSMutableURLRequest (Hook)

- (void)hook_setAllHTTPHeaderFields:(id)arg1 {
    NSString *processName = [[NSProcessInfo processInfo] processName];
    if ([processName isEqualToString:@"storebookkeeperd"] ||
        [processName isEqualToString:@"familycircled"]) {
        NetNSLog(@"##### [NSMutableURLRequest setAllHTTPHeaderFields:%@] #####", arg1);
    }
    
    [self hook_setAllHTTPHeaderFields:arg1];
}

- (void)hook_setValue:(NSString *)value forHTTPHeaderField:(NSString *)field {
    NSURL *URL = [self performSelector:NSSelectorFromString(@"URL")];
    NSString *processName = [[NSProcessInfo processInfo] processName];
    if ([processName isEqualToString:@"storebookkeeperd"] ||
        [processName isEqualToString:@"familycircled"]) {
        NetNSLog(@"##### [NSMutableURLRequest setValue:%@ forHTTPHeaderField:%@] (URL:%@)#####", value, field, URL);
    }

    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
        if ([field isEqualToString:@"User-Agent"] ||
            [field isEqualToString:@"user-agent"]) {
            value = [[UIDevice currentDevice] myUserAgent:value];
        }
    }
    
    [self hook_setValue:value forHTTPHeaderField:field];
}

- (void)hook_addValue:(NSString *)value forHTTPHeaderField:(NSString *)field {
    NSString *processName = [[NSProcessInfo processInfo] processName];
    if ([processName isEqualToString:@"storebookkeeperd"] ||
        [processName isEqualToString:@"familycircled"]) {
        NetNSLog(@"##### [NSMutableURLRequest addValue:%@ forHTTPHeaderField:%@] #####", value, field);
    }
    
    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
        if ([field isEqualToString:@"User-Agent"] ||
            [field isEqualToString:@"user-agent"]) {
            value = [[UIDevice currentDevice] myUserAgent:value];
        } else if ([field isEqualToString:@"X-MMe-Client-Info"]) {
            NetNSLog(@"##### 替换 X-MMe-Client-Info: %@ 前 #####", value);
            //<iPhone6,1> <iPhone OS;8.4;12H143> <com.apple.AppleAccount/1.0 (com.apple.FamilyCircle/1)>
//            value = [NSString stringWithFormat:@"<%@> <iPhone OS;%@;%@> <com.apple.AppleAccount/1.0 (com.apple.FamilyCircle/1)>",
//                     TargetDeviceProductType, TargetDeviceOSVersion, TargetDeviceBuildVersion];
            NetNSLog(@"##### 替换 X-MMe-Client-Info: %@ 后 #####", value);
        } else if ([field isEqualToString:@"X-GS-Client-Info"]) {
            
        }
    }
    
    [self hook_addValue:value forHTTPHeaderField:field];
}


- (void)hook_setHTTPBody:(NSData *)body {
    NSString *aString = [[NSString alloc] initWithData:body encoding:NSUTF8StringEncoding];
    NetNSLog(@"##### [NSMutableURLRequest setHTTPBody:%@] #####", aString);
    [self hook_setHTTPBody:body];
}

@end
