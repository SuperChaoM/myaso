//
//  ISDevice+Hook.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/28.
//
//

#import <Foundation/Foundation.h>
#import <iTunesStore/ISDevice.h>
#import <ITMLKit/IKJSDevice.h>
#import <ITMLKit/IKJSITunesStore.h>
#import <StoreServices/SSDevice.h>

@interface DeviceHook : NSObject

+ (void)hook;

@end

@interface ISDevice (Hook)

@end

@interface IKJSDevice (Hook)

@end

@interface IKJSITunesStore (Hook)

@end

@interface SSDevice (Hook)

@end
