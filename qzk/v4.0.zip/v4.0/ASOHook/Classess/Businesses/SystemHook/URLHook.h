//
//  URLHook.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/29.
//
//

#import <Foundation/Foundation.h>

@interface URLHook : NSObject

+ (void)hook;

@end
