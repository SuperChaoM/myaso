//
//  FunctionHook.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/7.
//
//

#ifndef FunctionHook_h
#define FunctionHook_h

void startHookFunctions();


#endif /* FunctionHook_h */
