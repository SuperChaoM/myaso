//
//  FunctionHook.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/7.
//
//

#import "FunctionHook.h"
#import "TaskManager.h"
#import "ZKDeviceLogic.h"
#import "CfgManager.h"

#import <substrate.h>
#import <dlfcn.h>
#import <SystemConfiguration/CaptiveNetwork.h>

#pragma mark - c函数
extern "C" unsigned char *CC_SHA1(const void *data, uint32_t len, unsigned char *md);
unsigned char * (*old_CC_SHA1)(const void *data, uint32_t len, unsigned char *md);
unsigned char * new_CC_SHA1(const void *data, uint32_t len, unsigned char *md);
unsigned char * new_CC_SHA1(const void *data, uint32_t len, unsigned char *md) {
    if (len != 4096) {
        GLNSLog(@"##### [调用堆栈:%@]\n CC_SHA1 %s ;len = %d; #####", [NSThread callStackSymbols], data, len);
    }
    
    return old_CC_SHA1(data, len, md);
}


#pragma mark - MGCopyAnswer
extern "C" CFStringRef MGCopyAnswer(CFStringRef prop);
static CFPropertyListRef (*orig_MGCopyAnswer_internal)(CFStringRef prop, uint32_t* outTypeCode);
static CFPropertyListRef new_MGCopyAnswer_internal(CFStringRef prop, uint32_t* outTypeCode) {
    NSString *propString = (NSString *)prop;
    CFPropertyListRef value = orig_MGCopyAnswer_internal(prop, outTypeCode);
    
    if (![propString isEqualToString:@"InternalBuild"] &&
        ![propString isEqualToString:@"ReleaseType"] &&
        ![propString isEqualToString:@"LBJfwOEzExRxzlAnSuI7eg"] &&
        ![propString isEqualToString:@"AJFQheZDyUbvI6RmBMT9Cg"] &&
        ![propString isEqualToString:@"AJFQheZDyUbvI6RmBMT9Cg"] &&
        ![propString isEqualToString:@"Oji6HRoPi7rH7HPdWVakuw"] &&
        ![propString isEqualToString:@"8DHlxr5ECKhTSL3HmlZQGQ"] &&
        ![propString isEqualToString:@"apple-internal-install"] &&
        ![propString isEqualToString:@"magnetometer"] &&
        ![propString isEqualToString:@"CoreRoutineCapability"] &&
        ![propString isEqualToString:@"DeviceClassNumber"] &&
        ![propString isEqualToString:@"dictation"] &&
        ![propString isEqualToString:@"multitasking"] &&
        ![propString isEqualToString:@"cellular-data"] &&
        ![propString isEqualToString:@"gps"] &&
        ![propString isEqualToString:@"shoebox"]) {
        //GLNSLog(@"##### new_MGCopyAnswer_internal prop:%@ value:%@ #####", propString, (NSString *)value);
    }
    
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    int taskopt = [[taskDict valueForKey:TaskKeyOpt] intValue];
    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
        if ([propString isEqualToString:@"ProductVersion"]) {
            NSArray<NSString *> *symbols = [NSThread callStackSymbols];
            for (NSString *symbol in symbols) {
                if ([symbol containsString:@"[ZKStoreServices SSJSTokenSecondEncryt:data:]"] ||
                    [symbol containsString:@"[TaskManager getTask:completionHandler:]"] ||
                    [symbol containsString:@"[TaskManager saveTaskResult:completionHandler:]"] ||
                    ([symbol containsString:@"CFRunLoopRunSpecific"] && ((taskopt == 0) || (taskopt & ASOTaskTypeBuyActive))) ||
                    [symbol containsString:@"[UIDevice(Common) myUserAgent:]"]) {
                    return value;
                }
            }
            value = CFStringCreateWithCString(CFAllocatorGetDefault(), [TargetDeviceOSVersion UTF8String], kCFStringEncodingUTF8);
        } else if ([propString isEqualToString:@"BuildVersion"]) {
            NSArray<NSString *> *symbols = [NSThread callStackSymbols];
            for (NSString *symbol in symbols) {
                if ([symbol containsString:@"[UIDevice(Common) myUserAgent:]"]) {
                    return value;
                }
            }
            value = CFStringCreateWithCString(CFAllocatorGetDefault(), [TargetDeviceBuildVersion UTF8String], kCFStringEncodingUTF8);
        } else if ([propString isEqualToString:@"ProductType"]) {
            NSArray<NSString *> *symbols = [NSThread callStackSymbols];
            for (NSString *symbol in symbols) {
                if ([symbol containsString:@"[ZKStoreServices SSJSTokenSecondEncryt:data:]"]) {
                    return value;
                }
            }
            value = CFStringCreateWithCString(CFAllocatorGetDefault(), [TargetDeviceProductType UTF8String], kCFStringEncodingUTF8);
        }
    }

    if (![ZKDeviceLogic systemVersion_10_x] && (taskopt & ASOTaskTypeBuy)) {              // 固件10.x的暂不换设备信息
        if ([propString isEqualToString:@"HWModelStr"]) {
            //value = (CFPropertyListRef)@"N51AP";
        } else if ([propString isEqualToString:@"GSDeviceName"]) {
            //value = (CFPropertyListRef)@"iPhone";
        } else if ([propString isEqualToString:@"UniqueDeviceID"]) {
            NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
            NSString *uuid = [taskDict valueForKey:TaskKeyUUID];
            if (uuid && ![uuid isEqualToString:@""]) {
                NSArray<NSString *> *symbols = [NSThread callStackSymbols];
                for (NSString *symbol in symbols) {
                    if ( [symbol containsString:@"[TaskManager getTask:completionHandler:]"] ||
                        [symbol containsString:@"[TaskManager saveTaskResult:errorMessage:completionHandler:]"]) {
                        return value;
                    }
                }
                NSLog(@"##### [设备信息] uuid = %@ 前 #####", (NSString *)value);
                value = CFStringCreateWithCString(CFAllocatorGetDefault(), [uuid UTF8String], kCFStringEncodingUTF8);
                NSLog(@"##### [设备信息] uuid = %@ 后 #####", (NSString *)value);
            }
        } else if ([propString isEqualToString:@"SerialNumber"]) {
            
        } else if ([propString isEqualToString:@"VasUgeSzVyHdB27g2XpN0g"]) { // 序列码
            
        } else if ([propString isEqualToString:@"k5lVWbXuiZHLA17KGiVUAA"]) { // 蓝牙地址
            
        } else if ([propString isEqualToString:@"gI6iODv8MZuiP0IA+efJCw"]) { // wifi地址
            
        } else if ([propString isEqualToString:@"TF31PAB6aO8KAbPyNKSxKA"]) { // DieId
            
        }
    }
    
    return value;
}

static CFPropertyListRef (*orig_MGCopyAnswer)(CFStringRef prop);
static CFPropertyListRef new_MGCopyAnswer(CFStringRef prop) {
    return orig_MGCopyAnswer(prop);
}

static void MGCopyAnswer_hook() {
    uint8_t MGCopyAnswer_arm64_impl[8] = {0x01, 0x00, 0x80, 0xd2, 0x01, 0x00, 0x00, 0x14};
    const uint8_t* MGCopyAnswer_ptr = (const uint8_t*) MGCopyAnswer;
    if (memcmp(MGCopyAnswer_ptr, MGCopyAnswer_arm64_impl, 8) == 0) {
        MSHookFunction((void *)(MGCopyAnswer_ptr + 8), (void*)new_MGCopyAnswer_internal, (void**)&orig_MGCopyAnswer_internal);
    } else {
        MSHookFunction((void *)MGCopyAnswer_ptr, (void*)new_MGCopyAnswer, (void**)&orig_MGCopyAnswer);
    }
}

#pragma mark _CFCopySystemVersionDictionary
extern "C" CFPropertyListRef _CFCopySystemVersionDictionary();
static CFPropertyListRef (*orig_CFCopySystemVersionDictionary)();
static CFPropertyListRef new_CFCopySystemVersionDictionary() {
    NSDictionary *dict = (NSDictionary *)orig_CFCopySystemVersionDictionary();
    NSMutableDictionary *retValue = [[NSMutableDictionary alloc] initWithDictionary:dict];
    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        int taskopt = [[taskDict valueForKey:TaskKeyOpt] intValue];
        if (taskopt & ASOTaskTypeBuy) {
            [retValue setObject:TargetDeviceOSVersion forKey:@"ProductVersion"];
            //[retValue setObject:TargetDeviceBuildVersion forKey:@"ProductBuildVersion"];
        }
    }
    
    return retValue;
}


#pragma mark - 对外函数
void startHookFunctions() {
    NSString *processName = [[NSProcessInfo processInfo] processName];
    
    GLNSLog(@"##### 进程名称:%@ #####", processName);
    if (![processName isEqualToString:@"mobileactivationd"] &&
        ![processName isEqualToString:@"mobactivationd"] &&
        ![processName isEqualToString:@"PGDribbble"] &&             // 不要去修改9.2～9.3.3 盘古越狱工具
        ![processName isEqualToString:@"yalu102"] &&
        ![processName isEqualToString:@"yidian-pro"] &&
        ![processName isEqualToString:@"JD4iPhone"] &&
        ![processName isEqualToString:@"sohunews"] &&
        ![processName isEqualToString:@"UCWEB"] &&
        ![processName isEqualToString:@"waimai"] &&
        ![processName isEqualToString:@"niumowang"] &&
        ![processName isEqualToString:@"NewMissFresh"] &&
        ![processName isEqualToString:@"installd"] &&
        ![processName isEqualToString:@"dataaccessd"] &&            // 修改buildversion时候，重启机子会有升级界面
        ![processName isEqualToString:@"lockdownd"]) {
        MGCopyAnswer_hook();
    }
    
    // 能够修改user-agent中的值
    if ([processName isEqualToString:@"AppStore"]) {
        MSHookFunction((void *)_CFCopySystemVersionDictionary, (void*)new_CFCopySystemVersionDictionary, (void**)&orig_CFCopySystemVersionDictionary);
    }

//    MSHookFunction(CC_SHA1, &new_CC_SHA1, &old_CC_SHA1);
}
