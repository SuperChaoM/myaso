//
//  ISDevice+Hook.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/12/28.
//
//

#import "DeviceHook.h"

#import "CfgManager.h"
#import "TaskManager.h"
#import "ZKDeviceLogic.h"

@implementation DeviceHook

+ (void)hook {
    exchangeMethod([ISDevice class], @selector(guid), @selector(hook_guid));
    exchangeMethod([ISDevice class], @selector(serialNumber), @selector(hook_serialNumber));
    exchangeMethod([ISDevice class], @selector(deviceName), @selector(hook_deviceName));
    exchangeMethod([ISDevice class], @selector(hardwareName), @selector(hook_hardwareName));
    exchangeMethod([ISDevice class], @selector(systemName), @selector(hook_systemName));
    
    exchangeMethod([IKJSDevice class], @selector(systemVersion), @selector(hook_systemVersion));
    exchangeMethod([IKJSDevice class], @selector(productType), @selector(hook_productType));
    exchangeMethod([IKJSDevice class], @selector(appVersion), @selector(hook_appVersion));
    exchangeMethod([IKJSDevice class], @selector(model), @selector(hook_model));
    
    exchangeMethod([IKJSITunesStore class], @selector(userAgent), @selector(hook_userAgent));
    
    exchangeMethod([SSDevice class],
                   @selector(userAgent),
                   @selector(hook_userAgent));
    exchangeMethod([SSDevice class],
                   @selector(productType),
                   @selector(hook_productType));
}

@end

@implementation ISDevice (Hook)

- (NSString*)hook_guid {
    NSString *res = [self hook_guid];
//    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
//    NSString *uuid = [taskDict valueForKey:TaskKeyUUID];
//    if (uuid && ![uuid isEqualToString:@""]) {
//        DeviceDataNSLog(@"##### hook_guid [伪造前]GUID = %@ #####", res);
//        res = uuid;
//        DeviceDataNSLog(@"##### hook_guid [伪造后]GUID = %@ #####", res);
//    }
    
    return res;
}

- (NSString *)hook_serialNumber {
    NSString *res = [self hook_serialNumber];
//    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
//    NSString *sn = [taskDict valueForKey:TaskKeySN];
//    if (sn && ![sn isEqualToString:@""]) {
//        DeviceDataNSLog(@"##### hook_serialNumber [伪造前]sn = %@ #####", res);
//        res = sn;
//        DeviceDataNSLog(@"##### hook_serialNumber [伪造后]sn = %@ #####", res);
//    }
    
    return res;
}

- (NSString*)hook_deviceName {
    NSString *res = [self hook_deviceName];
    DeviceDataNSLog(@"##### hook_deviceName = %@ #####", res);
    return res;
}

- (NSString*)hook_hardwareName {
    NSString *res = [self hook_hardwareName];
    DeviceDataNSLog(@"##### hook_hardwareName = %@ #####", res);
    return res;
}

- (NSString*)hook_systemName {
    NSString *res = [self hook_systemName];
    DeviceDataNSLog(@"##### hook_systemName = %@ #####", res);
    return res;
}

@end

#pragma mark - IKJSDevice
// https://xp.apple.com/report/2/xp_its_main
@implementation IKJSDevice (Hook)

-(NSString *)hook_systemVersion {
    NSString *value = [self hook_systemVersion];
    DeviceDataNSLog(@"##### [IKJSDevice systemVersion]:%@ #####", value);
    
//    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
//        value = TargetDeviceOSVersion;
//    }
    
    return value;
}

-(NSString *)hook_productType {
    NSString *value = [self hook_productType];
    DeviceDataNSLog(@"##### [IKJSDevice productType:%@] #####", value);
//    value = TargetDeviceProductType;
    return value;
}

-(NSString *)hook_appVersion {
    NSString *value = [self hook_appVersion];
    DeviceDataNSLog(@"##### [IKJSDevice appVersion:%@] #####", value);
    value = TargetDeviceAppVersion;
    return value;
}

-(NSString *)hook_model {
    NSString *value = [self hook_model];
    DeviceDataNSLog(@"##### [IKJSDevice model:%@] #####", value);
    return value;
}

@end

#pragma mark - IKJSITunesStore
@implementation IKJSITunesStore (Hook)

-(NSString *)hook_userAgent {
    NSString *value = [self hook_userAgent];
    DeviceDataNSLog(@"##### [IKJSITunesStore userAgent]:%@ #####", value);
    
    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
        value = [[UIDevice currentDevice] myUserAgent:value];
    }
    
    return value;
}

@end

#pragma mark - SSDevice
@implementation SSDevice (Hook)

-(NSString *)hook_userAgent {
    NSString *value = [self hook_userAgent];
    DeviceDataNSLog(@"##### [SSDevice userAgent]:%@ #####", value);
    if ([ZKDeviceLogic systemVersion_8_3_or_8_4]) {
        // 原先本来就没有设置
//        value = [[UIDevice currentDevice] myUserAgent:value];
    }
    
    return value;
}

- (NSString *)hook_productType {
    NSString *value = [self hook_productType];
    DeviceDataNSLog(@"##### [SSDevice productType:%@] #####", value);
    return value;
}

@end
