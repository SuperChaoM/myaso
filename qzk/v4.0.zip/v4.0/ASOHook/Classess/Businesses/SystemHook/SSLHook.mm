//
//  SSLHook.m
//  ASOHook
//
//  Created by 邱智铠 on 2017/10/15.
//
//

#import "SSLHook.h"

#import "YDASOWidget.h"
#import "MyTouch.h"

FUNPTR(void, MSHookFunction, void *symbol, void *replace, void **result) = NULL;
FUNPTR(void, MSHookMessageEx, Class _class, SEL sel, IMP imp, IMP *result) = NULL;

FUNHOOK(OSStatus, SSLRead, SSLContextRef context, void *data, size_t dataLength, size_t *processed)
{
    OSStatus ret = _SSLRead(context, data, dataLength, processed);
    //NSString *str = [[NSString alloc] initWithBytesNoCopy:(void *)data length:dataLength encoding:NSUTF8StringEncoding freeWhenDone:NO];
    
    //NSLog(@"##### SSLRead: %@ ###", str);
    
    
    return ret;
}
ENDHOOK

//
FUNHOOK(OSStatus, SSLWrite, SSLContextRef context, const void *data, size_t dataLength, size_t *processed)
{
    OSStatus ret = _SSLWrite(context, data, dataLength, processed);
    NSString *str = [[NSString alloc] initWithBytesNoCopy:(void *)data length:dataLength encoding:NSUTF8StringEncoding freeWhenDone:NO];
    
    //NSLog(@"##### SSLWrite:%@ #####", str);
    
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    NSString *gifCodeUrl = @"";
    static BOOL isRecognition = NO;
    NSArray *arr1 = [str componentsSeparatedByString:@"\r\n"];
    for (NSString *v in arr1) {
        if ([v isEqualToString:@""]) {
            continue;
        }
    
        if ([v hasPrefix:@"GET"] || [v hasPrefix:@"POST"]) {
            NSArray *arr3 = [v componentsSeparatedByString:@" "];
            gifCodeUrl = [gifCodeUrl stringByAppendingString:arr3[1]];
            continue;
        }
        
        NSArray *arr2 = [v componentsSeparatedByString:@": "];
        if (arr2.count == 2) {
            [dict setValue:arr2[1] forKey:arr2[0]];
        }
    }
    
    if ([dict.allKeys containsObject:@"Host"]) {
        gifCodeUrl = [NSString stringWithFormat:@"https://%@%@", [dict valueForKey:@"Host"], gifCodeUrl];
    }
    
    GLNSLog(@"##### SSL url:%@ #####", gifCodeUrl);
    if (!isRecognition && [gifCodeUrl containsString:@"ndsopaapl.nudatasecurity.com"] && [gifCodeUrl hasSuffix:@"&ptype=SCRIPT"]) {
        isRecognition = YES;
        NSString *newGifCodeUrl = [gifCodeUrl copy];
        gifCodeUrl = @"";
        NSLog(@"##### recogntioin verify code after 6 second #####");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            NSLog(@"##### begin recogntion verify code #####");
            [[YDVerifySetting sharedInstance] setShowDebugLog:NO];
            [[YDVerifySetting sharedInstance] setShowImageLog:NO];
            [[YDVerifySetting sharedInstance] setCurrentTargetStyle:YDVerifyStyleHollow5];
            
            [[YDVerifyManager sharedManager] autoVerifyGifCode:newGifCodeUrl  completionHandler:^(NSString *code, NSError *error) {
                isRecognition = NO;
                NSLog(@"YDVerify read verify code: %@, error: %@", code, error);
                
                NSInteger currentTargetStyle = [[YDVerifySetting sharedInstance] currentTargetStyle];
                NSLog(@"YDVerify current target style: %ld", (long)currentTargetStyle);
                
                CGPoint inputFocusPoint = [[YDVerifySetting sharedInstance] inputFocusPoint4VerifyStyle:currentTargetStyle];
                CGPoint longFocusPoint = [[YDVerifySetting sharedInstance] longFocusPoint4VerifyStyle:currentTargetStyle];
                CGPoint pasteClickPoint = [[YDVerifySetting sharedInstance] pasteClickPoint4VerifyStyle:currentTargetStyle];
                CGPoint blankPoint = [[YDVerifySetting sharedInstance] blankAreaPoint4VerifyStyle:currentTargetStyle];
                CGPoint nextBarItemPoint = [[YDVerifySetting sharedInstance] nextPagePoint4VerifyStyle:currentTargetStyle];
                
                if (!error) {
                    [UIPasteboard generalPasteboard].string = code;
                    
                    NSLog(@"YDVerify input focus point: %@", NSStringFromCGPoint(inputFocusPoint));
                    NSLog(@"YDVerify long focus point: %@", NSStringFromCGPoint(longFocusPoint));
                    NSLog(@"YDVerify paste click point: %@", NSStringFromCGPoint(pasteClickPoint));
                    NSLog(@"YDVerify blank click point: %@", NSStringFromCGPoint(blankPoint));
                    NSLog(@"YDVerify next barItem click point: %@", NSStringFromCGPoint(nextBarItemPoint));
                    
                    // 获取焦点
                    [MyTouch touch:inputFocusPoint];
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        // 长按，获取粘贴
                        [MyTouch longTouch:longFocusPoint];
                        
                        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                            //  点击粘贴
                            [MyTouch touch:pasteClickPoint];
                            
                            //dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                // 点击空白处，让键盘消失
                            //    [MyTouch touch:blankPoint];
                                
                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                    // 点击下一步
                                    //id target = [self performSelector:NSSelectorFromString(@"target")];
                                    //[target performSelector:NSSelectorFromString(@"buttonAction:") withObject:self];
                                    [MyTouch touch:nextBarItemPoint];
                                });
                           // });
                        });
                    });
                } else {
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        // 点击下一步
                        [MyTouch touch:nextBarItemPoint];
                    });
                }
            }];
        });
    }
    
    return ret;
} ENDHOOK


FUNHOOK(OSStatus, SSLSetSessionOption, SSLContextRef context, SSLSessionOption option, Boolean value)
{
    // Remove the ability to modify the value of the kSSLSessionOptionBreakOnServerAuth option
    if (option == kSSLSessionOptionBreakOnServerAuth)
        return noErr;
    else
        return _SSLSetSessionOption(context, option, value);
} ENDHOOK

//
FUNHOOK(SSLContextRef, SSLCreateContext, CFAllocatorRef allocator, SSLProtocolSide protocolSide, SSLConnectionType connectionType)
{
    SSLContextRef ret = _SSLCreateContext(allocator, protocolSide, connectionType);
    
    // Immediately set the kSSLSessionOptionBreakOnServerAuth option in order to disable cert validation
    _SSLSetSessionOption(ret, kSSLSessionOptionBreakOnServerAuth, true);
    return ret;
} ENDHOOK

//
FUNHOOK(OSStatus, SSLHandshake, SSLContextRef context)
{
    OSStatus ret = _SSLHandshake(context);
    return (ret == errSSLServerAuthCompleted) ? _SSLHandshake(context) : ret;
} ENDHOOK



void SSLHook() {
    _PTRFUN(/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate, MSHookFunction);
    _PTRFUN(/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate, MSHookMessageEx);
    
    _HOOKFUN(/System/Library/Frameworks/Security.framework/Security, SSLRead);
    _HOOKFUN(/System/Library/Frameworks/Security.framework/Security, SSLWrite);
    
    // SSL Kill
    _HOOKFUN(/System/Library/Frameworks/Security.framework/Security, SSLHandshake);
    _HOOKFUN(/System/Library/Frameworks/Security.framework/Security, SSLCreateContext);
    _HOOKFUN(/System/Library/Frameworks/Security.framework/Security, SSLSetSessionOption);
}

