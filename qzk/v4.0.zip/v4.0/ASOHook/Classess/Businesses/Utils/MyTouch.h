//
//  SimulateTouch.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/8/1.
//
//

#import <Foundation/Foundation.h>

@interface MyTouch : NSObject

+ (void)touch:(CGPoint)point;

+ (void)longTouch:(CGPoint)point;

+ (void)swipeFromPoint:(CGPoint)fromPoint toPoint:(CGPoint)toPoint;

@end
