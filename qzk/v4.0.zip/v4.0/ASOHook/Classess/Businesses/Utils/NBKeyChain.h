//
//  NBKeyChain.h
//  NBBase
//
//  Created by NB Team on 2017/2/21.
//
//

#import <Foundation/Foundation.h>

#define KeyChainServer                      @"com.nb.authtimeiterval"

@interface NBKeyChain : NSObject

// save data to keychain
+ (void)save:(NSString *)service data:(id)data;

// take out data from keychain
+ (id)load:(NSString *)service;

// delete data from keychain
+ (void)delete:(NSString *)service;

@end
