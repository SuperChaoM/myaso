//
//  Global.m
//  ASOHook
//
//  Created by 邱智铠 on 2018/3/28.
//
//

#import "Global.h"

@implementation Global

+ (NSString *)ASOVersion {
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:@"/Library/MobileSubstrate/DynamicLibraries/ASOHook.plist"];
    NSString *retVer = @"3.00.00";
    if (dict != nil) {
        retVer = [dict valueForKey:@"ASOVersion"];
    }
    
    return retVer;
}

@end
