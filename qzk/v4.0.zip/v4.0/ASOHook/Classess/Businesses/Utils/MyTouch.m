//
//  SimulateTouch.m
//  ASOHook
//
//  Created by 邱智铠 on 2017/8/1.
//
//

#import "MyTouch.h"
#import <PTFakeTouch/PTFakeMetaTouch.h>
#import "SimulateTouch.h"

@implementation MyTouch

+ (void)touch:(CGPoint)point {
//    UIWindow *window = [UIApplication sharedApplication].keyWindow;
//    NSInteger pointId = [PTFakeMetaTouch fakeTouchId:[PTFakeMetaTouch getAvailablePointId] AtPoint:point inWindow:window withTouchPhase:UITouchPhaseBegan];
//    [PTFakeMetaTouch fakeTouchId:pointId AtPoint:point inWindow:window withTouchPhase:UITouchPhaseEnded];
    
    
    int r = [SimulateTouch simulateTouch:0 atPoint:point withType:STTouchDown];
    if (r == 0) {
        [[NBNotificationCenter defaultCenter] postKillProcessNotify:@[@"backboardd"]];
        printf("iOSREError: Simutale touch down failed at (%f, %f).\n", point.x, point.y);
        return;
    }
    r = [SimulateTouch simulateTouch:r atPoint:point withType:STTouchUp];
    if (r == 0) printf("iOSREError: Simutale touch up failed at (%f, %f).\n", point.x, point.y);

}

+ (void)longTouch:(CGPoint)point {
    int r = [SimulateTouch simulateTouch:0 atPoint:point withType:STTouchDown];
    if (r == 0) {
        [[NBNotificationCenter defaultCenter] postKillProcessNotify:@[@"backboardd"]];
        printf("iOSREError: Simutale touch down failed at (%f, %f).\n", point.x, point.y);
        return;
    }
    [NSThread sleepForTimeInterval:1.5f];
    r = [SimulateTouch simulateTouch:r atPoint:point withType:STTouchUp];
    if (r == 0) printf("iOSREError: Simutale touch up failed at (%f, %f).\n", point.x, point.y);
    
}

+ (void)swipeFromPoint:(CGPoint)fromPoint toPoint:(CGPoint)toPoint {
    float duration = 0.05;
    int r = [SimulateTouch simulateSwipeFromPoint:fromPoint toPoint:toPoint duration:duration];
    if (r == 0) {
        [[NBNotificationCenter defaultCenter] postKillProcessNotify:@[@"backboardd"]];
    }
}

#pragma mark


@end
