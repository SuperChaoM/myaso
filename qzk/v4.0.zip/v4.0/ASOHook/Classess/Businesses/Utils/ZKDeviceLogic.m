//
//  ZKDeviceLogic.m
//  ASOHook
//
//  Created by 邱智铠 on 2017/7/15.
//
//

#import "ZKDeviceLogic.h"

@implementation ZKDeviceLogic

+ (BOOL)systemVersion_8_3_or_8_4 {
    if (SYSTEM_VERSION_GREATER_THAN(NSFoundationVersionNumber_iOS_8_2) &&
        SYSTEM_VERSION_LESS_THAN(NSFoundationVersionNumber_iOS_8_x_Max)) {
        if (ISREPLACE) {
            return YES;
        }
        return NO;
    }
    
    return NO;
}

+ (BOOL)systemVerison_9_x {
    if (SYSTEM_VERSION_GREATER_THAN(NSFoundationVersionNumber_iOS_8_x_Max) &&
        SYSTEM_VERSION_LESS_THAN(NSFoundationVersionNumber_iOS_9_x_Max)) {
        return YES;
    }
    
    return NO;
}

+ (BOOL)systemVersion_10_x {
    return SYSTEM_VERSION_GREATER_THAN(NSFoundationVersionNumber_iOS_9_x_Max);
}

+ (BOOL)canOnekeyNew {
    if (SYSTEM_VERSION_GREATER_THAN(NSFoundationVersionNumber_iOS_8_2) &&
            SYSTEM_VERSION_LESS_THAN(NSFoundationVersionNumber_iOS_9_2)) {
        return YES;
    }
    
    return NO;
}

@end
