//
//  FileLogic.m
//  ASOHook
//
//  Created by 邱智铠 on 2017/4/27.
//
//

#import "FileLogic.h"

@implementation FileLogic

+ (BOOL)isDirectoryExistsAtPath:(NSString *)path {
    if (path == nil || [path isEqualToString:@""]) {
        return NO;
    }
    
    BOOL isDir = NO;
    return ([[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDir] && isDir);
}

+ (BOOL)isFileExistsAtPath:(NSString *)path {
    if (path == nil || [path isEqualToString:@""]) {
        return NO;
    }
    
    BOOL isDir = YES;
    return ([[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDir] && !isDir);
}

+ (BOOL)createDirectoryAtPath:(NSString *)path {
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:[NSNumber numberWithShort:0777]
                                                           forKey:NSFilePosixPermissions];
    
    NSError *error = nil;
    BOOL result = [[NSFileManager defaultManager] createDirectoryAtPath:path
                                            withIntermediateDirectories:YES
                                                             attributes:attributes
                                                                  error:&error];
    if (!result && error) {
        return NO;
    }
    
    return YES;
}

+ (NSArray<NSString *> *)allFilesAtDirectoryPath:(NSString *)dirPath {
    
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:10];
    
    NSError *error = nil;
    NSArray *tempArray = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dirPath error:&error];
    if (error) {
        return [NSArray array];
    }
    
    for (NSString *fileName in tempArray) {
        NSString *fullPath = [dirPath stringByAppendingPathComponent:fileName];
        if ([FileLogic isFileExistsAtPath:fullPath]) {
            [array addObject:fullPath];
        }
    }
    
    return array;
}

+ (long long)fileSizeAtPath:(NSString *)filePath {
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]){
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
    }
    return 0;
}

+ (float)folderSizeAtPath:(NSString *)folderPath {
    NSFileManager* manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:folderPath]) return 0;
    NSEnumerator *childFilesEnumerator = [[manager subpathsAtPath:folderPath] objectEnumerator];
    NSString* fileName;
    long long folderSize = 0;
    while ((fileName = [childFilesEnumerator nextObject]) != nil){
        NSString* fileAbsolutePath = [folderPath stringByAppendingPathComponent:fileName];
        folderSize += [FileLogic fileSizeAtPath:fileAbsolutePath];
    }
    return folderSize/(1024.0*1024.0);
}

@end
