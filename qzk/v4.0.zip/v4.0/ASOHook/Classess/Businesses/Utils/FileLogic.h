//
//  FileLogic.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/4/27.
//
//

#import <Foundation/Foundation.h>

@interface FileLogic : NSObject

// 文件夹是否存在
+ (BOOL)isDirectoryExistsAtPath:(NSString *)path;

// 文件是否存在
+ (BOOL)isFileExistsAtPath:(NSString *)path;

// 创建文件夹
+ (BOOL)createDirectoryAtPath:(NSString *)path;

// 获取某文件夹下所有文件
+ (NSArray<NSString *> *)allFilesAtDirectoryPath:(NSString *)dirPath;

// 某文件大小  B
+ (long long)fileSizeAtPath:(NSString *)filePath;

// 某文件夹大小 M
+ (float )folderSizeAtPath:(NSString *)folderPath;

@end
