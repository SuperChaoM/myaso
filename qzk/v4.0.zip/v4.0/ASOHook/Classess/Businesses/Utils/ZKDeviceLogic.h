//
//  ZKDeviceLogic.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/7/15.
//
//

#import <Foundation/Foundation.h>

@interface ZKDeviceLogic : NSObject

+ (BOOL)systemVersion_8_3_or_8_4;

+ (BOOL)systemVerison_9_x;

+ (BOOL)systemVersion_10_x;

+ (BOOL)canOnekeyNew;

@end
