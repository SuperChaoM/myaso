//
//  Global.h
//  ASOHook
//
//  Created by 邱智铠 on 2018/3/28.
//
//

#import <Foundation/Foundation.h>

@interface Global : NSObject

+ (NSString *)ASOVersion;

@end
