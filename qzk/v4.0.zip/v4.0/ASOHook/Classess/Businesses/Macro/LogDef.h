//
//  LogDef.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2017/1/3.
//
//

#ifndef LogDef_h
#define LogDef_h

#pragma mark - 日志
#define kGLDebugOn  0   //基本
/* 基本模块调试 */
#define GLNSLog(format, ...) do { \
if (kGLDebugOn) { \
NSLog(format, ##__VA_ARGS__); \
} \
} while(0)

#define kNetDebugOn  0   //基本
/* 网络模块调试 */
#define NetNSLog(format, ...) do { \
if (kNetDebugOn) { \
NSLog(format, ##__VA_ARGS__); \
} \
} while(0)

#define kDeviceDataDebugOn  0   //设备数据
/* 设备数据模块调试 */
#define DeviceDataNSLog(format, ...) do { \
if (kDeviceDataDebugOn) { \
NSLog(format, ##__VA_ARGS__); \
} \
} while(0)


#endif /* LogDef_h */
