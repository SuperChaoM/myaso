//
//  UtilityDefines.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/9/25.
//
//

#ifndef UtilityDefines_h
#define UtilityDefines_h

#define exchangeMethod(aClass, oldSEL, newSEL) \
{ \
    Method oldMethod = class_getInstanceMethod(aClass,oldSEL); \
    assert(oldMethod); \
    Method newMethod = class_getInstanceMethod(aClass,newSEL); \
    assert(newMethod); \
    method_exchangeImplementations(oldMethod,newMethod); \
} \

#define exchangeClassMethod(aClass, oldSEL, newSEL) \
{ \
    Method oldMethod = class_getClassMethod(aClass,oldSEL); \
    assert(oldMethod); \
    Method newMethod = class_getClassMethod(aClass,newSEL); \
    assert(newMethod); \
    method_exchangeImplementations(oldMethod,newMethod); \
} \


#endif /* UtilityDefines_h */
