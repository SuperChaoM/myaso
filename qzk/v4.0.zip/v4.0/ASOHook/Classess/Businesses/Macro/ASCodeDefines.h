//
//  ASCodeDefines.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/22.
//
//

#ifndef ASCodeDefines_h
#define ASCodeDefines_h

typedef NS_OPTIONS(int, ASOTaskType) {
    ASOTaskTypeBuy = 1,                     // 购买
    ASOTaskTypeDownload = 1 << 1,           // 下载
    ASOTaskTypeActive = 1 << 2,             // 激活
    ASOTaskTypeComment = 1 << 3,            // 评论
    ASOTaskTypeQueryDetail = 1 << 4,        // 查看详情
    ASOTaskTypeBuyActive = 1 << 5,          // 买激活
    ASOTaskTypeLoginItunes = 1 << 6,        // 登录
    ASOTaskTypeBuyActiveWithInfo = 1 << 7,  // 买激活，需要上报账号信息
};

typedef NS_ENUM(int, ASCode) {
    ASCodeSuccess                       = 1000,
    ASCodeBuySuccess					= 1001,			// 购买成功
    ASCodeSuccessLogin					= 1002,			// 登录成功
    ASCodeSuccessDownload				= 1003,			// 下载成功
    ASCodeNoTask                        = 1004,         // 没有任务
    ASCodeNetError                      = 1005,         // 网络有问题
    ASCodeGetTaskError                  = 1006,         // 获取任务异常
    ASCodeUpdate                        = 1007,         // 更新版本
    ASCodeServerException               = 1008,         // 服务器异常
    ASCodeBuyNeedInputVerifyCode        = 1009,         // 购买需要输入验证码
    
    ASCodeFail                          = 2000,			// 失败
    ASCodeFailDownImg					= 2001,			// 下载资源图片出错
    ASCodeFailImgUrlUnfound             = 2002,			// 没有发现下载图片的url
    ASCodeFailImgNameEmpty				= 2003,			// 图片名称为空
    ASCodeFailKeywordUnfond             = 2004,			// 关键字没找到
    ASCodeFailAccountEmpty				= 2005,			// 账号为空
    ASCodeFailPwdEmpty					= 2006,			// 密码为空
    ASCodeFailWriteTaskFile             = 2007,			// 保存任务文件出错
    ASCodeFailLogoutAccount             = 2008,			// 注销账号失败
    ASCodeFailSearchViewUnfound         = 2009,			// 没有找到搜索界面
    ASCodeFailSearchApp                 = 2010,			// 搜索应用失败
    ASCodeFailBuyConectToItunes         = 2011,			// 无法连接到 iTunes Store(购买)
    ASCodeFailBuyTimeout				= 2012,			// 购买超时
    ASCodeFailAppleIDDisable			= 2013,			// 账号被禁用
    ASCodeFailPwdInvail                 = 2014,			// 密码无效
    ASCodeFailProtocolChange			= 2015,			// 账号协议有变
    ASCodeFailBuyCannot                 = 2016,			// 无法购买(有可能网络问题)
    ASCodeFailAppleIDStop				= 2017,			// 账号被停用
    ASCodeFailDownload					= 2018,			// 下载失败
    ASCodeFailDownloadTimeout			= 2019,			// 下载超时
    ASCodeFailDownloadCannot			= 2020,			// 无法下载(网络问题)
    ASCodeFailDownloadConnectItunes     = 2021,			// 无法连接itunes store(下载)
    ASCodeFailLoginConnectItunes		= 2022,			// 无法连接itunes store(登录)
    ASCodeFailLogin                     = 2023,         // 登录失败
    ASCodeFailSearchKeyword             = 2024,			// 搜索关键字失败
    ASCodeFailHadBuy                    = 2025,         // 该帐号购买过
    ASCodeFailLoadAppStoreToolBar       = 2026,         // 加载appstore工具栏失败
    ASCodeFailAppNotHaveTheKeyword      = 2027,         // 该应用没有该关键字
    ASCodeFailSearchRetConnectItunes    = 2028,         // 无法连接到 iTunes Store(搜索)
    ASCodeFailScrollPos                 = 2029,         // 滚动到指定位置
    ASCodeFailNoExistIpa                = 2030,         // 服务端上面没有ipa包
    ASCodeFailDownloadIPA               = 2031,         // 下载ipa包失败
    ASCodeFailInstall                   = 2032,         // 安装失败(买激活)
    ASCodeFailAppNameChanged            = 2033,         // 应用名称不匹配
    ASCodeFailConnectInner              = 2034,         // 下载ipa，连接内网失败
    ASCodeFailNoNewUser                 = 2035,         // 激活任务，不是新用户
    ASCodeFailGetActivateTask           = 2036,         // 获取激活任务失败
    ASCodeFailAppleIDLocked             = 2037,         // 账号被锁定
    ASCodeFailAppleIDNeedVerify         = 2038,         // 需要验证
    ASCodeFailRecognitionVerifyCodeTimeout = 2039,      // 识别验证码超时
    ASCodeFailAppleIDNeedVerifyForSetting   = 2040,     // 需要到设置中验证
    ASCodeFailCreateSymlinkIpa          = 2041,         // 创建ipa软连接失败
    ASCodeFailConnectVPN                = 2042,         // 连接vpn失败
    ASCodeFailCheckIPTimeout            = 2043,         // 检查ip超时
};


#endif /* ASCodeDefines_h */
