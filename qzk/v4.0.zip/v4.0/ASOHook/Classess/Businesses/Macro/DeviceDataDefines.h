//
//  DeviceDataDefines.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2017/2/3.
//
//

#ifndef DeviceDataDefines_h
#define DeviceDataDefines_h

#define TargetDeviceStoreFront      @"143465-19,29"
#define TargetDeviceLanguage        @"zh-Hans-CN"

#pragma mark - 替换数据 9.0.2  有效果
//#define TargetDeviceBigOS           @"9"
//#define TargetDeviceOSVersion       @"9.0.2"
//#define TargetDeviceBuildVersion    @"13A452"
//#define TargetDeviceUAFormat        @"%@iOS/%@ model/%@ hwp/s5l8960x build/%@ (6; dt:89)"
//#define TargetDeviceDT              @"89"
//#define TargetDeviceProductType     @"iPhone6,1"
//#define TargetDeviceAppVersion      @"2.0"

#pragma mark - 替换数据 10.1.1  有效果
//#define TargetDeviceBigOS           @"10"
//#define TargetDeviceOSVersion       @"10.1.1"
//#define TargetDeviceBuildVersion    @"14B150"
//#define TargetDeviceUAFormat        @"%@iOS/%@ model/%@ hwp/s5l8960x build/%@ (6; dt:89)"
//#define TargetDeviceDT              @"89"
//#define TargetDeviceProductType     @"iPhone6,1"
//#define TargetDeviceAppVersion      @"274.22"

#pragma mark - 替换数据 10.2.1  有效果
//#define TargetDeviceBigOS           @"10"
//#define TargetDeviceOSVersion       @"10.2.1"
//#define TargetDeviceBuildVersion    @"14D27"
//#define TargetDeviceUAFormat        @"%@iOS/%@ model/%@ hwp/s5l8960x build/%@ (6; dt:89)"
//#define TargetDeviceDT              @"89"
//#define TargetDeviceProductType     @"iPhone6,1"
//#define TargetDeviceAppVersion      @"274.22"

#pragma mark - 替换数据 10.3.1  
//#define TargetDeviceBigOS           @"10"
//#define TargetDeviceOSVersion       @"10.3.1"
//#define TargetDeviceBuildVersion    @"14E304"
//#define TargetDeviceUAFormat        @"%@iOS/%@ model/%@ hwp/s5l8960x build/%@ (6; dt:89)"
//#define TargetDeviceDT              @"89"
//#define TargetDeviceProductType     @"iPhone6,1"
//#define TargetDeviceAppVersion      @"274.22"

#pragma mark - 替换数据 10.2  iPhone6  (AppStore/2.0 iOS/10.2 model/iPhone7,2 hwp/t7000 build/14C92 (6; dt:106))
#define TargetDeviceBigOS           @"10"
#define TargetDeviceOSVersion       @"10.2"
#define TargetDeviceBuildVersion    @"14C92"
#define TargetDeviceUAFormat        @"%@iOS/%@ model/%@ hwp/t7000 build/%@ (6; dt:106)"
#define TargetDeviceDT              @"106"
#define TargetDeviceProductType     @"iPhone7,2"
#define TargetDeviceAppVersion      @"274.22"

#pragma mark - 替换数据 10.2.1 iPhone7 (AppStore/2.0 iOS/10.2 model/iPhone9,1 hwp/t8010 build/14C92 (6; dt:137))
//#define TargetDeviceBigOS           @"10"
//#define TargetDeviceOSVersion       @"10.2.1"
//#define TargetDeviceBuildVersion    @"14D27"
//#define TargetDeviceUAFormat        @"%@iOS/%@ model/%@ hwp/t8010 build/%@ (6; dt:137)"
//#define TargetDeviceDT              @"137"
//#define TargetDeviceProductType     @"iPhone9,1"
//#define TargetDeviceAppVersion      @"274.22"

#endif /* DeviceDataDefines_h */
