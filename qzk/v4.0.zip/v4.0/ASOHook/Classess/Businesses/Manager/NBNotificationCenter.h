//
//  NBNotificationCenter.h
//  NBBase
//
//  Created by Qiu.ZhiKai on 2017/3/23.
//
//

#import <Foundation/Foundation.h>

#define NBKillProcessNotificationFile               @"killprocessnotify.txt"
#define NBKillProcessNotificationName               "com.robert.aso.notify.killprocesses"
#define NBOnkeyNewNotificationName                  "com.robert.aso.notify.onekeynew"
#define NBInstallNotificationName                   "com.robert.aso.notify.install"
#define NBUninstallNotificationName                 "com.robert.aso.uninstall"
#define NBKillBackboarddNotificationName            "com.robert.aso.killbackboardd"
#define NBNextTaskNotificationName                  "com.robert.aso.nexttask"
#define NBRebootNotificationName                    "com.robert.aso.reboot"

@interface NBNotificationCenter : NSObject

+ (NBNotificationCenter *)defaultCenter;

- (void)registerNotification;

- (void)postKillProcessNotify:(NSArray *)processes;

@end
