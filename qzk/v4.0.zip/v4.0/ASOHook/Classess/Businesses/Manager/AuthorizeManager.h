//
//  AuthorizeManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2017/3/26.
//
//

#import <Foundation/Foundation.h>

@interface AuthorizeManager : NSObject

+ (AuthorizeManager *)defaultManager;

- (BOOL)isNeedSCInfoZip;

- (BOOL)checkIsExistSCInfoZip;

- (void)downloadSCInfoZip;

// 解压
- (void)extraSCInfoZip;

@end
