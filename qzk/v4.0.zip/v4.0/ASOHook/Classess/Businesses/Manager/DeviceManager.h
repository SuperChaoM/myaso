//
//  DeviceManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/11/26.
//
//

#import <Foundation/Foundation.h>

@interface DeviceManager : NSObject

+ (NSString *)generateUUIDString;

// 重置idfa
+ (void)resetIDFA;

@end
