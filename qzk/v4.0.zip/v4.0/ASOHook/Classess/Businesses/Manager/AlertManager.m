//
//  AlertManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/28.
//
//

#import "AlertManager.h"
#import "MBProgressHUD.h"

@interface AlertManager()

@end

@implementation AlertManager

+ (AlertManager*)defaultManager {
    static AlertManager *_manager = nil;
    if (_manager == nil) {
        _manager = [[AlertManager alloc] init];
    }
    return _manager;
}

- (void)toast:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        if (window == NULL) {
            GLNSLog(@"##### AlertManager::toast window is null #####");
            return;
        }
        
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:window animated:YES];
        //    // Set the text mode to show only text.
        hud.mode = MBProgressHUDModeText;
        hud.label.text = message;
        // Move to bottm center.
        hud.offset = CGPointMake(0.f, MBProgressMaxOffset);
        [hud hideAnimated:YES afterDelay:2.f];
    });
}

- (void)SBToast:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"任务提醒"
                                                            message:message
                                                           delegate:nil
                                                  cancelButtonTitle:nil
                                                  otherButtonTitles:nil];
        [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(performDismiss:) userInfo:alertview repeats:NO];
        [alertview show];
    });
}

-(void)performDismiss:(id)sender
{
    NSTimer *timer = (NSTimer *)sender;
    UIAlertView *alertView = (UIAlertView *)timer.userInfo;
    [alertView dismissWithClickedButtonIndex:0 animated:NO];
    [alertView release];
}

@end
