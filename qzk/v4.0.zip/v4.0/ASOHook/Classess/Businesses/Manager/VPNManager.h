//
//  VPNManager.h
//  FakeIDFA
//
//  Created by 邱智铠 on 2017/4/10.
//
//

#import <Foundation/Foundation.h>

@interface VPNManager : NSObject

// vpn设置开关
+ (void)setVPNEnabled:(BOOL)enabled;
// vpn是否可用
+ (BOOL)VPNEnabled;
// 是否连接
+ (BOOL)VPNIsConnected;

@end

@interface VPNBundleController : NSObject

- (id)_vpnSpecifier;
- (id)vpnSpecifier;
-(BOOL)isToggleSwitchInRootMenu;

-(id)initWithParentListController:(id)Meh;
-(id)vpnActiveForSpecifier:(id)arg1;
-(void)setVPNActive:(BOOL)arg1 ;
-(void)_setVPNActive:(BOOL)arg1 ;

@end
