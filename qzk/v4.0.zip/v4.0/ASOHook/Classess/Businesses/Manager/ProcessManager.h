//
//  ProcessManager.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/4/14.
//
//

#import <Foundation/Foundation.h>

@interface ProcessManager : NSObject

+ (BOOL)asoserverIsRunning;

// 运行中进程
+ (NSArray *)runningProcesses;

@end
