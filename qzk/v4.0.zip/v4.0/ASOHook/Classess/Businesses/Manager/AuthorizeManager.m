//
//  AuthorizeManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2017/3/26.
//
//

#import "AuthorizeManager.h"
#import "UIDevice+Common.h"
#import "FileLogic.h"

#define SCInfoZipPathFormat             @"/var/mobile/%@.zip"

@implementation AuthorizeManager

+ (AuthorizeManager *)defaultManager {
    static AuthorizeManager *_manager = nil;
    if (_manager == nil) {
        _manager = [[AuthorizeManager alloc] init];
    }
    return _manager;
}

- (BOOL)isNeedSCInfoZip {
    if (SYSTEM_VERSION_GREATER_THAN(NSFoundationVersionNumber_iOS_9_1) &&
        SYSTEM_VERSION_LESS_THAN(NSFoundationVersionNumber_iOS_9_x_Max)) {
        GLNSLog(@"##### [授权文件]该系统版本是否需要检测授权文件：需要 #####");
        return YES;
    } else {
        GLNSLog(@"##### [授权文件]该系统版本是否需要检测授权文件：不需要 #####");
        return NO;
    }
}

- (BOOL)checkIsExistSCInfoZip {
    NSString *uuidString = [[UIDevice currentDevice] UUIDString];
    NSString *fileString = [NSString stringWithFormat:SCInfoZipPathFormat, uuidString];
    if ([[NSFileManager defaultManager] fileExistsAtPath:fileString]) {
        NSLog(@"##### [授权文件]本地已经存在一份授权文件  #####");
        return YES;
    } else {
        NSLog(@"##### [授权文件]本地没有授权文件 #####");
        return NO;
    }
}

- (void)downloadSCInfoZip {
    NSString *uuidString = [[UIDevice currentDevice] UUIDString];
    NSString *urlString = [NSString stringWithFormat:@"http://www.iosapples.com/att/auth_backup/%@.zip", uuidString];
    NSLog(@"##### [授权文件]downloadSCInfoZip url: %@ #####", urlString);
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
                               NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
                               if (httpResponse.statusCode == 200) {
                                   NSString *uuidString = [[UIDevice currentDevice] UUIDString];
                                   NSString *fileString = [NSString stringWithFormat:SCInfoZipPathFormat, uuidString];
                                   if ([data writeToFile:fileString atomically:YES]) {
                                       NSLog(@"##### [授权文件]下载SCInfo成功, 授权文件备份到本地成功 #####");
                                   } else {
                                       NSLog(@"##### [授权文件]下载SCInfo成功, 授权文件备份到本地失败 #####");
                                   }
                                   
                               } else {
                                   NSLog(@"##### [授权文件]下载失败，错误信息：%@", httpResponse);
                               }
                           }];
}

- (void)extraSCInfoZip {
    NSLog(@"##### [授权文件]进行授权，不让PP守护闪退 #####");
    NSString *uuidString = [[UIDevice currentDevice] UUIDString];
    NSString *fileString = [NSString stringWithFormat:SCInfoZipPathFormat, uuidString];
    NSString *deviceSCInfo = [NSString stringWithFormat:@"%@", @"/var/mobile/Library/FairPlay/iTunes_Control/"];
    NSString *scInfoItunes = [NSString stringWithFormat:@"%@iTunes/", deviceSCInfo];
    // 删除手机中授权文件夹iTunes
    NSString *cmdString = [NSString stringWithFormat:@"rm -rf %@", scInfoItunes];
    system([cmdString UTF8String]);
    
    for (int i = 1; i <= 3; i++) {
        if ([FileLogic isDirectoryExistsAtPath:scInfoItunes]) {
            NSLog(@"##### [授权文件] 授权成功 #####");
            return;
        }
        NSLog(@"##### [授权文件] 第%d次进行授权 ", i);
        cmdString = [NSString stringWithFormat:@"unzip -o %@ -d %@", fileString, deviceSCInfo];
        system([cmdString UTF8String]);
        // 兼容备份时候不是备份外面那个itunes文件夹，而是备份itunes里面授权文件
        NSString *tmpSCInfo = [NSString stringWithFormat:@"%@%@/", deviceSCInfo, uuidString];
        if ([FileLogic isDirectoryExistsAtPath:tmpSCInfo]) {
            cmdString = [NSString stringWithFormat:@"mv %@ %@", tmpSCInfo, scInfoItunes];
            NSLog(@"##### [授权文件] 命令:%@ #####", cmdString);
            system([cmdString UTF8String]);
        }
    }
    
    NSLog(@"##### [授权文件] 授权失败 #####");
}

@end
