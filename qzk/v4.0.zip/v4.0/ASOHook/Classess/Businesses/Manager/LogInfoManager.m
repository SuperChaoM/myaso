//
//  LogInfoManager.m
//  ASOHook
//
//  Created by 邱智铠 on 2017/5/26.
//
//

#import "LogInfoManager.h"
#import "CfgManager.h"

@implementation LogInfoManager

+ (void)writeInfo:(NSString *)str {
    NSString *filePath = [NSString stringWithFormat:@"%@loginfo.txt", [CfgManager getAppDocumentsPath:AppStoreIdentifier]];
//    NSLog(@"##### [LogInfoManager writeInfo] 路径:%@ #####", filePath);
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *datestr = [dateFormatter stringFromDate:[NSDate date]];
    str = [NSString stringWithFormat:@"%@ %@\n",datestr, str];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        [str writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
        return;
    }
    
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForUpdatingAtPath:filePath];
    
    [fileHandle seekToEndOfFile];  //将节点跳到文件的末尾
    
    NSData* stringData  = [str dataUsingEncoding:NSUTF8StringEncoding];
    
    [fileHandle writeData:stringData]; //追加写入数据
    
    [fileHandle closeFile];
}

@end
