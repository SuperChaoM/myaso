//
//  LogInfoManager.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/5/26.
//
//

#import <Foundation/Foundation.h>

@interface LogInfoManager : NSObject

+ (void)writeInfo:(NSString *)str;

@end
