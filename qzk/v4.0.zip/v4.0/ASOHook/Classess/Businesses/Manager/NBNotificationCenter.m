//
//  NBNotificationCenter.m
//  NBBase
//
//  Created by Qiu.ZhiKai on 2017/3/23.
//
//

#import "NBNotificationCenter.h"
#import "CfgManager.h"
#import "TaskManager.h"
#import "AppManager.h"
#import "ZKBaseUtil.h"

//安装／卸载
#import <MobileCoreServices/LSApplicationWorkspace.h>

static void ReceiveNotifyNextTaskCB(CFNotificationCenterRef center,
                                         void *observer,
                                         CFStringRef name,
                                         const void *object,
                                         CFDictionaryRef userInfo)
{
    id lockScreenManager = [NSClassFromString(@"SBLockScreenManager") performSelector:NSSelectorFromString(@"sharedInstance")];
    if ([lockScreenManager performSelector:NSSelectorFromString(@"isUILocked")]) {
        NSLog(@"##### SBLockScreenManager isUILocked #####");
    } else {
        [[TaskManager defaultManager] exectableNextTask];
    }
}

static void ReceiveNotifyKillProcessesCB(CFNotificationCenterRef center,
                                         void *observer,
                                         CFStringRef name,
                                         const void *object,
                                         CFDictionaryRef userInfo)
{
    NSString *docDir = [CfgManager getAppDocumentsPath:AppStoreIdentifier];
    NSString *notifyfile = [NSString stringWithFormat:@"%@%@", docDir, NBKillProcessNotificationFile];
    NSString *jsonString = [NSString stringWithContentsOfFile:notifyfile encoding:NSUTF8StringEncoding error:nil];
    NSArray *processes = [jsonString JSONValue];
    for (NSString *process in processes) {
        NSString *cmdString = [NSString stringWithFormat:@"killall -9 %@", process];
//        NSLog(@"##### cmd: %@ #####", cmdString);
        system([cmdString UTF8String]);
    }
}

static void ReceiveNotifyOneKeyNewCB(CFNotificationCenterRef center,
                                     void *observer,
                                     CFStringRef name,
                                     const void *object,
                                     CFDictionaryRef userInfo)
{
    NSLog(@"##### 【一键新机】开始 #####");
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [ZKBaseUtil executeCMD:@"/var/mobile/Media/TouchSprite/lua/daemon/onekeynew" error:nil];
    });
}

static void ReceiveNotifyInstallCB(CFNotificationCenterRef center,
                                     void *observer,
                                     CFStringRef name,
                                     const void *object,
                                     CFDictionaryRef userInfo)
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        NSString *tmpIpa = [NSString stringWithFormat:@"%@%@", [CfgManager getAppDocumentsPath:AppStoreIdentifier], IPAName];
        NSString *cmdString = [NSString stringWithFormat:@"/var/mobile/Media/TouchSprite/lua/daemon/asohelper -install %@", tmpIpa];
        system([cmdString UTF8String]);
    });
    
}

static void ReceiveNotifyUninstallCB(CFNotificationCenterRef center,void *observer,CFStringRef name,const void *object,CFDictionaryRef userInfo)
{
    GLNSLog(@"##### [收到卸载应用通知] #####");
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    if (taskDict) {
        NSString *appIdentifier = [taskDict valueForKey:TaskKeyIdentifier];
        if ([[LSApplicationWorkspace defaultWorkspace] applicationIsInstalled:appIdentifier]) {
            NSString *uninstalltxt = [NSString stringWithFormat:@"%@%@", [CfgManager getAppDocumentsPath:AppStoreIdentifier], FlagUninstall];
            [@"" writeToFile:uninstalltxt atomically:YES encoding:NSUTF8StringEncoding error:nil];
            
            NSArray *array = [NSArray arrayWithObjects:appIdentifier, nil];
            NSSet *set = [NSSet setWithArray:array];
            NSDictionary *info = [NSDictionary dictionaryWithObject:set
                                                             forKey:@"SBInstalledApplicationsAddedBundleIDs"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"SBInstalledApplicationsDidChangeNotification"
                                                                object:nil
                                                              userInfo:info];
        }
    }
}

static void ReceiveNotifyRebootCB(CFNotificationCenterRef center,void *observer,CFStringRef name,const void *object,CFDictionaryRef userInfo)
{
    [[AppManager defaultManager].theSpringBoard performSelector:NSSelectorFromString(@"reboot")];
}


@implementation NBNotificationCenter

+ (NBNotificationCenter *)defaultCenter {
    static NBNotificationCenter *_center = nil;
    if (_center == nil) {
        _center = [[NBNotificationCenter alloc] init];
    }
    return _center;
}

- (void)registerNotification {
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    ReceiveNotifyKillProcessesCB,
                                    CFSTR(NBKillProcessNotificationName),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    // 下一个任务
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    ReceiveNotifyNextTaskCB,
                                    CFSTR(NBNextTaskNotificationName),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    // 一键新机 通知
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    ReceiveNotifyOneKeyNewCB,
                                    CFSTR(NBOnkeyNewNotificationName),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    // 安装 通知
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    ReceiveNotifyInstallCB,
                                    CFSTR(NBInstallNotificationName),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    // 卸载 通知
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    ReceiveNotifyUninstallCB,
                                    CFSTR(NBUninstallNotificationName),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    // 重启
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    ReceiveNotifyRebootCB,
                                    CFSTR(NBRebootNotificationName),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
}

- (void)postKillProcessNotify:(NSArray *)processes {
    NSString *docDir = [CfgManager getAppDocumentsPath:AppStoreIdentifier];
    NSString *notifyfile = [NSString stringWithFormat:@"%@%@", docDir, NBKillProcessNotificationFile];
    NSError *error = nil;
    NSString *jsonString = [[NSString alloc] initWithData:[processes JSONData] encoding:NSUTF8StringEncoding];
    BOOL bBool = [jsonString writeToFile:notifyfile atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (bBool && !error) {
        notify_post(NBKillProcessNotificationName);
    } else {
        NSLog(@"##### 保存杀死进程通知文件 %@ #####", error);
    }
}

@end
