//
//  DeviceManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/11/26.
//
//

#import "DeviceManager.h"
#import "CfgManager.h"
#import "UIDevice+Common.h"

#import <CommonCrypto/CommonDigest.h>

@implementation DeviceManager

+ (NSString *)generateUUIDString {
    // uuid : sha1(serialNumber + dieID + macAddress + bluetoothMac);
    NSString *serizlNumber = [[UIDevice currentDevice] serialNumberString];
    NSString *dieID = [[UIDevice currentDevice] dieIDString];
    NSString *macAddress = [[UIDevice currentDevice] macAddressString];
    NSString *bluetoothMac = [[UIDevice currentDevice] bluetoothAddressString];
    
    NSUInteger randromNum = (8000000000000 + (arc4random() % 1000000000000));
    NSString *randomDieID = [NSString stringWithFormat:@"%lu", (unsigned long)randromNum];
    NSString *input = [NSString stringWithFormat:@"%@%@%@%@", serizlNumber, randomDieID, macAddress, bluetoothMac];
    NSData *data = [NSData dataWithBytes:[input UTF8String] length:input.length];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    CC_SHA1(data.bytes, (CC_LONG)data.length, digest);
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    for(int i=0; i<CC_SHA1_DIGEST_LENGTH; i++) {
        [output appendFormat:@"%02x", digest[i]];
    }
    
    GLNSLog(@"##### serizlNumber:%@\n dieID:%@\n macAddress:%@\n bluetoothMac:%@\n uuid:%@ #####",
          serizlNumber, dieID, macAddress, bluetoothMac, output);
    return output;
}

+ (void)resetIDFA {
    notify_post("com.robert.asoserver.resetidfa");
}

@end
