//
//  VPNManager.m
//  FakeIDFA
//
//  Created by 邱智铠 on 2017/4/10.
//
//

#import "VPNManager.h"
#import <objc/runtime.h>
#import "AppManager.h"

#import <ifaddrs.h>

@implementation VPNManager

+ (void)setVPNEnabled:(BOOL)enabled {
    NSBundle* VPNPreferences = [NSBundle bundleWithPath:@"/System/Library/PreferenceBundles/VPNPreferences.bundle"];
    if([VPNPreferences load]){
        Class VPC = objc_getClass("VPNBundleController");
        if(VPC){
            VPNBundleController* VPNBC = [[VPC alloc] initWithParentListController:nil];
            
            if([VPNBC respondsToSelector:@selector(setVPNActive:)]){
                [VPNBC setVPNActive:enabled];
                GLNSLog(@"##### [VPN] [VPNBC setVPNActive:%@] #####", enabled ? @"YES" : @"NO");
            } else if([VPNBC respondsToSelector:@selector(_setVPNActive:)]){
                [VPNBC _setVPNActive:enabled];
                GLNSLog(@"##### [VPN] [VPNBC _setVPNActive:%@] #####", enabled ? @"YES" : @"NO");
            } else{
                GLNSLog(@"##### [VPN] Failed To Call Connecting Method #####");
            }
        } else {
            GLNSLog(@"##### [VPN] objc_getClass(\"VPNBundleController\") = %@ #####", VPC);
        }
    }
    
    [VPNPreferences unload];
}

+ (BOOL)VPNIsConnected {
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while (temp_addr != NULL) {
            NSString *string = [NSString stringWithFormat:@"%s" , temp_addr->ifa_name];
            if ([string rangeOfString:@"tap"].location != NSNotFound ||
                [string rangeOfString:@"tun"].location != NSNotFound ||
                [string rangeOfString:@"ppp"].location != NSNotFound){
                return YES;
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    
    // Free memory
    freeifaddrs(interfaces);
    return NO;
}

+ (BOOL)VPNEnabled {
    BOOL bRet = NO;
    NSBundle* VPNPreferences = [NSBundle bundleWithPath:@"/System/Library/PreferenceBundles/VPNPreferences.bundle"];
    if([VPNPreferences load]){
        Class VPC = objc_getClass("VPNBundleController");
        if(VPC){
            GLNSLog(@"##### [VPN] VPNBundleController Loaded #####");
            VPNBundleController* VPNBC = [[VPC alloc] initWithParentListController:nil];
            id PSS = nil;
            if([VPNBC respondsToSelector:@selector(_vpnSpecifier)]){
                PSS = [VPNBC _vpnSpecifier];
            } else if([VPNBC respondsToSelector:@selector(vpnSpecifier)]){
                PSS = [VPNBC vpnSpecifier];
            }
            GLNSLog(@"##### [VPN] vpnSpecifier:%@ #####", PSS);
            bRet = [[VPNBC vpnActiveForSpecifier:PSS] boolValue];
            GLNSLog(@"##### [VPN] 状态:%@ #####", bRet ? @"打开" : @"关闭");
        } else {
            GLNSLog(@"##### [VPN] objc_getClass(\"VPNBundleController\") = %@ #####", VPC);
        }
    } else{
        GLNSLog(@"##### [VPN] VPNPreferences.bundle Loading Failed #####");
    }
    
    [VPNPreferences unload];
    return bRet;
}

@end
