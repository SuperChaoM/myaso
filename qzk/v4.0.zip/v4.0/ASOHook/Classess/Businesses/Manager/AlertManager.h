//
//  AlertManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/28.
//
//

#import <Foundation/Foundation.h>

#define toast(msg)  [[AlertManager defaultManager] toast:msg]

@interface AlertManager : NSObject

+ (AlertManager*)defaultManager;

- (void)toast:(NSString *)message;

- (void)SBToast:(NSString *)message;

@end
