//
//  CacheManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/11/19.
//
//

#import <Foundation/Foundation.h>

@interface CacheManager : NSObject

+ (CacheManager *)defaultManager;

// 检测是否清空缓存
- (BOOL)checkCacheIsCleanup;

// 保存缓存配置
- (void)saveCacheCfg;

// 清理
- (BOOL)clearup;

@end
