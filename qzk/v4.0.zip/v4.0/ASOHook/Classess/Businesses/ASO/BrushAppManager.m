//
//  BrushAppManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/21.
//
//

#import "BrushAppManager.h"
#import "CfgManager.h"
#import "AppManager.h"
#import "TaskManager.h"
#import "AlertManager.h"
#import "VPNManager.h"
#import "FileLogic.h"
#import "ZKDeviceLogic.h"
#import "YDActivateTaskManager.h"
#import "ZKBaseUtil.h"

#import "MobileCoreServices/LSApplicationWorkspace.h"
#import <MobileCoreServices/LSApplicationProxy.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <unistd.h>
// StoreKitUI
#import "SKUINavigationBarController.h"
#import "SKUITabBarController.h"
#import "SKUISearchBar.h"
#import "SKUISearchFieldController.h"
#import "SKUIContentUnavailableView.h"
#import "SKUIAttributedStringView.h"
#import "SKUIAttributedStringLayout.h"
#import "SKUIStorePageSectionsViewController.h"
#import "SKUIHorizontalLockupView.h"
#import "SKUIOfferView.h"
#import "SKUIItemOfferButton.h"
#import "SKUICardViewElementCollectionViewCell.h"
#import "SKUICollectionView.h"
#import "SKUIFlexibleSegmentedControl.h"
#import "SKUIStyledButton.h"
#import "SKUIButtonCollectionViewCell.h"
//登陆
#import <CoreFoundation/CoreFoundation.h>
#import <StoreServices/SSAccountStore.h>
#import <StoreServices/SSAccount.h>
#import <StoreServices/SSAuthenticateRequest.h>
#import <StoreServices/SSMutableAuthenticationContext.h>
#import <StoreServices/SSAuthenticateResponse.h>

@interface BrushAppManager ()
{
    ASCode _retCode;
    BrushStep _step;
    SKUITabBarController *_tabBarVc;
    
    NSDictionary *_taskDict;
    NSTimer *_processTimer;
    NSString *_serverTaskMsg;
    int _tryNum;
    int _scrollToIndex;             // 滚动到第几个
    int _reloadAppStoreNum;
    int _matchAppNum;               // 配对应用次数
    int _waitInputVerifyCodeNum;    // 识别验证码次数
    int _waitLoadVerifyCodeNum;     // 等待加载验证码次数
    
    BOOL _isLogining;
    BOOL _isCancelDownloading;      // 取消下载中
    BOOL _isTaskSetting;            // 任务保存中
    BOOL _isOneKeyNewDoing;         // 一键新机中
    BOOL _isVPNSwitching;           // vpn切换中
}

@property (nonatomic, strong) NSString *activeCheckErrMsg;      // 买激活确认错误消息

// 下载
@property (nonatomic, strong) NSMutableData *fileData;
@property (nonatomic, assign) long long totalLength;
@property (nonatomic, assign) float downloadProgress;
@property (nonatomic, assign) BOOL isDownloading;
@property (nonatomic, assign) BOOL isInstalling;
@property (nonatomic, assign) BOOL isUninstalling;
@property (nonatomic, assign) BOOL checkingQiankaTask;

@end

@implementation BrushAppManager

+ (BrushAppManager*)defaultManager {
    static BrushAppManager *_manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [[BrushAppManager alloc] init];
    });
    
    return _manager;
}

- (instancetype)init {
    if (self = [super init]) {
        self.cacheAppDict = [NSMutableDictionary dictionary];
    }
    
    return self;
}

- (void)startBrushApp {
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    if ([[taskDict valueForKey:TaskKeyOpt] intValue] & ASOTaskTypeBuyActive) {         // 买量
        NSString *extJsonString = [taskDict valueForKey:TaskKeyExtJson];
        NSString *callbackUrl = [taskDict valueForKey:TaskKeyCallbackUrl];
        NSString *keywordString = [taskDict valueForKey:TaskKeyKeyword];
        //NSLog(@"##### extJsonString:%@ callbackUrl:%@ keywordString:%@", extJsonString, callbackUrl, keywordString);
        [[YDActivateTaskManager sharedManager] parseTaskParam:extJsonString callback:callbackUrl keyword:keywordString];
    }
    [[YDActivateSetting sharedInstance] setShowDebugLog:YES];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        _retCode                    = ASCodeFail;
        _step                       = BrushStepCheckAppStore;
        self.activeCheckErrMsg      = @"";
        _tryNum                     = 0;
        _reloadAppStoreNum          = 0;
        _matchAppNum                = 0;
        _waitInputVerifyCodeNum     = 0;
        _waitLoadVerifyCodeNum      = 0;
        _isLogining                 = NO;
        _isCancelDownloading        = NO;
        _isTaskSetting              = NO;
        _isOneKeyNewDoing           = NO;
        _isUninstalling             = NO;
        _isVPNSwitching             = NO;
        
        _processTimer = [NSTimer scheduledTimerWithTimeInterval:2.0f
                                                         target:self
                                                       selector:@selector(startBrush:)
                                                       userInfo:nil
                                                        repeats:YES];
    });
}

- (SKUISearchBar *)getSearchBar {
    SKUISearchBar *searchBar = nil;
    
    NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
    if (_tabBarVc.selectedIndex == itemsCount - 2) {
        SKUINavigationBarController *searchVC = _tabBarVc.selectedViewController;
        for (UIView *subview in searchVC.navigationBar.subviews) {
            GLNSLog(@"##### getSearchBar subview = %@ #####", [subview class]);
            if ([subview isKindOfClass:[UISearchBar class]]) {
                searchBar = (SKUISearchBar *)subview;
                break;
            } else if ([subview isKindOfClass:NSClassFromString(@"UISearchBarTextField")]) {
                if ([((UITextField *)subview).delegate isKindOfClass:[UISearchBar class]]) {
                    searchBar = (SKUISearchBar *)(((UITextField *)subview).delegate);
                    break;
                }
            }
        }
    }
    
    return searchBar;
}

- (NSString *)getNavigationBarTitle {
    UINavigationBar *navBar = nil;
    if ([ZKDeviceLogic systemVersion_10_x]) {
        navBar = ((UINavigationController *)_tabBarVc.selectedViewController.presentedViewController).navigationBar;
    } else {
        navBar = ((SKUINavigationBarController *)_tabBarVc.selectedViewController).navigationBar;
    }
    for (UIView *subview in navBar.subviews) {
        if ([subview isKindOfClass:NSClassFromString(@"UINavigationItemView")]) {
            NSString *title = [subview performSelector:@selector(title)];
            GLNSLog(@"##### getNavigationBarTitle : %@ #####", title);
            return title;
        }
    }
    
    return @"";
}

- (SKUIStorePageSectionsViewController *)getStorePageSectionsViewController {
    SKUIStorePageSectionsViewController *storePageSectionsVC = nil;
    
    SKUINavigationBarController *searchVC = _tabBarVc.selectedViewController;
    UIViewController *stackDocumentViewController = searchVC.topViewController.childViewControllers[0];
    if ([stackDocumentViewController isKindOfClass:NSClassFromString(@"SKUIStackDocumentViewController")]) {
        if (stackDocumentViewController.childViewControllers.count == 1) {
            if ([stackDocumentViewController.childViewControllers[0] isKindOfClass:NSClassFromString(@"SKUIStorePageSectionsViewController")]) {
                storePageSectionsVC = (SKUIStorePageSectionsViewController *)stackDocumentViewController.childViewControllers[0];
            }
        }
    }
    
    return storePageSectionsVC;
}

- (SKUIHorizontalLockupView *)getHorizontalLockupViewWithAppName:(NSString *)appName {
    static int switchFlag = 0;
    SKUIStorePageSectionsViewController *storePageSectionsVC = [self getStorePageSectionsViewController];
    if (storePageSectionsVC == nil) {
        return nil;
    }
    
    NSArray *cells = nil;
    int num = self.appPosIndex >= 8 ? self.appPosIndex : self.storeDataResultsNum - 1;
    for (int i = num; i >= -1 ; i--) {
        if (switchFlag == 0) {
            if (i >= 0) {
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:0];
                UICollectionViewCell *cell_1 = [storePageSectionsVC.collectionView cellForItemAtIndexPath:indexPath];
                UICollectionViewCell *cell_2 = [storePageSectionsVC collectionView:storePageSectionsVC.collectionView cellForItemAtIndexPath:indexPath];         // 这个原本跟上面cells是一样的，但是有时候会导致配对不正确，所以都把这两个获取出来，然后拼成数组遍历
                cells = cell_1 ? [NSArray arrayWithObjects:cell_1, cell_2, nil] : [NSArray arrayWithObjects:cell_2, cell_1, nil];
            } else {
                cells = storePageSectionsVC.collectionView.visibleCells;
            }
        } else {
            cells = storePageSectionsVC.collectionView.visibleCells;
        }
        
        
        GLNSLog(@"##### cells: %@ 位置；%d/%d #####", cells, i, num);
        for (UICollectionViewCell *cell in cells) {
            for (UIView *view in [cell.subviews[0] subviews]) {
                if ([view isKindOfClass:NSClassFromString(@"SKUIHorizontalLockupView")]) {
                    SKUIHorizontalLockupView *horLockupView = (SKUIHorizontalLockupView *)view;
                    UIView *subview = [ZKBaseUtil getSubViewFromParent:horLockupView subViewClassName:@"SKUIAttributedStringView"];
                    if ([subview isKindOfClass:NSClassFromString(@"SKUIAttributedStringView")]) {
                        SKUIAttributedStringView *nameStringView = (SKUIAttributedStringView *)subview;
                        SKUIAttributedStringLayout *nameLayout = nameStringView.layout;
                        NSAttributedString *nameAttrString = nameLayout.attributedString;
                        GLNSLog(@"###### 应用名称:%@   目标应用:%@  #####", nameAttrString.string, appName);
                        if ([appName isEqualToString:nameAttrString.string]) {
                            switchFlag = switchFlag == 0 ? 1 : 0;
                            return horLockupView;
                        }
                    }
                }
            }
        }
    }
    
    switchFlag = switchFlag == 0 ? 1 : 0;
    return nil;
}

- (void)startBrush:(NSTimer *)theTimer {
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    NSString *account = [taskDict valueForKey:TaskKeyAccount];
    NSString *pwd = [taskDict valueForKey:TaskKeyPwd];
    NSString *keyword = [taskDict valueForKey:TaskKeyKeyword];
    NSString *appName = [taskDict valueForKey:TaskKeyAppName];
    NSString *identifier = [taskDict valueForKey:TaskKeyIdentifier];
    NSString *appid = [taskDict valueForKey:TaskKeyAppID];
    NSString *ipaVerString = [taskDict valueForKey:TaskKeyIpaVer];
    BOOL bActiveNotUnstall = [[taskDict valueForKey:TaskKeyActiveNotUnstall] intValue] == 1;
    BOOL isChangeVPN = [[taskDict valueForKey:TaskKeyChangeVPN] boolValue];
    int taskopt = [[taskDict valueForKey:TaskKeyOpt] intValue];
    ASCode accountStatus = [[taskDict valueForKey:TaskKeyAccountStatus] intValue];
    
    switch (_step) {
        case BrushStepCheckAppStore:
        {
            GLNSLog(@"##### 检测是否加载好AppStore #####");
            UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
            if (rootVC && [rootVC isKindOfClass:NSClassFromString(@"SKUITabBarController")]) {
                _tabBarVc = (SKUITabBarController *)rootVC;
                if (_tabBarVc.tabBar.items.count >= 1) {
                    _tryNum = 0;
                    _step = BrushStepOneKeyNew;
                } else {
                    _tryNum++;
                    if (_tryNum >= 60) {
                        _tryNum = 0;
                        _retCode = ASCodeFailLoadAppStoreToolBar;
                        _step = BrushStepFinish;
                    }
                }
            } else {
                _tryNum++;
                if (_tryNum >= 60) {
                    _tryNum = 0;
                    _retCode = ASCodeFailLoadAppStoreToolBar;
                    _step = BrushStepFinish;
                }
            }
        }
            break;
            
        case BrushStepOneKeyNew:
        {
            if (_isOneKeyNewDoing) {
                if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/TouchSprite/tmp/onekeyret.txt"]) {
                    if (isChangeVPN) {
                        _step = BrushStepChangeVPN;
                    } else {
                        _step = BrushStepCheckApp;
                    }
                    _tryNum = 0;
                    NSLog(@"##### 【一键新机】结束 #####");
                } else {
                    toast(@"一键新机中...");
                }
                break;
            }
            // 一键新机
            if ([ZKDeviceLogic canOnekeyNew]) {
                notify_post(NBOnkeyNewNotificationName);
                _isOneKeyNewDoing = YES;
            } else {
                _step = BrushStepCheckApp;
            }
        }
            break;
            
        case BrushStepChangeVPN:
        {
            GLNSLog(@"##### 切换vpn #####");
            if (isChangeVPN) {      // 是否切换vpn
                /*
                if (_tryNum <= 0) {
                    // 打开vpn设置
                    id workspace = [NSClassFromString(@"LSApplicationWorkspace") performSelector:NSSelectorFromString(@"defaultWorkspace")];
                    [workspace performSelector:NSSelectorFromString(@"openSensitiveURL:withOptions:") withObject:[NSURL URLWithString:@"prefs:root=General&path=VPN"] withObject:nil];
                    
                    _tryNum++;
                } else if (_tryNum >= 5) {
                    _tryNum = 0;
                    _step = BrushStepCheckApp;
                } else {
                    _tryNum++;
                }
                */
                if (_isVPNSwitching) {
                    toast(@"切换vpn中...");
                    return;
                }
                if (_tryNum >= 10) {
                    _tryNum = 0;
                    _retCode = ASCodeFailConnectVPN;
                    _step = BrushStepSetTask;
                    break;
                }
                _isVPNSwitching = YES;
                _tryNum++;
                
                [VPNManager setVPNEnabled:NO];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    [VPNManager setVPNEnabled:YES];
                    [NSThread sleepForTimeInterval:5.0f];
                    if ([VPNManager VPNIsConnected]) {
                        _tryNum = 0;
                        _step = BrushStepCheckIp;
                    } else {
                        [VPNManager setVPNEnabled:NO];
                    }
                    _isVPNSwitching = NO;
                });
            } else {
                _tryNum = 0;
                _step = BrushStepCheckApp;
            }
            
        }
            break;
            
        case BrushStepCheckIp:
        {
            if (_tryNum++ >= 15) {
                _step = BrushStepSetTask;
                _retCode = ASCodeFailCheckIPTimeout;
                break;
            }
            if (_tryNum <= 1) {
                [[TaskManager defaultManager] checkIPWithCompletionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
                    if (connectionError) {
                        GLNSLog(@"检查网络是否重复失败");
                        _step = BrushStepSetTask;
                        _retCode = ASCodeNetError;
                    } else {
                        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
                        GLNSLog(@"#### responseData:%@ code:%ld #####", data, (long)httpResponse.statusCode);
                        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
                        GLNSLog(@"##### [获取任务]任务 : %@ #####", jsonDict);
                        int code = [[jsonDict valueForKey:@"Code"] intValue];
                        if (code == 1) {
                            _step = BrushStepCheckApp;
                            _tryNum = 0;
                        }
                    }
                }];
            }
        }
            break;
        
        case BrushStepCheckApp:
        {
            GLNSLog(@"##### [检测应用] identifier:%@ #####", identifier);
            if (self.isUninstalling) {
                toast(@"卸载应用中...");
                if ([[AppManager defaultManager] appIsInstalled:identifier]) {
                    break;
                } else {
                    self.isUninstalling = NO;
                }
            }
            
            if ([[AppManager defaultManager] appIsInstalled:identifier]) {
                BOOL bNeedUnstall = YES;
                for (LSApplicationProxy *appProxy in [[LSApplicationWorkspace defaultWorkspace] allApplications]) {
                    if (![appProxy.applicationType isEqualToString:@"User"]) {
                        continue;
                    }
                    if (![identifier isEqualToString:appProxy.applicationIdentifier]) {
                        continue;
                    }
                    NSString *shortVersion = appProxy.shortVersionString ?: @"";
                    NSString *buildVersion = appProxy.bundleVersion ?: @"";
                    NSLog(@"##### [检测应用] identifier:%@ shortVersionString:%@ bundleVersion:%@ ipaVerString:%@ #####", identifier, shortVersion, buildVersion, ipaVerString);
                    if (taskopt & ASOTaskTypeBuyActive) {
                        if ([shortVersion hasPrefix:ipaVerString] || [buildVersion hasPrefix:ipaVerString]) {
                            bNeedUnstall = bActiveNotUnstall ? NO : YES;
                        }
                    }
                    break;
                }
                
                if (bNeedUnstall) {             // 版本不一致或者不是免卸载
                    notify_post(NBUninstallNotificationName);
                    self.isUninstalling = YES;
                    break;
                }
            }
            
            if (taskopt & ASOTaskTypeLoginItunes) {
                _isLogining = NO;
                _step = BrushStepLoginItunes;
            } else if (taskopt & ASOTaskTypeBuy) {
                _isLogining = NO;
                _step = BrushStepLoginItunes;
            } else if (taskopt & ASOTaskTypeQueryDetail) {
                _step = BrushStepQueryApp;
            } else if (taskopt & ASOTaskTypeComment) {
                _step = BrushStepQueryApp;
            } else if (taskopt & ASOTaskTypeBuyActive) {
                self.isDownloading = NO;
                self.isInstalling = NO;
                self.checkingQiankaTask = NO;
                _step = BrushStepDownloadIPA;
            } else {
                _retCode = ASCodeSuccess;
                _step = BrushStepSetTask;
            }
        }
            break;
            
        case BrushStepLoginItunes:
        {
            if (_isLogining) {
                GLNSLog(@"##### [登录帐号]登录中... #####");
                NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
                if (itemsCount >= 1) {
                    UITabBarItem *searchTabBarItem = _tabBarVc.tabBar.items[_tabBarVc.selectedIndex == 0 ? itemsCount - 1 : 0];
                    [_tabBarVc performSelector:@selector(_tabBarItemClicked:) withObject:searchTabBarItem];
                }
                
                break;
            }
            
            if (account.length <= 0 || pwd.length <= 0) {
                GLNSLog(@"##### [登录帐号] 帐号或密码为空 #####");
                _tryNum = 0;
                _retCode = account.length <= 0 ? ASCodeFailAccountEmpty : ASCodeFailPwdEmpty;
                _step = BrushStepSetTask;
                break;
            }
            
            SSAccountStore *accountStore = [SSAccountStore defaultStore];
            if (accountStore.activeAccount) {
                if ([accountStore.activeAccount.accountName isEqualToString:account]) {
                    NSLog(@"##### [登录帐号] this is account had logined #####");
                    _tryNum = 0;
                    if ((taskopt & ASOTaskTypeBuy) || (taskopt & ASOTaskTypeQueryDetail)) {
                        _step = BrushStepCheckTabBar;
                    } else {
                        _retCode = ASCodeSuccess;
                        _step = BrushStepSetTask;
                    }
                } else {
                    NSLog(@"##### [登录帐号] have an account logined #####");
                    [accountStore signOutAccount:accountStore.activeAccount];
                }
            }
            
            GLNSLog(@"##### [登录帐号] %@/%@ #####", account, pwd);
            _isLogining = YES;
            SSMutableAuthenticationContext *authenticationContext = [SSMutableAuthenticationContext contextForSignIn];
            [authenticationContext setAccountName:account];
            [authenticationContext setInitialPassword:pwd];
            [authenticationContext setAllowsRetry:false];
            [authenticationContext setCanSetActiveAccount:YES];
            
            SSAuthenticateRequest *authenticateRequest;
            authenticateRequest = [[SSAuthenticateRequest alloc] initWithAuthenticationContext:authenticationContext];
            [authenticateRequest startWithAuthenticateResponseBlock:^(SSAuthenticateResponse *response){
                if (response && !response.error) {
                    NSLog(@"##### [登录帐号]login account success #####");
                    _tryNum = 0;
                    if ((taskopt & ASOTaskTypeBuy) || (taskopt & ASOTaskTypeQueryDetail)) {
                        _step = BrushStepCheckTabBar;
                    } else {
                        _retCode = ASCodeSuccess;
                        _step = BrushStepSetTask;
                    }
                } else {
                    if (_tryNum >= 2) {
                        _tryNum = 0;
                        _step = BrushStepSetTask;
                    } else {
                        _tryNum++;
                    }
                    NSString *failureDesc = [response.error.userInfo valueForKey:@"NSLocalizedDescription"];
                    NSString *failureReason = [response.error.userInfo valueForKey:@"NSLocalizedFailureReason"];
                    NSLog(@"##### [登录帐号] login account fail desc: %@, reason: %@ ", failureDesc, failureReason);
                    if ([failureReason isEqualToString:@"您的 Apple ID 或密码不正确。"]) {
                        _retCode = ASCodeFailPwdInvail;
                    } else if ([failureReason containsString:@"您的帐户已被禁用"] ||
                               [failureReason containsString:@"Your account is disabled"] ||
                               [failureReason containsString:@"此 Apple ID 已由于安全原因被禁用。 请访问 iForgot 重新设置您的账户 (http://iforgot.apple.com)。"] ||
                               [failureReason containsString:@"This Apple ID has been locked for security reasons. Visit iForgot to reset your account (https://iforgot.apple.com)."]) {
                        _retCode = ASCodeFailAppleIDDisable;
                    } else if ([failureDesc isEqualToString:@"无法连接到 iTunes Store"]) {
                        _retCode = ASCodeFailLoginConnectItunes;
                    } else {
                        _retCode = ASCodeFailLogin;
                    }
                }
                
                _isLogining = NO;
                if (_retCode == ASCodeFailPwdInvail || _retCode == ASCodeFailAppleIDDisable) {
                    _tryNum = 0;
                    _step = BrushStepSetTask;
                }
                
            }];
        }
            break;
            
        case BrushStepCheckTabBar:
        {
            GLNSLog(@"##### [检测是否加载好工具栏] #####");
            if (_tabBarVc.tabBar.items.count >= 1) {
                _tryNum = 0;
                _step = BrushStepClickSearacBar;
            } else if (_tryNum++ > 60) {
                _tryNum = 0;
                _step = BrushStepSetTask;
                _retCode = ASCodeFailLoadAppStoreToolBar;
            }
        }
            break;
            
        case BrushStepClickSearacBar:
        {
            GLNSLog(@"##### [点击搜索栏] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (itemsCount >= 1) {
                UITabBarItem *searchTabBarItem = _tabBarVc.tabBar.items[itemsCount - 2];
                [_tabBarVc performSelector:@selector(_tabBarItemClicked:) withObject:searchTabBarItem];
                
                _tryNum = 0;
                _step = BrushStepCheckSeachTF;
            }
        }
            break;
            
        case BrushStepCheckSeachTF:
        {
            GLNSLog(@"##### [检测是否出现搜索框] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                GLNSLog(@"##### [检测是否出现搜索框] 当前选中的index = %lu #####", (unsigned long)_tabBarVc.selectedIndex);
                _tryNum = 0;
                _step = BrushStepClickSearacBar;
            } else {
                SKUISearchBar *searchBar = [self getSearchBar];
                if (searchBar) {
                    _tryNum = 0;
                    _step = BrushStepClickSeachTF;
                } else if (_tryNum++ >= 30) {
                    _tryNum = 0;
                    _step = BrushStepSetTask;
                    _retCode = ASCodeFailSearchViewUnfound;
                }
            }
        }
            break;
            
        case BrushStepClickSeachTF:
        {
            GLNSLog(@"##### [点击搜索框] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _tryNum = 0;
                _step = BrushStepClickSearacBar;
                break;
            }
            SKUISearchBar *searchBar = [self getSearchBar];
            if (![searchBar isFirstResponder]) {
                if (![searchBar.delegate isKindOfClass:NSClassFromString(@"SKUISearchFieldController")]) {
                    GLNSLog(@"##### [点击搜索框] [_searchBar.delegate isKindOfClass:%@] #####", [searchBar.delegate class]);
                    break;
                }
                
                [searchBar becomeFirstResponder];
            }
            
            _tryNum = 0;
            _step = BrushStepSearchKeyword;
        }
            break;
            
        case BrushStepSearchKeyword:
        {
            GLNSLog(@"##### [搜索关键字] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _tryNum = 0;
                _step = BrushStepClickSearacBar;
                break;
            }
            if (keyword.length <= 0) {
                _tryNum = 0;
                _step = BrushStepSetTask;
                _retCode = ASCodeFailKeywordUnfond;
                break;
            }
            SKUISearchBar *searchBar = [self getSearchBar];
            if (![searchBar.text isEqualToString:keyword]) {
                searchBar.text = keyword;
            }
            
            self.appPosIndex = -1;          // 重置应用排名位置
            self.storeDataResultsNum = 0;   
            if ([searchBar.delegate respondsToSelector:@selector(searchBarSearchButtonClicked:)]) {
                [searchBar.delegate performSelector:@selector(searchBarSearchButtonClicked:) withObject:searchBar];
            }
            
            _tryNum = 0;
            _step = BrushStepWaitSearchResult;
        }
            break;
            
        case BrushStepWaitSearchResult:
        {
            GLNSLog(@"##### [等待搜索结果] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            if (_tryNum++ >= 60) {
                GLNSLog(@"##### [等待搜索结果] 超时 #####");
                _tryNum = 0;
                _step = BrushStepSetTask;
                _retCode = ASCodeFailSearchKeyword;
                break;
            }
            
            SKUINavigationBarController *searchVC = _tabBarVc.selectedViewController;
            if (![searchVC.topViewController isKindOfClass:NSClassFromString(@"SKUIDocumentContainerViewController")]) {
                GLNSLog(@"##### 等待搜索结果 [searchVC.topViewController isKindOfClass:%@] #####", [searchVC.topViewController class]);
                break;
            }
            if (searchVC.topViewController.childViewControllers.count != 1) {
                GLNSLog(@"##### 等待搜索结果 searchVC.topViewController.childViewControllers.count = %lu #####", (unsigned long)searchVC.topViewController.childViewControllers.count);
                break;
            }
            
            UIViewController *stackDocumentViewController = searchVC.topViewController.childViewControllers[0];
            if ([stackDocumentViewController isKindOfClass:NSClassFromString(@"SKUIContentUnavailableDocumentViewController")]) {
                // 搜索不到数据
                SKUIContentUnavailableView *unavailableContentView = (SKUIContentUnavailableView *)stackDocumentViewController.view;
                SKUIAttributedStringView *messageView = (SKUIAttributedStringView *)[ZKBaseUtil getSubViewFromParent:unavailableContentView subViewClassName:@"SKUIAttributedStringView"];
                SKUIAttributedStringLayout *messageLayout = messageView.layout;
                NSAttributedString *messageAttrString = messageLayout.attributedString;
                GLNSLog(@"搜索错误提示:%@", messageAttrString);
                _tryNum = 0;
                _step = BrushStepSetTask;
                _retCode = ASCodeFailSearchRetConnectItunes;
                break;
            } else if ([stackDocumentViewController isKindOfClass:NSClassFromString(@"SKUITrendingSearchDocumentViewController")]) {
                // 还是处于搜索界面
                _tryNum = 0;
                _step = BrushStepClickSeachTF;
                break;
            }
            
            if (![stackDocumentViewController isKindOfClass:NSClassFromString(@"SKUIStackDocumentViewController")]) {
                GLNSLog(@"##### 等待搜索结果 [stackDocumentViewController isKindOfClass:%@] #####", [stackDocumentViewController class]);
                break;
            }
            
            SKUIStorePageSectionsViewController *storePageSectionsVC = [self getStorePageSectionsViewController];
            if (storePageSectionsVC == nil) {
                GLNSLog(@"##### [等待搜索结果] storePageSectionsVC == nil #####");
                break;
            }
            UICollectionView *collectionView = storePageSectionsVC.collectionView;
            NSInteger numberOfItems = [collectionView.dataSource collectionView:collectionView numberOfItemsInSection:0];
            if (numberOfItems <= 0) {
                break;
            }
            
            if (self.appPosIndex < 0) {         // 该应用没有包含该关键字
                GLNSLog(@"##### [等待搜索结果] 不包含该关键字 #####");
                _tryNum = 0;
                _step = BrushStepSetTask;
                _retCode = ASCodeFailAppNotHaveTheKeyword;
            } else {
                _scrollToIndex = 0;
                _tryNum = 0;
                _step = BrushStepScrollToAppPos;
            }
        }
            break;
            
        case BrushStepScrollToAppPos:
        {
            GLNSLog(@"##### [翻页到指定应用位置] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            
            if (self.appPosIndex <= _scrollToIndex) {
                _tryNum = 0;
                _step = BrushStepMatchApp;
                break;
            } else if (_tryNum++ >= 150) {
                _retCode = ASCodeFailScrollPos;
                _step = BrushStepSetTask;
                break;
            }
            
            SKUIStorePageSectionsViewController *storePageSectionsVC = [self getStorePageSectionsViewController];
            if (storePageSectionsVC == nil) {
                GLNSLog(@"##### [翻页到指定应用位置] storePageSectionsVC == nil #####");
                break;
            }
            SKUICollectionView *collectionView = (SKUICollectionView *)storePageSectionsVC.collectionView;
            NSInteger numberOfItems = [collectionView numberOfItemsInSection:0];
            GLNSLog(@"##### [翻页到指定应用位置] 已经加载 %ld #####", (long)numberOfItems);
            if (_scrollToIndex < self.appPosIndex) {
                if (numberOfItems <= self.appPosIndex) {
                    if (_scrollToIndex < numberOfItems - 1) {
                        _scrollToIndex = (int)numberOfItems - 1;
                    } else {
                        GLNSLog(@"##### [翻页到指定应用位置] 加载。。。 #####");
                        CGPoint targetOffset = CGPointMake(0, collectionView.contentOffset.y);
                        [storePageSectionsVC scrollViewWillEndDragging:collectionView withVelocity:CGPointMake(0, 0.192369) targetContentOffset:&targetOffset];
                        break;
                    }
                } else {
                    _scrollToIndex = self.appPosIndex;
                }
            }
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:_scrollToIndex inSection:0];
            GLNSLog(@"##### [翻页到指定应用位置] 滚动到 indexPath = %@ #####", indexPath);
            [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionTop animated:YES];
        }
            break;
        
        case BrushStepMatchApp:
        {
            GLNSLog(@"##### [配对应用] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            if (_matchAppNum++ > 2) {
                _step = BrushStepSetTask;
                _retCode = ASCodeFailAppNameChanged;
                break;
            }
            
            SKUINavigationBarController *searchVC = _tabBarVc.selectedViewController;
            UIViewController *stackDocumentViewController = searchVC.topViewController.childViewControllers[0];
            if ([stackDocumentViewController isKindOfClass:NSClassFromString(@"SKUITrendingSearchDocumentViewController")]) {
                GLNSLog(@"##### [配对应用] 重新回到了搜索界面 #####");
                _step = BrushStepClickSeachTF;
                break;
            }
            SKUIHorizontalLockupView *horizontalLockupView = [self getHorizontalLockupViewWithAppName:appName];
            if (horizontalLockupView == nil) {
                GLNSLog(@"##### [配对应用] horizontalLockupView == nil #####");
                _step = BrushStepClickSeachTF;
                break;
            } else {
                if (taskopt & ASOTaskTypeBuy) {
                    _step = BrushStepBuyApp;
                } else if (taskopt & ASOTaskTypeQueryDetail) {
                    _step = BrushStepQueryApp;
                } else if (taskopt & ASOTaskTypeComment) {
                    _step = BrushStepQueryApp;
                } else {
                    _retCode = ASCodeSuccess;
                    _step = BrushStepFinish;
                }
                break;
            }
        }
            break;
            
        case BrushStepBuyApp:
        {
            GLNSLog(@"##### [购买应用] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            
            if (accountStatus == ASCodeFailAppleIDStop ||
                accountStatus == ASCodeFailAppleIDLocked ||
                accountStatus == ASCodeFailAppleIDNeedVerifyForSetting ||
                accountStatus == ASCodeFailAppleIDNeedVerify) {       // 被停用/被锁定/设置中验证/需要验证
                _retCode = accountStatus;
                _step = BrushStepSetTask;
                break;
            }
            
            if (_tryNum++ > 100) {
                _retCode = ASCodeFailBuyTimeout;
                _step = BrushStepSetTask;
                break;
            }
            
            SKUIHorizontalLockupView *horizontalLockupView = [self getHorizontalLockupViewWithAppName:appName];
            SKUIOfferView *offerView = (SKUIOfferView *)[ZKBaseUtil getSubViewFromParent:horizontalLockupView subViewClassName:@"SKUIOfferView"];
            SKUIItemOfferButton *itemOfferButton = (SKUIItemOfferButton *)[ZKBaseUtil getSubViewFromParent:offerView subViewClassName:@"SKUIItemOfferButton"];
            GLNSLog(@"##### [购买应用] button title = %@, progressType = %d #####",itemOfferButton.title, itemOfferButton.progressType);
            if (itemOfferButton.progressType == 0) {
                if ([itemOfferButton.title isEqualToString:@"获取"] ||
                    [itemOfferButton.title isEqualToString:@"GET"] ||
                    [itemOfferButton.title isEqualToString:@"取得"]) {
                    [offerView _buttonAction:itemOfferButton];
                } else if ([itemOfferButton.title isEqualToString:@"打开"]) {
                    notify_post(NBUninstallNotificationName);
                } else if ([itemOfferButton.title isEqualToString:@"更新"]) {
                    toast(@"删除桌面上该应用，请手动删除应用");
                } else {
                    if (ISDEBUG) {      // 测试用，帐号可以重复购买
                        [offerView _buttonAction:itemOfferButton];
                    } else {
                        GLNSLog(@"##### [购买应用]该帐号购买过这款应用 #####");
                        _tryNum = 0;
                        _step = BrushStepSetTask;
                        _retCode = ASCodeFailHadBuy;
                    }
                }
            } else if (itemOfferButton.progressType == 1) {         // 购买中
                GLNSLog(@"##### [购买应用] 购买中... #####");
                _tryNum = 0;
                _step = BrushStepWaitBuyResult;
            } else if (itemOfferButton.progressType == 2) {         // 下载中
                if (SYSTEM_VERSION_GREATER_THAN(NSFoundationVersionNumber_iOS_8_x_Max)) {       // >= 9.0
                    [offerView _buttonAction:itemOfferButton];
                } else {
                    _tryNum = 0;
                    _step = BrushStepWaitBuyResult;
                }
            }
        }
            break;
            
        case BrushStepWaitBuyResult:
        {
            GLNSLog(@"##### [等待购买结果] %lu #####", (unsigned long)_tabBarVc.selectedIndex);
            if ([[self getNavigationBarTitle] isEqualToString:@"需要验证"]) {
                GLNSLog(@"##### 等待输入验证码 #####");
                if (_waitInputVerifyCodeNum++ > 60) {
                    _tryNum = 0;
                    _retCode = ASCodeFailRecognitionVerifyCodeTimeout;
                    _step = BrushStepSetTask;
                }
                return;
            }
            
            if ([ZKDeviceLogic systemVersion_10_x]) {
                if (_tabBarVc.selectedViewController.presentedViewController != nil) {
                    // 这个是需要输入验证码才引入的
                    GLNSLog(@"##### 等待加载验证码 #####");
                    return;
                }
                
                if (accountStatus == ASCodeBuyNeedInputVerifyCode && _waitLoadVerifyCodeNum++ < 3) {
                    return;
                }
            } else {
                if (_tabBarVc.selectedIndex == __LONG_LONG_MAX__) {
                    // 这个是需要输入验证码才引入的
                    GLNSLog(@"##### 等待加载验证码 #####");
                    return;
                }
            }
            
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            
            if (accountStatus == ASCodeFailAppleIDStop ||
                accountStatus == ASCodeFailAppleIDLocked ||
                accountStatus == ASCodeFailAppleIDNeedVerifyForSetting ||
                accountStatus == ASCodeBuyNeedInputVerifyCode ||
                accountStatus == ASCodeFailAppleIDNeedVerify) {       // 被停用/被锁定/设置中验证/需要简短验证/需要验证
                _retCode = accountStatus;
                _step = BrushStepSetTask;
                break;
            }
            
            NSProgress *progress = [[LSApplicationWorkspace defaultWorkspace] installProgressForBundleID:identifier makeSynchronous:0];
            int64_t completedCount = progress ? progress.completedUnitCount : 0;
            
            SKUIHorizontalLockupView *horizontalLockupView = [self getHorizontalLockupViewWithAppName:appName];
            SKUIOfferView *offerView = (SKUIOfferView *)[ZKBaseUtil getSubViewFromParent:horizontalLockupView subViewClassName:@"SKUIOfferView"];
            SKUIItemOfferButton *itemOfferButton = (SKUIItemOfferButton *)[ZKBaseUtil getSubViewFromParent:offerView subViewClassName:@"SKUIItemOfferButton"];
            NSLog(@"##### [等待购买结果]  按钮状态 %d 进度：%lld 按钮:%@ #####", itemOfferButton.progressType, completedCount, itemOfferButton.title);
            if (itemOfferButton.progressType == 2 || completedCount > 0) {
                GLNSLog(@"##### [等待购买结果] 购买成功 #####");
                _tryNum = 0;
                _step = taskopt & ASOTaskTypeDownload ? BrushStepWaitDownload : BrushStepCancelDownload;
                
                break;
            } else if (itemOfferButton.progressType == 0) {
                if ([itemOfferButton.title isEqualToString:@"获取"] ||
                    [itemOfferButton.title isEqualToString:@"GET"] ||
                    [itemOfferButton.title isEqualToString:@"取得"]) {
                    [offerView _buttonAction:itemOfferButton];
                }
            } else if (itemOfferButton.progressType == 1) {
                GLNSLog(@"##### [等待购买结果] 购买中 ...");
            }
            
            if (_tryNum++ >= 100) {
                _tryNum = 0;
                _step = BrushStepSetTask;
                _retCode = ASCodeFailBuyTimeout;
            }
        }
            break;
            
        case BrushStepWaitDownload:
        {
            GLNSLog(@"##### [等待下载] #####");
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            
            SKUIHorizontalLockupView *horizontalLockupView = [self getHorizontalLockupViewWithAppName:appName];
            SKUIOfferView *offerView = (SKUIOfferView *)[ZKBaseUtil getSubViewFromParent:horizontalLockupView subViewClassName:@"SKUIOfferView"];
            SKUIItemOfferButton *itemOfferButton = (SKUIItemOfferButton *)[ZKBaseUtil getSubViewFromParent:offerView subViewClassName:@"SKUIItemOfferButton"];
            
            if ([itemOfferButton.title isEqualToString:@"打开"]) {
                GLNSLog(@"##### [等待下载] 下载完成 #####");
                _tryNum = 0;
                if (taskopt & ASOTaskTypeQueryDetail) {
                    _step = BrushStepQueryApp;
                } else if (taskopt & ASOTaskTypeActive) {
                    _step = BrushStepActive;
                } else {
                    _step = BrushStepSetTask;
                }
                _retCode = _step == BrushStepSetTask ? ASCodeSuccess : _retCode;
            } else {
                if (_tryNum++ >= 150) {
                    _retCode = ASCodeFailDownloadTimeout;
                    _step = BrushStepSetTask;
                    break;
                }
            }
        }
            break;
            
        case BrushStepCancelDownload:
        {
            GLNSLog(@"##### [取消下载] #####");
            _tryNum++;
            if (_isCancelDownloading && ((_tryNum + 1) % 3 != 2)) {
                GLNSLog(@"##### [取消下载] 取消下载中...... ######");
                break;
            }
            _isCancelDownloading = NO;
            if (_tryNum > 30) {
                GLNSLog(@"#### [取消下载] 超时 #####");
                _retCode = ASCodeSuccess;
                _step = BrushStepSetTask;
                break;
            }
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            
            NSProgress *progress = [[LSApplicationWorkspace defaultWorkspace] installProgressForBundleID:identifier makeSynchronous:0];
            int64_t completedCount = progress ? progress.completedUnitCount : 0;
            
            SKUIHorizontalLockupView *horizontalLockupView = [self getHorizontalLockupViewWithAppName:appName];
            SKUIOfferView *offerView = (SKUIOfferView *)[ZKBaseUtil getSubViewFromParent:horizontalLockupView subViewClassName:@"SKUIOfferView"];
            SKUIItemOfferButton *itemOfferButton = (SKUIItemOfferButton *)[ZKBaseUtil getSubViewFromParent:offerView subViewClassName:@"SKUIItemOfferButton"];
            
            GLNSLog(@"##### [取消下载]  按钮状态 %d 进度:%lld #####", itemOfferButton.progressType, completedCount);
            if (itemOfferButton.progressType == 2 || completedCount > 0) {
                NSLog(@"##### [取消下载] 点击 #####");
                _isCancelDownloading = YES;
                [offerView _buttonAction:itemOfferButton];
//                sleep(3.0);
//                _isCancelDownloading = NO;
            } else if (itemOfferButton.progressType == 0) {
                if (taskopt & ASOTaskTypeQueryDetail) {
                    _step = BrushStepQueryApp;
                } else if (taskopt & ASOTaskTypeBuyActive) {
                    self.isDownloading = NO;
                    self.isInstalling = NO;
                    self.checkingQiankaTask = NO;
                    _step = BrushStepDownloadIPA;
                } else {
                    _step = BrushStepSetTask;
                }
                _tryNum = 0;
                _retCode = _step == BrushStepSetTask ? ASCodeSuccess : _retCode;
            } else {
                // 正常不会走到这里，为了处理异常应用，比如百度地图(地图)  大众点评(装修)  V2.06.01
                if (completedCount <= 0) {
                    if (taskopt & ASOTaskTypeQueryDetail) {
                        _step = BrushStepQueryApp;
                    } else if (taskopt & ASOTaskTypeBuyActive) {
                        self.isDownloading = NO;
                        self.isInstalling = NO;
                        self.checkingQiankaTask = NO;
                        _step = BrushStepDownloadIPA;
                    } else {
                        _step = BrushStepSetTask;
                    }
                    _tryNum = 0;
                    _retCode = _step == BrushStepSetTask ? ASCodeSuccess : _retCode;
                }
            }
        }
            break;
            
        case BrushStepQueryApp:
        {
            NSUInteger itemsCount = _tabBarVc.tabBar.items.count;
            if (_tabBarVc.selectedIndex != itemsCount - 2) {
                _step = BrushStepClickSearacBar;
                break;
            }
            
            if (_tryNum == 0) {
                GLNSLog(@"##### [查看应用详情] #####");
                SKUIStorePageSectionsViewController *storePageSectionsVC = [self getStorePageSectionsViewController];
                if (storePageSectionsVC == nil) {
                    GLNSLog(@"##### [查看应用详情] storePageSectionsVC == nil #####");
                    break;
                }
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.appPosIndex inSection:0];
                [storePageSectionsVC collectionView:storePageSectionsVC didSelectItemAtIndexPath:indexPath];
                _tryNum++;
            } else if (_tryNum >= 3) {
                if (taskopt & ASOTaskTypeActive) {
                    _step = BrushStepActive;
                } else if (taskopt & ASOTaskTypeBuyActive) {
                    self.isDownloading = NO;
                    self.isInstalling = NO;
                    self.checkingQiankaTask = NO;
                    _step = BrushStepDownloadIPA;
                } else if (taskopt & ASOTaskTypeComment) {
                    _step = BrushStepComment;
                } else {
                    _step = BrushStepSetTask;
                    _retCode = ASCodeSuccess;
                }
                _tryNum = 0;
            } else {
                _tryNum++;
            }
        }
            break;
            
        case BrushStepComment:
        {
            SKUINavigationBarController *navController = _tabBarVc.selectedViewController;
            UIView *view = [ZKBaseUtil getSubViewFromParent:navController.view subViewClassName:@"UINavigationTransitionView"];
            if (view) {
                view = [ZKBaseUtil getSubViewFromParent:view subViewClassName:@"UIViewControllerWrapperView"];
                view = [ZKBaseUtil getSubViewFromParent:view subViewClassName:@"UIView"];
                view = [ZKBaseUtil getSubViewFromParent:view subViewClassName:@"UIView"];
                view = [ZKBaseUtil getSubViewFromParent:view subViewClassName:@"UIView"];
                SKUICollectionView *collectionView = (SKUICollectionView *)[ZKBaseUtil getSubViewFromParent:view subViewClassName:@"SKUICollectionView"];
                view = [ZKBaseUtil getSubViewFromParent:collectionView subViewClassName:@"SKUISegmentedControlCollectionViewCell"];
                view = [ZKBaseUtil getSubViewFromParent:view subViewClassName:@"UIView"];
                SKUIFlexibleSegmentedControl *flexSegControl = (SKUIFlexibleSegmentedControl *)[ZKBaseUtil getSubViewFromParent:view subViewClassName:@"SKUIFlexibleSegmentedControl"];
                UISegmentedControl *segControl = (UISegmentedControl *)[ZKBaseUtil getSubViewFromParent:flexSegControl subViewClassName:@"UISegmentedControl"];
                if (segControl.selectedSegmentIndex != 1) {
                    segControl.selectedSegmentIndex = 1;
                    [flexSegControl _valueChangeAction:segControl];
                } else {
                    if (![_tabBarVc.presentedViewController isKindOfClass:NSClassFromString(@"SKComposeReviewViewController")]) {
                        NSLog(@"点击评论按钮");
                        NSArray *cells = [ZKBaseUtil getSubViewFromParent:collectionView subViewsClassName:@"SKUIButtonCollectionViewCell"];
                        for (SKUIButtonCollectionViewCell *cell in cells) {
                            UIView *subview = [ZKBaseUtil getSubViewFromParent:cell subViewClassName:@"UIView"];
                            SKUIStyledButton *styledButton = (SKUIStyledButton *)[ZKBaseUtil getSubViewFromParent:subview subViewClassName:@"SKUIStyledButton"];
                            SKUIAttributedStringView *attrStrView = (SKUIAttributedStringView *)[ZKBaseUtil getSubViewFromParent:styledButton subViewClassName:@"SKUIAttributedStringView"];
                            if ([attrStrView.layout.attributedString.string isEqualToString:@"撰写评论"]) {
                                [cell _buttonAction:styledButton];
                                break;
                            }
                        }
                    } else {
                        NSLog(@"开始写评论");
                    }
                    
                }
                
                
            }
        }
            break;
            
        case BrushStepDownloadIPA:
        {
            if (self.isDownloading) {
                if (_tryNum++ >= 300) {           // 10分钟
                    _retCode = ASCodeFailDownloadIPA;
                    _step = BrushStepSetTask;
                    return;
                }
                NSString *tipMsg = [NSString stringWithFormat:@"下载进度：%.1f%@", self.downloadProgress * 100, @"%"];
                toast(tipMsg);
                return;
            }
            if (self.isInstalling) {
                _tryNum++;
                if ([[LSApplicationWorkspace defaultWorkspace] applicationIsInstalled:identifier]) {
                    _tryNum = 0;
                    _step = BrushStepActive;
                    GLNSLog(@"##### 应用已经安装好 #####");
                    return;
                } else if (_tryNum >= 90) {        // 五分钟
                    _retCode = ASCodeFailInstall;
                    _step = BrushStepSetTask;
                    return;
                }
                toast(@"安装中...");
                return;
            }
            if (self.checkingQiankaTask) {
                toast(@"买量确认中...");
                return;
            }
            
            NSString *ipaCachePath = [NSString stringWithFormat:@"%@ipa/", [CfgManager getAppDocumentsPath:AppStoreIdentifier]];
            NSString *appIpaCachePath = [NSString stringWithFormat:@"%@%@/", ipaCachePath, appid];
            if (![FileLogic isDirectoryExistsAtPath:ipaCachePath]) {
                [FileLogic createDirectoryAtPath:ipaCachePath];
            }
            if (![FileLogic isDirectoryExistsAtPath:appIpaCachePath]) {
                [FileLogic createDirectoryAtPath:appIpaCachePath];
            }
            
            NSString *ipafile = [NSString stringWithFormat:@"%@%@_v%@.ipa", appIpaCachePath, appid, ipaVerString];
            NSLog(@"##### 本地缓冲ipa路径：%@ #####", ipafile);
            NSArray *allVerIpa = [FileLogic allFilesAtDirectoryPath:appIpaCachePath];
            for (NSString *file in allVerIpa) {
                if ([file isEqualToString:ipafile]) {
                    continue;
                }
                [[NSFileManager defaultManager] removeItemAtPath:file error:nil];
            }
            
            
            if (![[NSFileManager defaultManager] fileExistsAtPath:ipafile]) {
                NSString *url = [NSString stringWithFormat:@"http://192.168.2.200/ipa/%@/%@_v%@.ipa", appid, appid, ipaVerString];
                NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
                [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
                self.isDownloading = YES;
                GLNSLog(@"##### 开始下载ipa #####");
            } else {
                GLNSLog(@"##### 下载ipa  已经存在: %@ #####", ipafile);
                _tryNum = 0;
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    if (taskopt & ASOTaskTypeBuyActive) {
                        self.checkingQiankaTask = YES;
                        NSError *error = nil;
                        BOOL bRet = NO;
                        
                        bRet = [[YDActivateTaskManager sharedManager] isNewUserWithError:&error];
                        if (bRet && error == nil) {
                            [NSThread sleepForTimeInterval:3.0f];
                            bRet = [[YDActivateTaskManager sharedManager] getNewTaskWithError:&error];
                            if (!(bRet && error == nil)) {
                                _retCode = ASCodeFailGetActivateTask;
                                _step = BrushStepSetTask;
                                self.activeCheckErrMsg = error ?  [error.userInfo objectForKey:NSLocalizedDescriptionKey] : @"";
                                return;
                            }
                        } else {
                            _retCode = ASCodeFailNoNewUser;
                            _step = BrushStepSetTask;
                            self.activeCheckErrMsg = error ?  [error.userInfo objectForKey:NSLocalizedDescriptionKey] : @"";
                            return;
                        }
                        self.checkingQiankaTask = NO;
                    }
                    
                    if ([[AppManager defaultManager] appIsInstalled:identifier]) {
                        self.isInstalling = YES;
                        [[AppManager defaultManager] openAppWithIdentifier:identifier];
                    } else {
                        self.isInstalling = YES;
                        NSString *tmpIpa = [NSString stringWithFormat:@"%@%@", [CfgManager getAppDocumentsPath:AppStoreIdentifier], IPAName];
                        
                        unlink([tmpIpa UTF8String]);
                        if (link([ipafile UTF8String], [tmpIpa UTF8String]) == 0) {
                            GLNSLog(@"##### 创建ipa软连接成功 #####");
                            notify_post(NBInstallNotificationName);
                        } else {
                            _step = BrushStepSetTask;
                            _retCode = ASCodeFailCreateSymlinkIpa;
                            GLNSLog(@"##### 创建ipa软连接失败 #####");
                        }
                    }
                });
            }
        }
            break;
            
        case BrushStepActive:
        {
            GLNSLog(@"##### [激活应用] #####");
            if (_tryNum > 5) {
                if (taskopt & ASOTaskTypeBuyActive) {
                    NSError *error;
                    [[YDActivateTaskManager sharedManager] checkActivedStatusWithError:&error];
                }
                _tryNum = 0;
                _step = BrushStepSetTask;
                _retCode = _step == BrushStepSetTask ? ASCodeSuccess : _retCode;
            } else {
                _tryNum++;
            }
        }
            break;
            
        case BrushStepSetTask:
        {
            if (_isTaskSetting) {
                GLNSLog(@"##### [任务上报] 上报中... #####");
                return;
            }
            
            if (ISDEBUG) {
                _tryNum = 0;
                _step = BrushStepFinish;
            } else {
                [VPNManager setVPNEnabled:NO];
                _isTaskSetting = YES;
                [[TaskManager defaultManager] saveTaskResult:_retCode errorMessage:self.activeCheckErrMsg completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
                    _isTaskSetting = NO;
                    _tryNum++;
                    if (connectionError) {
                        GLNSLog(@"##### [任务上报]错误 : %@ #####", connectionError);
                        if (_tryNum >= 3) {
                            _tryNum = 0;
                            _step = BrushStepFinish;
                        }
                    } else {
                        _tryNum = 0;
                        _step = BrushStepFinish;
                        
                        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
                        GLNSLog(@"##### [任务上报]结果 : %@ #####", jsonDict);
                        if ([[jsonDict valueForKey:@"Code"] intValue] == 1) {
                            GLNSLog(@"##### [任务上报]成功 #####");
                        } else {
                            GLNSLog(@"##### [任务上报]失败:%@ #####", jsonDict);
                        }
                    }
                }];
            }
        }
            break;
            
        case BrushStepFinish:
        {
            GLNSLog(@"##### [流程结束]检测是否有注销的帐号 #####");
            if ((taskopt & ASOTaskTypeBuy)) {
                SSAccountStore *accountStore = [SSAccountStore defaultStore];
                if (accountStore && accountStore.activeAccount) {
                    [accountStore signOutAccount:accountStore.activeAccount];
                }
            }
            
            if (_retCode == ASCodeSuccess) {
                toast(@"任务完成");
            } else if (_retCode == ASCodeNoTask || _retCode == ASCodeGetTaskError) {
                toast(_serverTaskMsg);
            } else if (_retCode == ASCodeNetError) {
                toast(@"网络有问题，请检查");
            } else if (_retCode == ASCodeServerException) {
                toast(@"服务器异常");
            } else if (_retCode == ASCodeUpdate) {
                [[AppManager defaultManager] openTouchSprite];
            } else if (_retCode == ASCodeFailAppNameChanged) {
                toast(@"应用名称不匹配，请检查");
            } else if (_retCode == ASCodeFailNoNewUser) {
                toast(@"买激活，旧用户");
            } else {
                toast(@"任务失败");
            }
            GLNSLog(@"##### 任务结果: %d #####", _retCode);
            
            _step = BrushStepCloseAppStore;
        }
            break;
            
        case BrushStepCloseAppStore:
        {
            if (_processTimer) {
                [_processTimer invalidate];
                _processTimer = nil;
            }
            
            if (_retCode != ASCodeUpdate) {
                [[NBNotificationCenter defaultCenter] postKillProcessNotify:@[@"AppStore"]];
            }
            
//            [UIView animateWithDuration:0.3f animations:^{
//                UIWindow *window = [UIApplication sharedApplication].keyWindow;
//                window.alpha = 0;
//                window.frame = CGRectMake(0, window.bounds.size.width, 0, 0);
//            } completion:^(BOOL finished) {
//                exit(0);
//            }];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark -NSURLConnectionDataDelegate
// 请求失败时调用（请求超时，网络超时）
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    _retCode = ASCodeFailConnectInner;
    _step = BrushStepSetTask;
}

// 接受到服务器的响应时候会调用
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    if (httpResponse.statusCode == 200) {
        self.fileData = [NSMutableData data];
        self.totalLength = response.expectedContentLength;
    } else {
        toast(@"ipa资源不存在");
        GLNSLog(@"##### 下载ipa包出错：%@ #####", httpResponse);
        [connection cancel];
        _retCode = ASCodeFailNoExistIpa;
        _step = BrushStepSetTask;
    }
}

// 接受到服务器返回实体数据时候调用
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.fileData appendData:data];
    self.downloadProgress = (float)self.fileData.length/self.totalLength;
    GLNSLog(@"##### 下载进度: %li/%lli %f #####", (unsigned long)self.fileData.length, self.totalLength, self.downloadProgress);
}

// 加载完毕后调用
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    NSString *appid = [taskDict valueForKey:TaskKeyAppID];
    
    NSString *ipaCachePath = [NSString stringWithFormat:@"%@ipa/", [CfgManager getAppDocumentsPath:AppStoreIdentifier]];
    NSString *appIpaCachePath = [NSString stringWithFormat:@"%@%@/", ipaCachePath, appid];
    if (![FileLogic isDirectoryExistsAtPath:ipaCachePath]) {
        [FileLogic createDirectoryAtPath:ipaCachePath];
    }
    if (![FileLogic isDirectoryExistsAtPath:appIpaCachePath]) {
        [FileLogic createDirectoryAtPath:appIpaCachePath];
    }
    
    NSString *ipaVerString = [taskDict valueForKey:TaskKeyIpaVer];
    NSString *ipafile = [NSString stringWithFormat:@"%@%@_v%@.ipa", appIpaCachePath, appid, ipaVerString];
    if ([self.fileData writeToFile:ipafile atomically:YES]) {
        GLNSLog(@"保存ipa成功");
    } else {
        GLNSLog(@"保存ipa失败");
    }
    self.isDownloading = NO;
    self.isInstalling = NO;
    GLNSLog(@"##### 下载ipa 保存：%@", ipafile);
}

@end
