//
//  BrushAppManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/21.
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(int, BrushStep) {
    BrushStepCheckAppStore,
    BrushStepGetTask,               // 获取任务
    BrushStepSaveTaskFile,          // 保存任务文件
    BrushStepSetTask,               // 保存任务结果
    BrushStepOneKeyNew,             // 一键新机
    BrushStepCheckIp,               // 检查ip是否重复
    BrushStepCheckApp,              // 检测应用是否有安装
    BrushStepChangeVPN,             // 切换vpn
    BrushStepDownloadIPA,           // 下载内网ipa
    BrushStepLoginItunes,           // 登录itunes
    BrushStepCheckTabBar,           // 检测最下面工具栏
    BrushStepClickSearacBar,        // 点击搜索
    BrushStepCheckSeachTF,          // 检测搜索框
    BrushStepClickSeachTF,          // 点击搜索框
    BrushStepSearchKeyword,         // 搜索关键字
    BrushStepWaitSearchResult,      // 等待搜索结果
    BrushStepScrollToAppPos,        // 滚动到应用的位置
    BrushStepMatchApp,              // 配对应用
    BrushStepBuyApp,                // 购买应用
    BrushStepWaitBuyResult,         // 等待购买结果
    BrushStepQueryApp,              // 查看应用详情
    BrushStepComment,               // 评论
    BrushStepWaitDownload,          // 等待下载
    BrushStepCancelDownload,        // 取消下载
    BrushStepActive,                // 激活应用
    BrushStepFinish,
    BrushStepCloseAppStore,         // 关闭
};

#define BrushSingeton           [BrushAppManager defaultManager]

@interface BrushAppManager : NSObject

@property (nonatomic, assign) int appPosIndex;
@property (nonatomic, assign) int storeDataResultsNum;
@property (nonatomic, strong) NSMutableDictionary *cacheAppDict;

+ (BrushAppManager*)defaultManager;

- (void)startBrushApp;

@end
