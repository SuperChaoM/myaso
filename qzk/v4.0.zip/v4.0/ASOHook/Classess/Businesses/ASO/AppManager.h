//
//  AppManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/19.
//
//

#import <Foundation/Foundation.h>

@interface AppManager : NSObject

+ (AppManager*)defaultManager;

@property (nonatomic, strong) id theSpringBoard;

- (BOOL)appIsInstalled:(NSString *)identifier;

- (void)handlerForInstallAfter:(NSNotification *)notification;

- (void)appActiveAfterAction:(NSString *)identifier;

- (void)uninstallApp:(NSString *)identifier;

- (void)openAppStore;

- (void)openTouchSprite;

- (void)openPreferences;

- (void)openAppWithIdentifier:(NSString *)identifier;

@end
