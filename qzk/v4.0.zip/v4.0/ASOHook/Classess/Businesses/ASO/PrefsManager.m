//
//  VPNManager.m
//  ASOHook
//
//  Created by 邱智铠 on 2017/10/28.
//
//

#import "PrefsManager.h"

#import "ZKBaseUtil.h"
#import "VPNManager.h"
#import "AppManager.h"
#import "TaskManager.h"

@implementation PrefsManager

+ (PrefsManager *)defaultManager {
    static id g_instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        g_instance = [[PrefsManager alloc] init];
    });
    
    return g_instance;
}

- (void)checkVPNConfig:(UIApplication *)app {
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    if (![[taskDict valueForKey:TaskKeyChangeVPN] boolValue]) {
        return;
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIWindow *window = [app performSelector:@selector(keyWindow)];
        UINavigationBar *bar = window.rootViewController.view.subviews[1].subviews[1];
        if (bar) {
            UIView *navItemView = [ZKBaseUtil getSubViewFromParent:bar subViewClassName:@"UINavigationItemView"];
            if (navItemView) {
                UILabel *label = (UILabel *)[ZKBaseUtil getSubViewFromParent:navItemView subViewClassName:@"UILabel"];
                if (label && [@"VPN" isEqualToString:label.text]) {         // vpn页面
                    if (self.isVPNSwitching) {
                        return;
                    }
                    self.isVPNSwitching = YES;
                    UITableView *tableView = window.rootViewController.view.subviews[1].subviews[0].subviews[0].subviews[0].subviews[0].subviews[0].subviews[0].subviews[0];
                    long vpnNum = tableView.numberOfSections - 1;
                    [self doSwitchVPNAction:vpnNum];
                }
            }
        }
    });
}

- (void)doSwitchVPNAction:(long)vpns {
    if (vpns <= 0) {
        // 没有vpn配置
        self.isVPNSwitching = NO;
        [[AppManager defaultManager] openAppStore];
        return ;
    } else {
        // 切换vpn
        if ([VPNManager VPNIsConnected]) {
            [VPNManager setVPNEnabled:NO];
        }
        int retryNum = 10;
        for (int i = 1; i <= retryNum; i++) {
            [VPNManager setVPNEnabled:YES];
            [NSThread sleepForTimeInterval:5.0f];
            if ([VPNManager VPNIsConnected] || i == retryNum) {
                [NSThread sleepForTimeInterval:2.0f];
                self.isVPNSwitching = NO;
                [[AppManager defaultManager] openAppStore];
                return;
            } else {
                GLNSLog(@"##### [VPN] 连接中 #####");
            }
        }
    }
}

@end
