//
//  AppManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/19.
//
//

#import "AppManager.h"
#import "CfgManager.h"
#import "TaskManager.h"
#import "BrushAppManager.h"
#import "ZKStoreServices.h"
#import "MyTouch.h"
#import "ZKBaseUtil.h"

#import <MobileCoreServices/LSApplicationWorkspace.h>
#import <MobileCoreServices/LSApplicationProxy.h>

@interface AppManager ()

@property (nonatomic, strong) NSMutableDictionary *cacheAppDict;

@end

@implementation AppManager

+ (AppManager *)defaultManager {
    static AppManager *_manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [[AppManager alloc] init];
    });
    
    return _manager;
}

- (instancetype)init {
    if (self = [super init]) {
        self.cacheAppDict = [NSMutableDictionary dictionary];
    }
    
    return self;
}

- (BOOL)appIsInstalled:(NSString *)identifier {
    NSArray<LSApplicationProxy *> *appList = [[LSApplicationWorkspace defaultWorkspace] allApplications];
    BOOL isInstalled = [[LSApplicationWorkspace defaultWorkspace] applicationIsInstalled:identifier];
    for (LSApplicationProxy *appProxy in appList) {
        if (![appProxy.applicationType isEqualToString:@"User"]) {
            continue;
        }
        if (![identifier isEqualToString:appProxy.applicationIdentifier]) {
            continue;
        }
        if (appProxy.isPlaceholder == 1) {
            isInstalled = NO;
        }
        
        break;
    }
    
    return isInstalled;
}

#pragma mark - 应用安装完成后控制
- (void)handlerForInstallAfter:(NSNotification *)notification {
    GLNSLog(@"###### [安装/卸载] notification:%@ #####", notification);
    NSDictionary *userInfo = notification.userInfo;
    NSSet *bundleIDsSet = [userInfo valueForKey:@"SBInstalledApplicationsAddedBundleIDs"];
    NSArray *bundleIDs = [bundleIDsSet allObjects];
    
    GLNSLog(@"###### [安装/卸载] bundleIDs:%@ #####", bundleIDs);
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    if (taskDict != nil) {
        NSString *appIdentifier = [taskDict valueForKey:TaskKeyIdentifier];
        if (appIdentifier != nil && ![appIdentifier isEqualToString:@""]) {
            if ([bundleIDs containsObject:appIdentifier]) {
                NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(runOpenAction:) object:taskDict];
                [thread start];
            }
        } else {
            GLNSLog(@"##### [安装/卸载]安装完成 identifier:%@ #####", appIdentifier);
        }
    } else {
        GLNSLog(@"##### [安装/卸载] 没有要卸载的任务 #####");
    }
}

-(void)runOpenAction:(id)sender {
    NSDictionary *task = (NSDictionary *)sender;
    NSString *appIdentifier = [task valueForKey:TaskKeyIdentifier];
    NSString *strActive = [task valueForKey:TaskKeyIsActive];
    NSString *strBuyActive = [task valueForKey:TaskKeyIsBuyActive];
    
    // 收到卸载通知，只做卸载，不做激活
    NSString *uninstalltxt = [NSString stringWithFormat:@"%@%@", [CfgManager getAppDocumentsPath:AppStoreIdentifier], FlagUninstall];
    if ([[NSFileManager defaultManager] fileExistsAtPath:uninstalltxt]) {
        [[NSFileManager defaultManager] removeItemAtPath:uninstalltxt error:nil];
        [self performSelector:NSSelectorFromString(@"uninstallApp:") withObject:appIdentifier];
        return;
    }
    
    
    if ((strActive != nil && [strActive isEqualToString:@"1"]) ||
        (strBuyActive != nil && [strBuyActive isEqualToString:@"1"])) {
        [self performSelector:NSSelectorFromString(@"openAppWithIdentifier:") withObject:appIdentifier];
    }
}

- (void)appActiveAfterAction:(NSString *)identifier {
    //NSLog(@"应用被激活:%@", identifier);
    NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
    NSString *appIdentifier = [taskDict valueForKey:TaskKeyIdentifier];
    
    if ([identifier isEqualToString:@"com.digizen.g2u"]) {      // 寄意
        for (int i = 0; i < 8; i++) {
            if (i == 7) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)((10 + i * 2) * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [MyTouch touch:CGPointMake(162, 472)];
                });
            } else {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)((10 + i * 2) * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [MyTouch swipeFromPoint:CGPointMake(250, 500) toPoint:CGPointMake(100, 550)];
                });
            }
        }
    }
    
    if ([appIdentifier isEqualToString:identifier]) {
        NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(runActiveAction:) object:taskDict];
        [thread start];
    }
}

-(void)runActiveAction:(id)sender {
    NSDictionary *task = (NSDictionary *)sender;
    NSString *appIdentifier = [task valueForKey:TaskKeyIdentifier];
    NSString *strBuyActive = [task valueForKey:TaskKeyIsBuyActive];
    NSString *strInterval = [task valueForKey:TaskKeyInterval];
    float fInterval = 10.0f;
    if (strInterval != nil && ![strInterval isEqual:@""]) {
        fInterval = [strInterval intValue];
    }
    
    if (strBuyActive != nil && [strBuyActive isEqualToString:@"1"]) {
        sleep(fInterval);
        
        NSMutableDictionary *taskDict = [[TaskManager defaultManager] getTaskDictionary];
        BOOL bUnstall = [[taskDict valueForKey:TaskKeyActiveNotUnstall] intValue] == 1;
        if (!bUnstall) {
            NSLog(@"##### 卸载应用 #####");
            [self performSelector:NSSelectorFromString(@"uninstallApp:") withObject:appIdentifier];
        } else {
            NSLog(@"##### 关闭应用  #####");
            [self performSelector:NSSelectorFromString(@"killApplication:") withObject:appIdentifier];
        }
    } else {
        [self performSelector:NSSelectorFromString(@"uninstallApp:") withObject:appIdentifier];
    }
    
    sleep(1.0f);
    [self openAppStore];
}

- (void)uninstallApp:(NSString *)identifier {
    GLNSLog(@"#### [安装/卸载]卸载应用: %@ ####", identifier);
    NSDictionary *opt = [NSDictionary dictionaryWithObject:@"User" forKey:@"ApplicationType"];
    id workspace = [NSClassFromString(@"LSApplicationWorkspace") performSelector:NSSelectorFromString(@"defaultWorkspace")];
    [workspace performSelector:NSSelectorFromString(@"uninstallApplication:withOptions:") withObject:identifier withObject:opt];
}

- (void)openAppStore {
    GLNSLog(@"##### open AppStore #####");
    [self openAppWithIdentifier:AppStoreIdentifier];
}

- (void)openTouchSprite {
    GLNSLog(@"##### 打开触动精灵 #####");
    [self openAppWithIdentifier:TSIdentifier];
}

- (void)openPreferences {
    GLNSLog(@"##### 打开设置 #####");
    [self openAppWithIdentifier:PreferencesIdentifier];
}

- (void)openAppWithIdentifier:(NSString *)identifier {
    GLNSLog(@"##### openAppWithIdentifier:%@ #####", identifier);
    id workspace = [NSClassFromString(@"LSApplicationWorkspace") performSelector:NSSelectorFromString(@"defaultWorkspace")];
    [workspace performSelector:NSSelectorFromString(@"openApplicationWithBundleID:") withObject:identifier];
}

- (void)killApplication:(NSString *)identifier {
    NSArray *allApps = [[LSApplicationWorkspace defaultWorkspace] allInstalledApplications];
    for (LSApplicationProxy *proxy in allApps) {
        if ([proxy.applicationIdentifier isEqualToString:identifier]) {
            NSString *bundleURLString = [proxy.bundleURL.absoluteString stringByReplacingOccurrencesOfString:@".app" withString:@""];
            NSArray *arr = [bundleURLString componentsSeparatedByString:@"/"];
            if (arr.count > 1) {
                NSString *executeName = [arr objectAtIndex:arr.count - 1];
                NSString *cmdString = [NSString stringWithFormat:@"killall -9 %@", executeName];
                [ZKBaseUtil executeCMD:cmdString error:nil];
            } else {
                [self performSelector:NSSelectorFromString(@"uninstallApp:") withObject:identifier];
            }
            break;
        }
    }
}

@end
