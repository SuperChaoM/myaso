//
//  TaskManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/19.
//
//

#import <Foundation/Foundation.h>

typedef void (^TaskBlock)(NSURLResponse* response, NSData* data, NSError* connectionError);

@interface TaskManager : NSObject

+ (TaskManager *)defaultManager;

- (void)exectableNextTask;

- (void)saveTaskResult:(ASCode)code errorMessage:(NSString *)errMsg completionHandler:(TaskBlock)handler;

- (NSDictionary *)getTask:(NSError **)error completionHandler:(TaskBlock)handler;

- (void)checkIPWithCompletionHandler:(TaskBlock)handler;

- (BOOL)saveTaskFile:(NSDictionary *)task;

- (NSMutableDictionary *)getTaskDictionary;

@end
