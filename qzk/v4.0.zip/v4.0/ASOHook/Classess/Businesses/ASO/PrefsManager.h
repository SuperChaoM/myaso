//
//  VPNManager.h
//  ASOHook
//
//  Created by 邱智铠 on 2017/10/28.
//
//

#import <Foundation/Foundation.h>

@interface PrefsManager : NSObject

+ (PrefsManager *)defaultManager;

- (void)checkVPNConfig:(UIApplication *)app;

@property (nonatomic, assign) BOOL isVPNSwitching;

@end
