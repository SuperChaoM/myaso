//
//  CacheManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/11/19.
//
//

#import "CacheManager.h"
#import "CfgManager.h"
#import "ZKDeviceLogic.h"

@interface CacheManager ()
{
    int _preCacheCleanupTimeInterval;
}

@end

@implementation CacheManager

+ (CacheManager *)defaultManager {
    static CacheManager *_manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [[CacheManager alloc] init];
    });
    return _manager;
}

- (instancetype)init {
    if (self = [super init]) {
        _preCacheCleanupTimeInterval = 0;
    }
    
    return self;
}

- (BOOL)checkCacheIsCleanup {
    GLNSLog(@"##### CacheManager checkCacheIsCleanup #####");
    int clearInterval = 60 * 60 * 24 * 365;           // 三天更新一次
    int nowTimeInterval = (int)[[NSDate date] timeIntervalSince1970];
    if (nowTimeInterval - _preCacheCleanupTimeInterval < clearInterval) {
        GLNSLog(@"##### CacheManager checkCacheIsCleanup 不需要清理缓存 111 #####");
        return NO;
    }
    
    NSString *filePath = [CfgManager getTweakConfigurePath];
    NSError *error = nil;
    NSString *content = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    if (error) {
        GLNSLog(@"##### CacheManager checkCacheIsCleanup 不需要清理缓存 222 error:%@ #####", error);
        return NO;
    }
    GLNSLog(@"##### CacheManager checkCacheIsCleanup 缓存配置内容:%@ #####", content);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData: [content dataUsingEncoding:NSUTF8StringEncoding]
                                                               options: NSJSONReadingMutableContainers
                                                                 error: &error];
    if (![dict isKindOfClass:[NSDictionary class]]) {
        NSLog(@"##### CacheManager checkCacheIsCleanup 读取出来的数据不是字典 #####");
        return NO;
    }
    _preCacheCleanupTimeInterval = [[dict valueForKey:@"Date"] intValue];
    int needSec = _preCacheCleanupTimeInterval + clearInterval - nowTimeInterval;
    if (needSec > 0) {
        GLNSLog(@"##### CacheManager checkCacheIsCleanup 还需要 %d 秒才会进行清理 #####", needSec);
        return NO;
    }
    GLNSLog(@"##### CacheManager checkCacheIsCleanup 需要清理缓存 #####");
    
    return YES;
}

- (void)saveCacheCfg {
    NSDate *nowDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *datestr = [dateFormatter stringFromDate:nowDate];
    int nowTimeInterval = (int)[nowDate timeIntervalSince1970];
    
    NSString *filePath = [CfgManager getTweakConfigurePath];
    NSString *content = [NSString stringWithFormat:@"{\"cacheUpdate\":\"%@\", \"Date\":\"%d\"}",
                         datestr, nowTimeInterval];
    GLNSLog(@"##### CacheManager saveCacheCfg 内容: %@ #####", content);
    NSError *error = nil;
    [content writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (error) {
        GLNSLog(@"##### CacheManager saveCacheCfg 保存失败 error:%@ #####", error);
    } else {
        GLNSLog(@"##### CacheManager saveCacheCfg 保存成功 #####");
    }
}

- (BOOL)clearup {
    if ([ZKDeviceLogic systemVersion_10_x]) {
        return YES;
    }
    NSArray *paths = [NSArray arrayWithObjects:
                      @"/var/mobile/Library/FairPlay/iTunes_Control/iTunes",
                      @"/var/mobile/Library/com.apple.itunesstored",
                      @"/var/mobile/Library/Caches",
                      @"/var/mobile/Library/Accounts",          // 这个是关键，当帐号过多时候，购买会很慢
                      @"/var/mobile/Library/Cookies",           // 这个是关键，当帐号过多时候，登录会很慢
                      @"/var/mobile/Library/Logs",
                      nil];
    
    for (NSString *path in paths) {
        NSError *error = nil;
        [[NSFileManager defaultManager] removeItemAtPath:path error:&error];
        
        if (error) {
            GLNSLog(@"##### 清空缓存路径:%@ error:%@ #####", path, error);
        } else {
            GLNSLog(@"##### 清空缓存路径:%@ #####", path);
        }
    }
    return YES;
}

#pragma mark - 文件／文件夹  大小
//单个文件的大小
- (long long) fileSizeAtPath:(NSString*) filePath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]){
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
    }
    return 0;
}

//遍历文件夹获得文件夹大小，返回多少M
- (float ) folderSizeAtPath:(NSString*) folderPath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:folderPath]) return 0;
    NSEnumerator *childFilesEnumerator = [[manager subpathsAtPath:folderPath] objectEnumerator];
    NSString* fileName;
    long long folderSize = 0;
    while ((fileName = [childFilesEnumerator nextObject]) != nil){
        NSString* fileAbsolutePath = [folderPath stringByAppendingPathComponent:fileName];
        folderSize += [self fileSizeAtPath:fileAbsolutePath];
    }
    return folderSize/(1024.0*1024.0);
}

@end
