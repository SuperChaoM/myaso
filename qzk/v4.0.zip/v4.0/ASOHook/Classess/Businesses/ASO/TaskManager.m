//
//  TaskManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/19.
//
//

#import "TaskManager.h"
#import "CfgManager.h"

#import "AlertManager.h"
#import "AppManager.h"
#import "VPNManager.h"
#import "CfgManager.h"

#import "ZKBaseUtil.h"
#import "Global.h"

@interface TaskManager ()

@property (nonatomic, assign) int runNumber;

@end

@implementation TaskManager

+ (TaskManager *)defaultManager {
    static TaskManager *_manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [[TaskManager alloc] init];
    });
    return _manager;
}

- (instancetype)init {
    if (self = [super init]) {
        self.runNumber = 0;
    }
    return self;
}

- (void)exectableNextTask {
    NSString *sMsg = [NSString stringWithFormat:@"%@ 获取任务", [Global ASOVersion]];
    [[AlertManager defaultManager] SBToast:sMsg];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [VPNManager setVPNEnabled:NO];
        // 获取任务
        if (ISDEBUG) {
            //携程旅行-预定酒店机票火车票助手      ctrip.com           379395415       淘宝
            //艺龙旅行-酒店机票火车票预订助手      com.elong.app       388089858       百度
            //王者荣耀                              com.tencent.smoba   989673964       手游
            //驴妈妈旅游-订景点门票机票火车票特价酒店  com.Lvmama.Lvmama  443926246    酒店
            //去哪儿旅行-预订机票酒店火车票特价旅游自由行   com.qunar.iphoneclient8     395096736
            NSMutableDictionary *dict = [NSMutableDictionary dictionary];
            [dict setValue:@"123-145" forKey:@"TaskID"];
            [dict setValue:@"zhenhaowan32@163.com" forKey:@"AppleID"];
            [dict setValue:@"As098765" forKey:@"Pwd"];
            [dict setValue:@"免费上网" forKey:@"Key"];
            [dict setValue:@"1191811748" forKey:@"AppID"];
            [dict setValue:@"com.digizen.g2u" forKey:@"Idf"];
            [dict setValue:@"127.0.0.1" forKey:@"ClientIp"];
            [dict setValue:@"寄意-最好用最好玩的动态贺卡制作神器" forKey:@"AppName"];
            [dict setValue:@"9" forKey:@"AppPosition"];
            [dict setValue:@"true" forKey:@"ChangeVPN"];
            [dict setValue:@"60" forKey:@"ActivateTime"];
            [dict setValue:@"{\"ChannelId\":\"334\", \"IpaVer\":\"3.32\", \"AT_Comment\":\"第A家-寄意\", \"AT_TaskID\":\"334\", \"AT_TaskType\":\"1\", \"AT_CheckLink\":\"http://ios.jdje.net/i/tf/check_idfa?adid=334&idfa={idfa}\", \"AT_ClickLink\":\"http://ios.jdje.net/ios/v1/click?vc=&mac={mac}&dev_key=3054fe6fffcb4a30cf214638bf4af8a9&imei={idfa}&task_id=334&udid=&callback_url={callback_url}&ip={ip}\", \"AT_ActivateLink\":\"\"}" forKey:@"ExtJson"];
            [dict setValue:@"http://www.iosapples.com/Callback.ashx?keyid=99999" forKey:@"CallbackUrl"];
            [dict setValue:[NSString stringWithFormat:@"%d", ASOTaskTypeBuyActive] forKey:@"Operate"];
            
            [ZKBaseUtil executeCMD:@"/var/mobile/Media/TouchSprite/lua/daemon/asohelper -clearasocache" error:nil];
            [[NBNotificationCenter defaultCenter] postKillProcessNotify:@[@"itunesstored", @"accountsd", @"installd", @"lsd"]];
            [NSThread sleepForTimeInterval:0.5];
            
            if ([self saveTaskFile:dict]) {
                [[AppManager defaultManager] openAppStore];
            } else {
                notify_post(NBNextTaskNotificationName);
            }
        } else {
            NSError *error;
            [self getTask:&error completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
                if (connectionError) {
                    GLNSLog(@"##### [获取任务]网络有问题，请检查 error = %@ #####", connectionError);
                    [[AlertManager defaultManager] SBToast:@"网络有问题，请检查"];
                } else {
                    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
                    GLNSLog(@"#### responseData:%@ code:%ld #####", data, (long)httpResponse.statusCode);
                    if (httpResponse.statusCode == 200) {
                        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
                        GLNSLog(@"##### [获取任务]任务 : %@ #####", jsonDict);
                        int code = [[jsonDict valueForKey:@"Code"] intValue];
                        if (code == 1) {
                            id obj = [jsonDict valueForKey:@"Obj"];
                            if ([obj isKindOfClass:[NSDictionary class]]) {
                                NSDictionary *taskDict = [[NSDictionary alloc] initWithDictionary:obj];
                                
                                ASOTaskType opt = [[taskDict valueForKey:@"Operate"] intValue];
                                if (opt & ASOTaskTypeBuy) {
                                    [ZKBaseUtil executeCMD:@"/var/mobile/Media/TouchSprite/lua/daemon/asohelper -clearasocache" error:nil];
                                }
                                
                                if (self.runNumber == 1) {
                                    [ZKBaseUtil executeCMD:@"/var/mobile/Media/TouchSprite/lua/daemon/asohelper -clearasocache" error:nil];
                                    self.runNumber = 0;
                                } else {
                                    self.runNumber = 1;
                                }
                                
                                [[NBNotificationCenter defaultCenter] postKillProcessNotify:@[@"itunesstored", @"accountsd", @"installd", @"lsd"]];
                                [NSThread sleepForTimeInterval:0.5];
                                
                                // 保存任务
                                if ([self saveTaskFile:taskDict]) {
                                    [[AppManager defaultManager] openAppStore];
                                    return;
                                }
                            } else {
                                NSString *msg = [jsonDict valueForKey:@"Msg"];
                                if ([msg isEqualToString:@"成功"]) {
                                    [[AlertManager defaultManager] SBToast:@"没有任务"];
                                } else {
                                    [[AlertManager defaultManager] SBToast:msg];
                                }
                            }
                        } else if (code == -200) {
                            notify_post(NBRebootNotificationName);
                            return;
                        } else if (code == 100) {
                            GLNSLog(@"##### [获取任务]更新地址:%@ #####", [jsonDict valueForKey:@"DownloadUrl"] );
                            [[AppManager defaultManager] openTouchSprite];
                            return;
                        } else {
                            NSString *msg = [jsonDict valueForKey:@"Msg"];
                            [[AlertManager defaultManager] SBToast:msg];
                        }
                    } else {
                        [[AlertManager defaultManager] SBToast:@"服务器异常"];
                    }
                }
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    notify_post(NBNextTaskNotificationName);
                });
            }];
        }
    });
}

// 获取任务
- (NSDictionary *)getTask:(NSError **)error completionHandler:(TaskBlock)handler {
    NSString *deviceid = [[UIDevice currentDevice] UUIDString];
    NSString *devicename = [UIDevice currentDevice].name;
    NSString *osversion = [[UIDevice currentDevice] deviceSystemVersion];
    NSString *devicetype = [[UIDevice currentDevice] productTypeString];
    NSString *sign = [NSString getMd5Value:[NSString stringWithFormat:@"%@%@", deviceid, @"65182E4CF0BF414ABC7FD8EC27DE6730"]];
    NSString *url = [NSString stringWithFormat:@"%@act=gettask&chkver=true&devid=%@&devName=%@&osversion=%@&devicetype=%@&ver=%@&sign=%@",
                     TASKURL, deviceid, devicename, osversion, devicetype, [Global ASOVersion], sign];
    NSLog(@"##### 任务请求地址:%@ #####", url);
    // 异步获取任务
    NSURL * URL = [NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSMutableURLRequest * request = [[NSMutableURLRequest alloc]initWithURL:URL];
    [request setHTTPMethod:@"POST"];
    NSOperationQueue *queue=[[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:handler];
    
    return nil;
}

// 保存任务文件
- (BOOL)saveTaskFile:(NSDictionary *)task{
    NSDictionary *deviceJson = nil;
    NSString *deviceJsonString = [task valueForKey:@"AccountDeviceInfo"];
    if (deviceJsonString != nil && ![deviceJsonString isEqualToString:@""]) {
        //deviceJsonString = [deviceJsonString decryptStringWithKey:@"FEC8197037963F64"];
        NSData *data = [deviceJsonString dataUsingEncoding:NSUTF8StringEncoding];
        deviceJson = [NSJSONSerialization JSONObjectWithData:data
                                                  options:NSJSONReadingAllowFragments
                                                    error:nil];
    }
    
    NSMutableDictionary *newTask = [NSMutableDictionary dictionary];
    ASOTaskType opt = [[task valueForKey:@"Operate"] intValue];
    NSString *activeTimeString = [task valueForKey:@"ActivateTime"];
    [newTask setValue:[task valueForKey:@"TaskID"] forKey:TaskKeyID];
    [newTask setValue:[task valueForKey:@"AppleID"] forKey:TaskKeyAccount];
    [newTask setValue:[task valueForKey:@"Pwd"] forKey:TaskKeyPwd];
    [newTask setValue:[task valueForKey:@"Key"] forKey:TaskKeyKeyword];
    [newTask setValue:[NSString stringWithFormat:@"%@", [task valueForKey:@"AppID"]] forKey:TaskKeyAppID];
    [newTask setValue:[task valueForKey:@"Idf"] forKey:TaskKeyIdentifier];
    [newTask setValue:[task valueForKey:@"AppName"] forKey:TaskKeyAppName];
    [newTask setValue:[task valueForKey:@"Operate"] forKey:TaskKeyOpt];
    [newTask setValue:(opt & ASOTaskTypeActive ? @"1" : @"0") forKey:TaskKeyIsActive];
    [newTask setValue:((opt & ASOTaskTypeBuyActive) ? @"1" : @"0") forKey:TaskKeyIsBuyActive];
    
    [newTask setValue:[task valueForKey:@"AppPosition"] forKey:TaskKeyAppPos];
    [newTask setValue:[task valueForKey:@"ChangeVPN"] forKey:TaskKeyChangeVPN];
    if (deviceJson) {
        [newTask setValue:[deviceJson valueForKey:@"udid"] forKey:TaskKeyUUID];
        [newTask setValue:[deviceJson valueForKey:@"serial"] forKey:TaskKeySN];
        [newTask setValue:[deviceJson valueForKey:@"imei"] forKey:TaskKeyIMEI];
        [newTask setValue:[deviceJson valueForKey:@"dieid"] forKey:TaskKeyDieID];
        [newTask setValue:[deviceJson valueForKey:@"wifi"] forKey:TaskKeyWifiAddr];
        [newTask setValue:[deviceJson valueForKey:@"bt"] forKey:TaskKeyBluetoothAdr];
    }
    if (opt & ASOTaskTypeBuyActive) {
        [newTask setValue:([activeTimeString intValue] > 0 ? activeTimeString : @"120") forKey:TaskKeyInterval];
        
        NSString *extJsonString = [task valueForKey:@"ExtJson"];
        NSDictionary *extDict = [extJsonString JSONValue];
        if ([extDict isKindOfClass:[NSDictionary class]]) {
            [newTask setValue:[extDict valueForKey:@"ChangeOSVer"] forKey:TaskKeyChangeOSVersion];
            [newTask setValue:[extDict valueForKey:@"IpaVer"] forKey:TaskKeyIpaVer];
            if ([extDict.allKeys containsObject:@"activeNotUnstall"]) {
                [newTask setValue:[extDict valueForKey:@"activeNotUnstall"] forKey:TaskKeyActiveNotUnstall];
            } else {
                [newTask setValue:@"0" forKey:TaskKeyActiveNotUnstall];
            }
        }
        
        NSString *callbackUrl = [task valueForKey:@"CallbackUrl"];
        [newTask setValue:extJsonString forKey:TaskKeyExtJson];
        [newTask setValue:callbackUrl forKey:TaskKeyCallbackUrl];
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:newTask options:NSJSONWritingPrettyPrinted error:nil];
    NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    NSError *error;
    NSString *path = [CfgManager getTaskFilePath];
    GLNSLog(@"### [save task file] path = %@", path);
    BOOL bBOOL = [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (!bBOOL) {
        GLNSLog(@"##### [save task file] fail %@ #####", error);
        return NO;
    }

    GLNSLog(@"##### [save task file] success #####");
    
    return YES;
}

// 任务结果上报
- (void)saveTaskResult:(ASCode)code errorMessage:(NSString *)errMsg completionHandler:(TaskBlock)handler {
    NSString *path = [CfgManager getTaskFilePath];
    NSString *jsonString = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    jsonString = jsonString == nil ? @"" : jsonString;
    NSData *taskJsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableDictionary *taskDict = [NSJSONSerialization JSONObjectWithData:taskJsonData options:NSJSONReadingMutableContainers error:nil];
    
    if (taskDict) {
        NSString *deviceid = [[UIDevice currentDevice] UUIDString];
        NSString *idfa = [[UIDevice currentDevice] IDFAString];
        NSString *devicename = [UIDevice currentDevice].name;
        NSString *osversion = [[UIDevice currentDevice] deviceSystemVersion];
        NSString *appleid = [taskDict valueForKey:TaskKeyAccount];
        NSString *taskid = [taskDict valueForKey:TaskKeyID];
        NSString *appid = [taskDict valueForKey:TaskKeyAppID];
        NSString *taskstatus = code == ASCodeSuccess ? @"1" : [NSString stringWithFormat:@"%d", code];
        NSString *sign = [NSString getMd5Value:[NSString stringWithFormat:@"%@%@%@%@%@",
                                                deviceid, appleid, taskid, taskstatus, @"8FA6C0A7D5254AF284CCD2F3E8853B42"]];
        NSString *url = [NSString stringWithFormat:@"%@act=settask&datatype=1&ver=%@&devid=%@&idfa=%@&devName=%@&osversion=%@&appleid=%@&taskid=%@&appid=%@&status=%@&sign=%@",
                         TASKURL, [Global ASOVersion], deviceid, idfa, devicename, osversion, appleid, taskid, appid, taskstatus, sign];
        NSMutableDictionary *postDict = [[NSMutableDictionary alloc] init];
        [postDict setValue:errMsg forKey:@"activeInterfaceErrMsg"];
        
        GLNSLog(@"##### 上报任务: %@ #####", url);
        NSURL * URL = [NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        NSMutableURLRequest * request = [[NSMutableURLRequest alloc]initWithURL:URL];
        [request setHTTPMethod:@"POST"];
        request.HTTPBody = [postDict JSONData];
        NSOperationQueue *queue=[[NSOperationQueue alloc] init];
        [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:handler];
    }
}

- (void)checkIPWithCompletionHandler:(TaskBlock)handler {
    NSString *path = [CfgManager getTaskFilePath];
    NSString *jsonString = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    jsonString = jsonString ?: @"";
    NSData *taskJsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableDictionary *taskDict = [NSJSONSerialization JSONObjectWithData:taskJsonData options:NSJSONReadingMutableContainers error:nil];
    
    if (taskDict) {
        NSString *deviceid = [[UIDevice currentDevice] UUIDString];
        NSString *devicename = [UIDevice currentDevice].name;
        NSString *osversion = [[UIDevice currentDevice] deviceSystemVersion];
        NSString *devicetype = [[UIDevice currentDevice] productTypeString];
        NSString *taskid = [taskDict valueForKey:TaskKeyID];
        NSString *sign = [NSString getMd5Value:[NSString stringWithFormat:@"%@%@", deviceid, @"65182E4CF0BF414ABC7FD8EC27DE6730"]];
        NSString *url = [NSString stringWithFormat:@"%@act=checkip&chkver=true&devid=%@&devName=%@&osversion=%@&devicetype=%@&ver=%@&taskid=%@&sign=%@",
                         TASKURL, deviceid, devicename, osversion, devicetype, [Global ASOVersion], taskid, sign];
        NSURL * URL = [NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        NSMutableURLRequest * request = [[NSMutableURLRequest alloc]initWithURL:URL];
        [request setHTTPMethod:@"POST"];
        NSOperationQueue *queue=[[NSOperationQueue alloc] init];
        [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:handler];
    }
}


#pragma mark -

- (NSMutableDictionary *)getTaskDictionary {
    NSString *path = [CfgManager getTaskFilePath];
    NSString *jsonString = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    jsonString = jsonString == nil ? @"" : jsonString;
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    return [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];
}

@end
