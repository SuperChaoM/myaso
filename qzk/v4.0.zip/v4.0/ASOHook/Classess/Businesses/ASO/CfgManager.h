//
//  CfgManager.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/20.
//
//

#import <Foundation/Foundation.h>

@interface CfgManager : NSObject

+ (NSString *)getAppDocumentsPath:(NSString *)identifier;

+ (NSString *)getTaskFilePath;

+ (NSString *)getTweakConfigurePath;

@end
