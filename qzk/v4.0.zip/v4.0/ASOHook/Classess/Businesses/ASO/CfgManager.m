//
//  CfgManager.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/20.
//
//

#import "CfgManager.h"

@interface CfgManager ()

@end

@implementation CfgManager

+ (NSString *)getAppDocumentsPath:(NSString *)identifier {
    Class LSApplicationWorkspace_class = objc_getClass("LSApplicationWorkspace");
    NSObject *workspace = [LSApplicationWorkspace_class performSelector:@selector(defaultWorkspace)];
    NSArray *allApps = [workspace performSelector:@selector(allApplications)];
    for (id app in allApps) {
        NSString *appIdf = [app performSelector:@selector(applicationIdentifier)];
        NSURL *containurl = [app performSelector:@selector(containerURL)];
        if ([appIdf isEqualToString:identifier]) {
            NSString *path = [containurl absoluteString];
            path = [path stringByReplacingOccurrencesOfString:@"file://" withString:@""];
            if ([path hasSuffix:@"/"]) {
                path = [path stringByAppendingString:@"Documents/"];
            } else {
                path = [path stringByAppendingString:@"/Documents/"];
            }
            return path;
        }
    }
    
    return @"";
}

+ (NSString *)getTweakConfigurePath {
    NSString *filepath = TweakFile;
    NSString *docDir = [self getAppDocumentsPath:AppStoreIdentifier];
    if (![docDir isEqualToString:@""]) {
        filepath = [docDir stringByAppendingString:TweakFileName];
    }
    
    return filepath;
}

+ (NSString *)getTaskFilePath {
    NSString *filepath = TaskFile;
    NSString *docDir = [self getAppDocumentsPath:AppStoreIdentifier];
    if (![docDir isEqualToString:@""]) {
        filepath = [docDir stringByAppendingString:TaskFileName];
    }
    
    return filepath;
}

@end
