//
//  NSString+BDJSON.m
//  MobileAssist
//
//  Created by 郑志淋 on 15/3/26.
//  Copyright (c) 2015年 baidu91. All rights reserved.
//

#import "NSString+BDJSON.h"

@implementation NSString (NSString_BDJSON)

- (id)JSONValue {
    NSError *error = nil;
    id value = nil;
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    value = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    if (error != nil) {
        NSLog(@"NSString JSONValue Error:[%@]", [error localizedDescription]);
    }
    return value;
}

@end
