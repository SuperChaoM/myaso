//
//  NSData+BDJSON.m
//  MobileAssist
//
//  Created by 郑志淋 on 15/3/26.
//  Copyright (c) 2015年 baidu91. All rights reserved.
//

#import "NSData+BDJSON.h"

@implementation NSData (NSData_BDJSON)

- (id)JSONValue {
    NSError *error = nil;
    id value = nil;
    value = [NSJSONSerialization JSONObjectWithData:self options:NSJSONReadingMutableContainers error:&error];
    if (error != nil) {
        NSLog(@"NSData JSONValue Error:[%@]",[error localizedDescription]);
    }
    return value;
}

@end
