//
//  NSDictionary.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 16/4/28.
//
//

#import "NSDictionary+Parser.h"

@implementation NSDictionary (Parser)

+ (NSMutableDictionary *)paramsDictionaryFromUrl:(NSString *)urlString
{
    if (urlString == nil) {
        return nil;
    }
    
    __autoreleasing NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    
    NSURL       *url = [[NSURL alloc]initWithString:urlString];
    NSString    *query = [url query];
    NSArray     *array = [query componentsSeparatedByString:@"&"];
    
    for (NSString *s in array) {
        NSArray *item = [s componentsSeparatedByString:@"="];
        
        if (item.count == 2) {
            [params setObject:[item objectAtIndex:1] forKey:[item objectAtIndex:0]];
        }
    }
    
    return params;
}

@end
