//
//  UIDevice+Common.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/20.
//
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(int, IOSPlatform) {
    kIOSPlatform_unknow     = 0,
    kIOSPlatform_iPhone,
    kIOSPlatform_iPhone3G,
    kIOSPlatform_iPhone3GS,
    kIOSPlatform_iPhone4,
    kIOSPlatform_iPhone4s,
    kIOSPlatform_iPhone5,
    kIOSPlatform_iPhone5c,
    kIOSPlatform_iPhone5s,
    kIOSPlatform_iPhone6,
    kIOSPlatform_iPhone6p,
    kIOSPlatform_iPhone6s,
    kIOSPlatform_iPhone6sp,
    kIOSPlatform_iPhone7,
    kIOSPlatform_iPhone7p,
};

@interface UIDevice(Common)

- (NSString *)deviceSystemVersion;

- (NSString *)productTypeString;

- (IOSPlatform)devicePlatform;

- (NSString *)myUserAgent:(NSString *)useragent;

- (NSString *)UUIDString;

- (NSString *)macAddressString;

- (NSString *)bluetoothAddressString;

- (NSString *)serialNumberString;

- (NSString *)IMEIString;

- (NSString *)dieIDString;

- (NSString *)IDFAString;

// 内网ip
- (NSString *)InnerIPAddressString;

// 外网ip
- (NSString *)OuterIPAddressString;

@end
