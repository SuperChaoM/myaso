//
//  NSObject+BDJSON.m
//  MobileAssist
//
//  Created by 郑志淋 on 15/3/26.
//  Copyright (c) 2015年 baidu91. All rights reserved.
//

#import "NSObject+BDJSON.h"

@implementation NSObject (NSObject_BDJSON)

- (NSData*)JSONData {
    NSError *error = nil;
    NSData *result = nil;
    result = [NSJSONSerialization dataWithJSONObject:self options:NSJSONWritingPrettyPrinted error:&error];
    if (error != nil) {
        NSLog(@"NSObject JSONData Error:[%@]",[error localizedDescription]);
    }
    return result;
}

@end
