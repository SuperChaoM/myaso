//
//  NSObject+BDJSON.h
//  MobileAssist
//
//  Created by 郑志淋 on 15/3/26.
//  Copyright (c) 2015年 baidu91. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (NSObject_BDJSON)

- (NSData*)JSONData;

@end
