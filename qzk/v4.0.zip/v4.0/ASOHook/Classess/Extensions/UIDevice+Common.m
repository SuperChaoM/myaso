//
//  UIDevice+Common.m
//  ASOHook
//
//  Created by Qiu.ZhiKai on 2016/10/20.
//
//

#import "UIDevice+Common.h"
#import <sys/sysctl.h>
#import <AdSupport/ASIdentifierManager.h>
#import <sys/utsname.h>
// 获取ip
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <net/if.h>

OBJC_EXTERN CFStringRef MGCopyAnswer(CFStringRef key) WEAK_IMPORT_ATTRIBUTE;

@implementation UIDevice(Common)

- (NSString *)deviceSystemVersion {
    NSString *sysVerString = [[UIDevice currentDevice] systemVersion];
    return sysVerString;
}

- (NSString *)productTypeString {
    struct utsname systemInfo;
    uname(&systemInfo);
    
    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
}

- (IOSPlatform)devicePlatform {
    size_t size;
    int nR = sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = (char *)malloc(size);
    nR = sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    
    if([platform isEqualToString:@"iPhone1,1"]) {
        return kIOSPlatform_iPhone;
    } else if([platform isEqualToString:@"iPhone1,2"]) {
        return kIOSPlatform_iPhone3G;
    } else if([platform isEqualToString:@"iPhone2,1"]) {
        return kIOSPlatform_iPhone3GS;
    } else if([platform isEqualToString:@"iPhone3,1"]||
              [platform isEqualToString:@"iPhone3,2"]||
              [platform isEqualToString:@"iPhone3,3"]) {
        return kIOSPlatform_iPhone4;
    } else if([platform isEqualToString:@"iPhone4,1"]) {
        return kIOSPlatform_iPhone4s;
    } else if([platform isEqualToString:@"iPhone5,1"]||
              [platform isEqualToString:@"iPhone5,2"]) {
        return kIOSPlatform_iPhone5;
    } else if([platform isEqualToString:@"iPhone5,3"]||
              [platform isEqualToString:@"iPhone5,4"]) {
        return kIOSPlatform_iPhone5c;
    } else if([platform isEqualToString:@"iPhone6,2"]||
              [platform isEqualToString:@"iPhone6,1"]) {
        return kIOSPlatform_iPhone5s;
    } else if ([platform isEqualToString:@"iPhone7,2"]) {
        return kIOSPlatform_iPhone6;
    }
    return kIOSPlatform_unknow;
}

- (NSString *)myUserAgent:(NSString *)useragent {
    NSString *systemVerStr = [[UIDevice currentDevice] deviceSystemVersion];
    NSString *buildVerStr =  [[UIDevice currentDevice] performSelector:NSSelectorFromString(@"buildVersion")];
    NSString *productTypeStr = [[UIDevice currentDevice] productTypeString];
    
    useragent = [useragent stringByReplacingOccurrencesOfString:systemVerStr withString:TargetDeviceOSVersion];
    useragent = [useragent stringByReplacingOccurrencesOfString:buildVerStr withString:TargetDeviceBuildVersion];
    useragent = [useragent stringByReplacingOccurrencesOfString:productTypeStr withString:TargetDeviceProductType];
    
    NSRange subRange = [useragent rangeOfString:@"6; dt:"];
    if (subRange.location != NSNotFound) {
        useragent = [NSString stringWithFormat:@"%@%@)", [useragent substringToIndex:subRange.location + subRange.length], TargetDeviceDT];
    }
    
    return useragent;
}

- (NSString *)UUIDString {
    if (kCFCoreFoundationVersionNumber < 800) {//iOS 7以下
        
        NSString *udid = [[UIDevice currentDevice] valueForKey:@"uniqueIdentifier"];
        
        return udid;
    }
    
    CFStringRef result = MGCopyAnswer(CFSTR("UniqueDeviceID"));
    
    return (__bridge NSString *)(result);
}

- (NSString *)macAddressString {
    if (kCFCoreFoundationVersionNumber < 800) {//iOS 7以下
        return @"";
    }
    
    CFStringRef result = MGCopyAnswer(CFSTR("WifiAddress"));
    
    return (__bridge NSString *)(result);
}

- (NSString *)bluetoothAddressString {
    if (kCFCoreFoundationVersionNumber < 800) {//iOS 7以下
        return @"";
    }
    
    CFStringRef result = MGCopyAnswer(CFSTR("BluetoothAddress"));
    
    return (__bridge NSString *)(result);
}

- (NSString *)serialNumberString {
    if (kCFCoreFoundationVersionNumber < 800) {//iOS 7以下
        return @"";
    }
    
    CFStringRef result = MGCopyAnswer(CFSTR("SerialNumber"));
    
    return (__bridge NSString *)(result);
}

- (NSString *)IMEIString {
    if (kCFCoreFoundationVersionNumber < 800) {//iOS 7以下
        return @"";
    }
    
    CFStringRef result = MGCopyAnswer(CFSTR("InternationalMobileEquipmentIdentity"));
    
    return (__bridge NSString *)(result);
}

- (NSString *)dieIDString {
    if (kCFCoreFoundationVersionNumber < 800) {//iOS 7以下
        return @"";
    }
    
    CFStringRef result = MGCopyAnswer(CFSTR("DieId"));
    
    return (__bridge NSString *)(result);
}

- (NSString *)IDFAString {
    NSString *idfa = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    return idfa;
}

- (NSString *)InnerIPAddressString {
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while (temp_addr != NULL) {
            if( temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if ([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    
    // Free memory
    freeifaddrs(interfaces);
    
    return address;
}

- (NSString *)OuterIPAddressString {
    NSError *error;
    NSURL *ipURL = [NSURL URLWithString:@"http://pv.sohu.com/cityjson?ie=utf-8"];
    NSMutableString *ip = [NSMutableString stringWithContentsOfURL:ipURL encoding:NSUTF8StringEncoding error:&error];
    //判断返回字符串是否为所需数据
    if ([ip hasPrefix:@"var returnCitySN = "]) {
        //对字符串进行处理，然后进行json解析
        //删除字符串多余字符串
        NSRange range = NSMakeRange(0, 19);
        [ip deleteCharactersInRange:range];
        NSString * nowIp =[ip substringToIndex:ip.length-1];
        //将字符串转换成二进制进行Json解析
        NSData * data = [nowIp dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        return [dict valueForKey:@"cip"];
    }
    
    return @"";
}

@end
