//
//  NSString+BDJSON.h
//  MobileAssist
//
//  Created by 郑志淋 on 15/3/26.
//  Copyright (c) 2015年 baidu91. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NSString_BDJSON)

- (id)JSONValue;

@end
