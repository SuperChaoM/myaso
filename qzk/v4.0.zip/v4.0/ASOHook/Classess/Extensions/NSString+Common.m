//
//  NSString+Common.m
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/2/29.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import "NSString+Common.h"
#import "GTMBase64.h"
#import "GTMNSString+URLArguments.h"
#import <CommonCrypto/CommonDigest.h>
//#import <Encrypt/NDDes3.h>

@implementation NSString(Common)

+ (BOOL) isNullOrEmpty:(NSString *)string {
    if (string == nil || [string isEqualToString:@""]) {
        return YES;
    }
    return NO;
}

+ (NSString *)getMd5Value:(NSString *)value {
    
    const char *cStr = [value UTF8String];
    unsigned char result[16];
    CC_MD5( cStr, (unsigned int)strlen(cStr), result );
    
    return [[NSString stringWithFormat:
             @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
             result[0], result[1], result[2], result[3],
             result[4], result[5], result[6], result[7],
             result[8], result[9], result[10], result[11],
             result[12], result[13], result[14], result[15]
             ] lowercaseString];
}

+ (NSString *)getMd5ValueWithData:(NSData *)data {
    
    unsigned char result[16];
    CC_MD5( data.bytes, (unsigned int)(data.length), result );
    
    NSString *resultString =  [NSString stringWithFormat:
                               @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                               result[0], result[1], result[2], result[3],
                               result[4], result[5], result[6], result[7],
                               result[8], result[9], result[10], result[11],
                               result[12], result[13], result[14], result[15]
                               ];
    return resultString;
}

//将对象转换成JSON字符串
+ (NSString *)JSONRepresentationWithObject:(id)object {
    if (object == nil) {
//        kFunctionParamInvalid;
        return nil;
    }
    
    NSData *jsonData = nil;
    @try {
        NSError *error = nil;
        jsonData = [NSJSONSerialization dataWithJSONObject:object
                                                   options:NSJSONWritingPrettyPrinted
                                                     error:&error];
        if (jsonData == nil || error) {
            GLNSLog(@"JSON serialization error: %@", error);
            return @"";
        }
    }
    @catch (NSException *exception) {
//        kExceptionDescription(exception);
        return @"";
    }
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

    

+ (id)JSONValueFromObject:(id)object {
    if (object == nil) {
//        kFunctionParamInvalid;
        return nil;
    }
    
    NSData *data = nil;
    if ([object isKindOfClass:[NSString class]]) {
        if (![NSString isNullOrEmpty:object]) {
            data = [(NSString *)object dataUsingEncoding:NSUTF8StringEncoding];
        }
    } else if ([object isKindOfClass:[NSData class]]) {
        data = (NSData *)object;
    }
    
    if (data == nil) {
        GLNSLog(@"JSON serialization invalid object: %@", object);
        return nil;
    }
    
    id value = nil;
    @try {
        NSError *error = nil;
        value = [NSJSONSerialization JSONObjectWithData:data
                                                options:NSJSONReadingAllowFragments
                                                  error:&error];
        if (error != nil) {
            GLNSLog(@"JSON serialization error: %@", error);
            return nil;
        }
    }
    @catch (NSException *exception) {
//        kExceptionDescription(exception);
    }
    
    return value;
}

+ (NSString *)decodeURL:(NSString *)string {
    
    if ([NSString isNullOrEmpty:string]) {
        return @"";
    }
    return [string stringByUnescapingFromURLArgument];
}

+ (NSString *)encodeURL:(NSString *)string {
    
    if ([NSString isNullOrEmpty:string]) {
        return @"";
    }
    return [string stringByEscapingForURLArgument];
}

+ (NSString*)encodeString:(NSString*)unencodedString{
    
    // CharactersToBeEscaped = @":&=;+!@#$()~',*";
    // CharactersToLeaveUnescaped = @"[].";
    
    NSString *encodedString = (NSString *)
    CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                              (CFStringRef)unencodedString,
                                                              NULL,
                                                              (CFStringRef)@"!*'();:@&=+$,%#[]",
                                                              kCFStringEncodingUTF8));
    
    return encodedString;
}

//URLDEcode
+ (NSString *)decodeString:(NSString*)encodedString

{
    //NSString *decodedString = [encodedString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding ];
    
    NSString *decodedString  = ( NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL,
                                                                                                                     (__bridge CFStringRef)encodedString,
                                                                                                                     CFSTR(""),
                                                                                                                     CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
    return decodedString;
}



+ (NSString *)replaceParamOfUrl:(NSString *)url withKey:(NSString *)key withNewValue:(NSString *)value {
    if ([url rangeOfString:[NSString stringWithFormat:@"&%@=", key]].location == NSNotFound) {
        return url;
    } else if ([url rangeOfString:[NSString stringWithFormat:@"&%@=%@", key, value]].location != NSNotFound) {
        return url;
    }
    
    NSMutableString *mstr = [NSMutableString string];
    NSArray     *array = [url componentsSeparatedByString:@"?"];
    for (int i = 0; i < array.count; i++) {
        if (i == 0) {
            [mstr appendFormat:@"%@?", array[i]];
            continue;
        } else {
            NSArray *groups = [array[i] componentsSeparatedByString:@"&"];
            int groupIndex = 0;
            for (NSString *group in groups) {
                NSArray *items = [group componentsSeparatedByString:@"="];
                if (items.count == 2) {
                    if ([key isEqualToString:items[0]]) {
                        [mstr appendFormat:@"%@=%@", items[0], value];
                    } else {
                        [mstr appendFormat:@"%@=%@", items[0], items[1]];
                    }
                }
                
                groupIndex++;
                if (groupIndex < groups.count) {
                    [mstr appendString:@"&"];
                }
            }
        }
    }
    return mstr;
}

@end
