//
//  NSString+Common.h
//  AppStore(ios)
//
//  Created by Qiu.ZhiKai on 16/2/29.
//  Copyright © 2016年 Qiu.ZhiKai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(Common)

+ (BOOL) isNullOrEmpty:(NSString *)string;

+ (NSString *)JSONRepresentationWithObject:(id)object;

+ (id)JSONValueFromObject:(id)object;

#pragma mark - md5
/**
 得到md5值
 
 @param value md5的生成源字符串
 @return 生成的md5
 */
+ (NSString *)getMd5Value:(NSString *)value;

/**
 得到md5值
 
 @param data md5的生成源字符串
 @return 生成的md5
 */
+ (NSString *)getMd5ValueWithData:(NSData *)data;

#pragma mark url编码/解码

/**
 将数据进行URL Encode编码
 
 @param string 待编码的数据
 */
+ (NSString *)encodeURL:(NSString *)string;
+ (NSString*)encodeString:(NSString*)unencodedString;

/**
 将数据进行URL Encode解码
 
 @param string 待解码的数据
 */
+ (NSString *)decodeURL:(NSString *)string;
+ (NSString *)decodeString:(NSString*)encodedString;

/**
 替换url中参数
 */
+ (NSString *)replaceParamOfUrl:(NSString *)url withKey:(NSString *)key withNewValue:(NSString *)value;

@end
