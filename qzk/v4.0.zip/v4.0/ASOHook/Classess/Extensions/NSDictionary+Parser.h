//
//  NSDictionary.h
//  ASOHook
//
//  Created by Qiu.ZhiKai on 16/4/28.
//
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Parser)

+ (NSMutableDictionary *)paramsDictionaryFromUrl:(NSString *)urlString;

@end
