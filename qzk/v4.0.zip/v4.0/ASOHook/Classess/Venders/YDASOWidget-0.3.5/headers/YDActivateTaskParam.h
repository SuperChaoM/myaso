//
//  YDActivateTaskParam.h
//  YDASOWidget
//
//  Created by sgy on 2017/7/25.
//  Copyright © 2017年 yunduo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define kATTaskSuccessCodeDefault       -999    // 根据平台选择
#define kATTaskSuccessCodePlatformA     0       // 平台A，code=0
#define kATTaskSuccessCodePlatformB     1       // 平台B，status=1

// 任务类型：  AT_TaskType  0-API任务(默认)  1-快速任务(需要激活)
typedef NS_ENUM(NSInteger, ATTaskType) {
    ATTaskTypeAPI = 0,
    ATTaskTypeQuick = 1,
};

// 对接平台
typedef NS_ENUM(NSInteger, ATTaskPlatform) {
    ATTaskPlatformUnknown = 0,  // 默认平台
    ATTaskPlatformA = 1,        // 平台A，code=0
    ATTaskPlatformB = 2,        // 平台B，status=1
};

@interface YDActivateTaskParam : NSObject

@property (nonatomic, copy) NSString *taskComment;      // 任务注释
@property (nonatomic, copy) NSString *taskID;           // 任务ID
@property (nonatomic, assign) ATTaskType taskType;      // 任务类型

@property (nonatomic, assign) BOOL postMethod;          // HTTP请求方式：1:POST, 0:GET(默认)

@property (nonatomic, copy) NSString *checkLink;        // 排重链接
@property (nonatomic, copy) NSString *clickLink;        // 点击链接
@property (nonatomic, copy) NSString *activateLink;     // 激活链接

@property (nonatomic, assign) BOOL realTimeCallback;    // 是否存在实时回调（去哪儿等，默认YES）

@property (nonatomic, assign) NSInteger newUserCode;    // 新用户状态值（各平台可能不同，默认0）
@property (nonatomic, assign) NSInteger successCode;    // 返回值成功数值（各平台可能不同，默认-1，A=0,B=1）

// 额外参数（ASO模块）
@property (nonatomic, copy) NSString *callbackLink;     // 回调链接
@property (nonatomic, copy) NSString *keyword;          // 任务关键词

- (NSString *)finalURLStringWithLink:(NSString *)link;

- (NSString *)finalCallbackURLWithLink:(NSString *)link;

+ (ATTaskPlatform)taskPlatformWithResponse:(NSDictionary *)dict;
- (BOOL)isActivateTaskSuccess:(NSDictionary *)dict;

- (instancetype)initWithDictionary:(NSDictionary *)dictionaryValue error:(NSError *__autoreleasing *)error;

@end
