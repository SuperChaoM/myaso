//
//  YDASOWidget.h
//  YDASOWidget
//
//  Created by sgy on 2017/7/25.
//  Copyright © 2017年 yunduo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for YDASOWidget.
FOUNDATION_EXPORT double YDASOWidgetVersionNumber;

//! Project version string for YDASOWidget.
FOUNDATION_EXPORT const unsigned char YDASOWidgetVersionString[];

#import "YDVerifyManager.h"
#import "YDActivateTaskManager.h"
