//
//  YDVerifyManager.h
//  YDASOWidget
//
//  Created by sgy on 2017/7/25.
//  Copyright © 2017年 yunduo. All rights reserved.
//

#import <UIKit/UIkit.h>
#import "YDVerifySetting.h"

#define kVerifyImageCodeInvalid             @"000"  // 无效的默认验证码

@interface YDVerifyManager : NSObject

+ (YDVerifyManager *)sharedManager;

// 验证码自动识别
- (void)autoVerifyCodeWithCompletionHandler:(void (^)(NSString *code, NSError *error))handler;

// 验证码自动识别(自动识别验证码是否已出现)
- (void)checkAndAutoVerifyCodeWithCompletionHandler:(void (^)(NSString *code, NSError *error))handler;

// 验证码自动识别Gif
- (void)autoVerifyGifCode:(NSString *)gifUrl completionHandler:(void (^)(NSString *code, NSError *error))handler;

@end
