//
//  YDActivateTaskManager.h
//  YDASOWidget
//
//  Created by sgy on 2017/7/25.
//  Copyright © 2017年 yunduo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/NSError.h>
#import "YDActivateSetting.h"
#import "YDActivateTaskParam.h"

typedef NS_ENUM(NSInteger, YDActivateErrorCode) {
    YDActivateErrorNetwork = -10,               // 网络错误
    YDActivateErrorNewUser = -100,              // 排重错误
    YDActivateErrorNewTask = -200,              // 任务错误
    YDActivateErrorActivedStatus = -300,        // 激活错误
};

@class YDActivateTaskParam;
@interface YDActivateTaskManager : NSObject

@property (nonatomic, strong) YDActivateTaskParam *taskParam;

+ (YDActivateTaskManager *)sharedManager;

// 解析参数（激活任务+ASO任务）
- (void)parseTaskParam:(NSString *)taskParam
              callback:(NSString *)callback
               keyword:(NSString *)keyword;

// 通过营销活动链接跳转AppStore
- (BOOL)shouldJump2AppStorePage;
- (void)jump2AppStorePageWithError:(NSError **)error;

// 判断是否是新用户
- (BOOL)isNewUserWithError:(NSError **)error;

// 获取新任务
- (BOOL)getNewTaskWithError:(NSError **)error;

// 是否激活成功
- (BOOL)checkActivedStatusWithError:(NSError **)error;

@end
