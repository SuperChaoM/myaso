//
//  YDActivateSetting.h
//  YDASOWidget
//
//  Created by sgy on 2017/7/25.
//  Copyright © 2017年 yunduo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDActivateSetting : NSObject

@property (nonatomic, assign) BOOL showDebugLog;                    // 显示调试日志

+ (YDActivateSetting *)sharedInstance;

@end
