//
//  YDVerifySetting.h
//  YDASOVerify
//
//  Created by sgy on 2017/8/10.
//  Copyright © 2017年 yunduo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define kVerifyImageCompressionQuality      0.7     // JPEG图片压缩系数
#define kVerifyImageCodeLengthDefault       3       // 验证码数据默认长度

// 验证码平台
typedef NS_ENUM(NSInteger, YDVerifyPlatform) {
    YDVerifyPlatformDefault = 0,
};

// 动态验证码类型
typedef NS_ENUM(NSInteger, YDVerifyStyle) {
    YDVerifyStyleUnknown = 1000,    // 未知类型，任意长度数字
    YDVerifyStyleSimple3 = 1030,    // 第1版简单动态，3位纯数字
    YDVerifyStyleHollow4 = 1040,    // 第2版空心动态，4位纯数字
    YDVerifyStyleHollow5 = 1050,    // 第3版空心动态，5位纯数字模糊 Gif
};

@interface YDVerifySetting : NSObject

@property (nonatomic, assign) YDVerifyStyle currentTargetStyle;     // 动态验证码类型（默认Unknown）
@property (nonatomic, strong) NSArray *targetStyleOrdered;          // 支持的目标验证码类型顺序（默认只支持最新类型）

@property (nonatomic, assign) NSInteger screenshotCount;            // 截屏数量（默认5张）
@property (nonatomic, assign) NSTimeInterval sleepForScreenshot;    // 连续截图时间间隔（默认：0.3s）

@property (nonatomic, assign) BOOL forcibleClipTarget;              // 强制指定切图区域（默认NO）
@property (nonatomic, assign) CGRect clipTargetRect;                // 切图的目标区域（默认CGRectZero）

@property (nonatomic, assign) CGFloat compressionQuality;           // 图片压缩系数（默认0.7）

@property (nonatomic, assign) NSInteger autoCheckMaxCount;          // 自动检测重试次数（默认6次）
@property (nonatomic, assign) NSTimeInterval sleepForAutoCheck;     // 自动检测延迟时间（默认5秒）

@property (nonatomic, assign) NSInteger verifyCodeLength;           // 验证码长度（默认至少3）
@property (nonatomic, assign) NSInteger autoRetryCount;             // 自动识别重试次数（默认0不重试）

@property (nonatomic, assign) BOOL showDebugLog;                    // 显示调试日志（默认NO）
@property (nonatomic, assign) BOOL showImageLog;                    // 显示图片日志（默认NO）

// 验证码平台信息
@property (nonatomic, assign) YDVerifyPlatform verifyPlatform;      // 验证码平台
@property (nonatomic, strong) NSString *platformUserName;           // 平台账户名
@property (nonatomic, strong) NSString *platformPassword;           // 平台密码

// 上传验证结果
@property (nonatomic, assign) BOOL needReportVerifyCode;            // 是否需要上报验证结果（默认YES）

+ (YDVerifySetting *)sharedInstance;

// 验证码对应的切图区域
- (CGRect)clipRect4VerifyStyle:(YDVerifyStyle)style;

// 动态字符输入框焦点位置
- (CGPoint)inputFocusPoint4VerifyStyle:(YDVerifyStyle)style;

// 长按输入焦点位置
- (CGPoint)longFocusPoint4VerifyStyle:(YDVerifyStyle)style;

// <粘贴>按钮点击位置
- (CGPoint)pasteClickPoint4VerifyStyle:(YDVerifyStyle)style;

// 空白处位置
- (CGPoint)blankAreaPoint4VerifyStyle:(YDVerifyStyle)style;

// <下一页>按钮点击位置
- (CGPoint)nextPagePoint4VerifyStyle:(YDVerifyStyle)style;

@end
