/*
 * readline.h
 *
 */

int ReadlineCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST objv[]);
int RLHistoryCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST objv[]);
